package com.guideme.application.android;

import com.guideme.application.android.modelo.Comentario;
import com.guideme.application.android.utils.Operaciones;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;

import static org.junit.Assert.*;

public class OperacionesTest {

    private ArrayList<Comentario> comentarios;
    Operaciones operaciones;
    @Before
    public void setUp() throws Exception {
        operaciones = new Operaciones();
        comentarios = new ArrayList<>();
        Comentario comentario = new Comentario();
        comentario.setCalificacion((float) 4);
        comentarios.add(comentario);
        comentario = new Comentario();
        comentario.setCalificacion((float) 3);
        comentarios.add(comentario);
        comentario = new Comentario();
        comentario.setCalificacion((float) 5);
        comentarios.add(comentario);
        comentario = new Comentario();
        comentario.setCalificacion((float) 2);
        comentarios.add(comentario);
    }

    @After
    public void tearDown() throws Exception {
        comentarios = null;
    }

    @Test
    public void calcularCalificacionTest() {
        assertEquals(3.5, operaciones.calcularCalificacion(comentarios), 0);
    }

    @Test
    public void calcularCalificacionTestSinComentarios() {
        comentarios = null;
        assertEquals(0, operaciones.calcularCalificacion(comentarios), 0);
    }
}