package com.guideme.application.android;

import com.guideme.application.android.utils.ValidarTextos;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.verify;


public class ValidarTextosTest {


    private ValidarTextos validarTextos;


    @Before
    public void setUp() throws Exception {
        validarTextos = new ValidarTextos();
    }

    @After
    public void tearDown() throws Exception {
        validarTextos = null;
    }

    @Test
    public void shouldReturnTrueWhenTextIsEmpty() {
        assertTrue(validarTextos.isBlank(""));
    }

    @Test
    public void shouldReturnFalseWhenTextIsNotEmpty() {
        assertFalse(validarTextos.isBlank(" "));
    }

    @Test
    public void shouldReturnTrueWhenIsEmail() {
        boolean var = validarTextos.isEmail("andreschess2009@hotmail.com");
        assertTrue(var);
    }

    @Test
    public void shouldReturnFalseWhenIsNotEmail() {
        assertFalse(validarTextos.isEmail("andreschess2009"));
    }

    @Test
    public void shouldReturnTrueWhenIsPhone() {
        assertTrue(validarTextos.isPhone("3108756121"));
    }

    @Test
    public void shouldReturnFalseWhenIsPhone() {
        assertFalse(validarTextos.isPhone("1234"));
    }

    @Test
    public void shouldReturnTrueWhenIsWeb() {
        boolean var = validarTextos.isWeb("www.facebook.com");
        assertTrue(var);
    }

    @Test
    public void shouldReturnFalseWhenIsNotWeb() {
        assertFalse(validarTextos.isWeb("facebook"));
    }

    @Test
    public void validatePassword() {

    }
}