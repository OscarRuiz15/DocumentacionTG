package com.guideme.application.android;

import com.guideme.application.android.modelo.Evento;
import com.guideme.application.android.modelo.Lugar;
import com.guideme.application.android.utils.Consultas;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.hasProperty;
import static org.junit.Assert.assertThat;

public class ConsultasTest {

    private Consultas consultas;
    private ArrayList<Lugar> lugares;
    private ArrayList<Evento> eventos;

    @Before
    public void setUp() throws Exception {
        consultas = new Consultas();

        lugares = new ArrayList<>();
        Lugar l = new Lugar();
        l.setNombre("Restaurante Viejo Juancho");
        lugares.add(l);
        l = new Lugar();
        l.setNombre("Restaurante El Naranjal");
        lugares.add(l);
        l = new Lugar();
        l.setNombre("Heladeria Yusti");
        lugares.add(l);
        l = new Lugar();
        l.setNombre("Hotel");
        lugares.add(l);
        l = new Lugar();
        l.setNombre("Restaurante Molino Viejo");
        lugares.add(l);

        eventos =  new ArrayList<>();
        Evento evento = new Evento();
        evento.setNombre("Promocion");
        eventos.add(evento);
        evento = new Evento();
        evento.setNombre("Promocion 2x1");
        eventos.add(evento);
        evento = new Evento();
        evento.setNombre("PROMO");
        eventos.add(evento);
    }

    @After
    public void tearDown() throws Exception {
        lugares = null;
        eventos = null;
    }

    @Test
    public void consultaLugaresPorNombre() {
        ArrayList<Lugar> actual = consultas.consultaLugaresPorNombre(lugares, "REstaurante");
        assertThat(actual, contains(
                hasProperty("nombre", is("Restaurante Viejo Juancho")),
                hasProperty("nombre", is("Restaurante El Naranjal")),
                hasProperty("nombre", is("Restaurante Molino Viejo"))
        ));
    }

    @Test
    public void consultaEventosPorNombre() {
        ArrayList<Evento> actual = consultas.consultaEventosPorNombre(eventos, "PROMO");
        assertThat(actual, contains(
                hasProperty("nombre", is("Promocion")),
                hasProperty("nombre", is("Promocion 2x1")),
                hasProperty("nombre", is("PROMO"))
        ));
    }
}