package com.guideme.application.android;

import com.guideme.application.android.utils.ControladorFechas;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class ControladorFechasTest {

    private ControladorFechas controladorFechas;

    @Before
    public void setUp() throws Exception {
        controladorFechas = new ControladorFechas();
    }

    @After
    public void tearDown() throws Exception {
        controladorFechas = null;
    }

    @Test
    public void getDiaSemana() {
        assertEquals("Lunes", controladorFechas.getDiaSemana(2));
    }

    @Test
    public void getMesInicial() {
        assertEquals("FEB", controladorFechas.getMesInicial(2));
    }

    @Test
    public void getMes() {
        assertEquals("Febrero", controladorFechas.getMes(2));
    }

    @Test
    public void getDate() {
        assertEquals("2019-07-06", controladorFechas.getDate());
    }

    @Test
    public void obtenerFecha() {
        String res[] = {"MAR", "Viernes", "22"};
        assertArrayEquals(res, controladorFechas.obtenerFecha("2019-03-22"));
    }

    @Test
    public void esMayordeEdadTrue() {
        assertEquals(true, controladorFechas.esMayordeEdad("2001-03-19"));
    }

    @Test
    public void esMayordeEdadFalse() {
        assertEquals(false, controladorFechas.esMayordeEdad("2001-07-08"));
    }

    @Test
    public void esMayordeEdadTrueMayorde18() {
        assertEquals(true, controladorFechas.esMayordeEdad("1999-03-19"));
    }

    @Test
    public void esMayordeEdadFalseMenorde17() {
        assertEquals(false, controladorFechas.esMayordeEdad("2002-03-21"));
    }
}