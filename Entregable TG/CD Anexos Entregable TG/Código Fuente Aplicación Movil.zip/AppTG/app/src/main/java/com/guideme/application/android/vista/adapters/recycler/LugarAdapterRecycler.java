package com.guideme.application.android.vista.adapters.recycler;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RatingBar;
import android.widget.TextView;

import com.guideme.application.android.R;
import com.guideme.application.android.modelo.Lugar;
import com.guideme.application.android.modelo.Usuario;
import com.guideme.application.android.utils.Alerts;
import com.guideme.application.android.utils.ControladorFechas;
import com.guideme.application.android.vista.activities.DetallesLugarActivity;
import com.guideme.application.android.vista.fragments.GlideApp;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;

public class LugarAdapterRecycler extends RecyclerView.Adapter<LugarAdapterRecycler.LugarHolder> {

    private Context context;
    private ArrayList<Lugar> lugares;
    private Usuario usuario;
    private String key;

    public LugarAdapterRecycler(Context context, ArrayList<Lugar> lugares, Usuario usuario, String key) {
        this.context = context;
        this.lugares = lugares;
        this.usuario = usuario;
        this.key = key;
    }

    @NonNull
    @Override
    public LugarHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.cardview_lugar_detalles, parent, false);
        return new LugarHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull LugarHolder holder, int position) {
        position = holder.getAdapterPosition();
        FirebaseStorage firebaseStorage = FirebaseStorage.getInstance();
        StorageReference storageReference = firebaseStorage.getReferenceFromUrl(lugares.get(position).getFoto().get(0));

        GlideApp.with(context)
                .load(storageReference)
                .into(holder.imagen);

        holder.rbrating.setRating(lugares.get(position).getRating());
        holder.txtdescripcion.setText(lugares.get(position).getDescripcion());
        holder.txtlugar.setText(lugares.get(position).getMunicipio());
        holder.txtnombre.setText(lugares.get(position).getNombre());
        holder.txtdireccion.setText(lugares.get(position).getDireccion());

        final int finalPosition = position;
        holder.imagen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ControladorFechas controladorFechas = new ControladorFechas();
                if (!controladorFechas.esMayordeEdad(usuario.getFecha())&&
                        lugares.get(finalPosition).getCategoria() == 1){
                    Alerts alerts = new Alerts(context);
                    alerts.menorDeEdadAlert();
                }else {
                    Intent intent = new Intent(context, DetallesLugarActivity.class);
                    Bundle bundle = new Bundle();
                    bundle.putSerializable("lugar", lugares.get(finalPosition));
                    bundle.putSerializable("usuario", usuario);
                    bundle.putString("key", key);
                    intent.putExtras(bundle);
                    context.startActivity(intent);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return lugares.size();
    }

    public void setFilter(ArrayList<Lugar> lugaresFiltrados) {
        lugares = new ArrayList<>();
        lugares.addAll(lugaresFiltrados);
        notifyDataSetChanged();
    }

    class LugarHolder extends RecyclerView.ViewHolder {
        ImageView imagen;
        TextView txtnombre;
        TextView txtlugar;
        TextView txtdescripcion;
        TextView txtdireccion;
        LinearLayout linearLayout;
        ProgressBar progressBar;

        RatingBar rbrating;

        LugarHolder(View itemView) {
            super(itemView);

            linearLayout = itemView.findViewById(R.id.linearlayout);
            progressBar = itemView.findViewById(R.id.progressBar);
            linearLayout.setVisibility(View.VISIBLE);
            progressBar.setVisibility(View.GONE);
            imagen = itemView.findViewById(R.id.imageCardDetail);
            imagen.setVisibility(View.VISIBLE);
            txtnombre = itemView.findViewById(R.id.placenameCardDetail);
            txtlugar = itemView.findViewById(R.id.lugarDetail);
            txtdescripcion = itemView.findViewById(R.id.detalleslugarcardDetail);
            txtdireccion = itemView.findViewById(R.id.direccionDetail);
            rbrating = itemView.findViewById(R.id.ratingCardPlaceDetailsDetail);

        }
    }
}
