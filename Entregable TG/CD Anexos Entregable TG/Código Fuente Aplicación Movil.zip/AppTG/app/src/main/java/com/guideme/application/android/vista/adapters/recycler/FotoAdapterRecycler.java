package com.guideme.application.android.vista.adapters.recycler;

import android.content.Context;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.guideme.application.android.R;
import com.guideme.application.android.vista.dialog.ImageDialog;
import com.guideme.application.android.vista.fragments.GlideApp;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;

public class FotoAdapterRecycler extends RecyclerView.Adapter<FotoAdapterRecycler.FotoViewHolder> {

    private ArrayList<String> fotos;
    private Context context;
    private FirebaseStorage firebaseStorage;


    public FotoAdapterRecycler(ArrayList<String> fotos, Context context) {
        this.fotos = fotos;
        this.context = context;
        firebaseStorage = FirebaseStorage.getInstance();
    }

    @NonNull
    @Override
    public FotoViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.cardview_fotos, parent, false);
        return new FotoViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull FotoViewHolder holder, int position) {
        position = holder.getAdapterPosition();
        StorageReference storageReference;
        try {
            storageReference = firebaseStorage.getReferenceFromUrl(fotos.get(position));
            GlideApp.with(context)
                    .load(storageReference)
                    .into(holder.imagen);
        } catch (Exception e) {
            Uri path = Uri.parse(fotos.get(position));
            holder.imagen.setImageURI(path);
        }
        final int finalPosition = position;
        holder.imagen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new ImageDialog(context, fotos.get(finalPosition));
            }
        });
    }

    @Override
    public int getItemCount() {
        return fotos.size();
    }

    static class FotoViewHolder extends RecyclerView.ViewHolder {

        private ImageView imagen;

        FotoViewHolder(View itemView) {
            super(itemView);
            imagen = itemView.findViewById(R.id.image);
        }
    }
}
