package com.guideme.application.android.vista.activities;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.design.widget.Snackbar;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;

import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GetTokenResult;
import com.guideme.application.android.R;
import com.guideme.application.android.modelo.Preferencia;
import com.guideme.application.android.modelo.Usuario;
import com.guideme.application.android.utils.Alerts;
import com.guideme.application.android.utils.Constants;
import com.guideme.application.android.vista.adapters.slides.SlideFragmentAdapter;
import com.guideme.application.android.vista.fragments.EventFragment;
import com.guideme.application.android.vista.fragments.FavoriteFragment;
import com.guideme.application.android.vista.fragments.HomeFragment;
import com.guideme.application.android.vista.fragments.ProfileFragment;
import com.guideme.application.android.vista.fragments.SearchFragment;

import java.util.Objects;

public class ContainerActivity extends AppCompatActivity implements GoogleApiClient.OnConnectionFailedListener {

    private int default_tab = R.id.home;
    private int currentItem = 0;
    private Usuario usuario;
    private Preferencia preferencia;

    private GoogleApiClient googleApiClient;
    private FirebaseAuth firebaseAuth;
    private FirebaseAuth.AuthStateListener firebaseAuthListener;
    FirebaseUser user;
    private ViewPager viewPager;
    private SwipeRefreshLayout swipeRefreshLayout;
    public String key = "";

    private View cContainer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_container);

        firebaseAuth = FirebaseAuth.getInstance();
        user = firebaseAuth.getCurrentUser();

        ProgressDialog progressDialog = new ProgressDialog(ContainerActivity.this);
        progressDialog.setMessage("Cargando Datos de Usuario");

        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();

        cContainer = findViewById(R.id.cContainer);

        //BottomBar bottomBar = findViewById(R.id.bottombar);
        final BottomNavigationView bottomBar = findViewById(R.id.bottomBar);
        swipeRefreshLayout = findViewById(R.id.refreshContainer);
        viewPager = findViewById(R.id.viewPager);

        bottomBar.setVisibility(View.GONE);
        final Alerts alerts = new Alerts(this);

        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .build();

        googleApiClient = new GoogleApiClient.Builder(this)
                .enableAutoManage(this, this)
                .addApi(Auth.GOOGLE_SIGN_IN_API, gso)
                .build();
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                if (alerts.isConnected()) {
                    if (user != null) {
                        user.getIdToken(true)
                                .addOnCompleteListener(new OnCompleteListener<GetTokenResult>() {
                                    public void onComplete(@NonNull Task<GetTokenResult> task) {
                                        if (task.isSuccessful()) {
                                            key = Objects.requireNonNull(task.getResult()).getToken();
                                            viewPager.setAdapter(slideFragmentAdapter());
                                            viewPager.setCurrentItem(currentItem);
                                            swipeRefreshLayout.setRefreshing(false);
                                        } else {
                                            swipeRefreshLayout.setRefreshing(false);
                                        }
                                    }
                                });
                    }
                } else {
                    swipeRefreshLayout.setRefreshing(false);
                }

            }
        });


        viewPager.setAdapter(slideFragmentAdapter());
        viewPager.setOffscreenPageLimit(4);

        if (savedInstanceState != null) {
            default_tab = savedInstanceState.getInt(Constants.DEFAULT_TAB);
            usuario = (Usuario) savedInstanceState.getSerializable("usuario");
            preferencia = (Preferencia) savedInstanceState.getSerializable("preferencia");
            key = savedInstanceState.getString("key");
        } else {
            usuario = (Usuario) (bundle != null ? bundle.getSerializable("usuario") : null);
            key = bundle != null ? bundle.getString("key") : null;
        }

        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                switch (position) {
                    case 0:
                        default_tab = R.id.home;
                        currentItem = 0;
                        bottomBar.setSelectedItemId(R.id.home);
                        swipeRefreshLayout.setEnabled(true);
                        break;
                    case 1:
                        default_tab = R.id.buscar;
                        currentItem = 1;
                        bottomBar.setSelectedItemId(R.id.buscar);
                        swipeRefreshLayout.setEnabled(true);
                        break;
                    case 2:
                        default_tab = R.id.favoritos;
                        currentItem = 2;
                        bottomBar.setSelectedItemId(R.id.favoritos);
                        swipeRefreshLayout.setEnabled(true);
                        break;
                    case 3:
                        default_tab = R.id.eventos;
                        currentItem = 3;
                        bottomBar.setSelectedItemId(R.id.eventos);
                        swipeRefreshLayout.setEnabled(true);
                        break;
                    case 4:
                        default_tab = R.id.profile;
                        currentItem = 4;
                        bottomBar.setSelectedItemId(R.id.profile);
                        swipeRefreshLayout.setEnabled(false);
                        break;
                }
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });

        bottomBar.setVisibility(View.VISIBLE);
        bottomBar.setSelectedItemId(default_tab);

        bottomBar.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.home:
                        default_tab = R.id.home;
                        currentItem = 0;
                        viewPager.setCurrentItem(currentItem);
                        swipeRefreshLayout.setEnabled(true);
                        break;
                    case R.id.buscar:
                        default_tab = R.id.buscar;
                        currentItem = 1;
                        viewPager.setCurrentItem(currentItem);
                        swipeRefreshLayout.setEnabled(true);
                        break;
                    case R.id.favoritos:
                        default_tab = R.id.favoritos;
                        currentItem = 2;
                        viewPager.setCurrentItem(currentItem);
                        swipeRefreshLayout.setEnabled(true);
                        break;
                    case R.id.eventos:
                        default_tab = R.id.eventos;
                        currentItem = 3;
                        viewPager.setCurrentItem(currentItem);
                        swipeRefreshLayout.setEnabled(true);
                        break;
                    case R.id.profile:
                        default_tab = R.id.profile;
                        currentItem = 4;
                        viewPager.setCurrentItem(currentItem);
                        swipeRefreshLayout.setEnabled(false);
                        break;
                }
                return true;
            }
        });
        //cargarPreferencias();
    }

    private SlideFragmentAdapter slideFragmentAdapter() {
        SlideFragmentAdapter slideFragmentAdapter = new SlideFragmentAdapter(getSupportFragmentManager());

        slideFragmentAdapter.agregarFragment(new HomeFragment());
        slideFragmentAdapter.agregarFragment(new SearchFragment());
        slideFragmentAdapter.agregarFragment(new FavoriteFragment());
        slideFragmentAdapter.agregarFragment(new EventFragment());
        slideFragmentAdapter.agregarFragment(new ProfileFragment());

        return slideFragmentAdapter;
    }


    /*private void cargarPreferencias() {
        String url = Constants.URL + Constants.URL_PREFERENCIAS_API + Constants.CONSULTA_USUARIOS
                + usuario.getUid();
        //System.out.println(url);

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        final JsonObjectRequest jsonArrayRequest = new JsonObjectRequest(Request.Method.GET, url,
                null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {
                    preferencia = new Preferencia(response);

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                crearPreferencia();
                Log.e("Verror", error.toString());
            }
        }) {
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> params = new HashMap<>();
                params.put("Content-Type", "application/json; charset=UTF-8");
                params.put("Authorization", key);
                return params;
            }
        };
        jsonArrayRequest.setRetryPolicy(new DefaultRetryPolicy(
                DefaultRetryPolicy.DEFAULT_TIMEOUT_MS * 3,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        requestQueue.add(jsonArrayRequest);

    }

    private void crearPreferencia() {
        try {
            preferencia = new Preferencia(0, usuario, new ArrayList<Tag>());

            RequestQueue requestQueue = Volley.newRequestQueue(this);
            JSONObject jsonBody = preferencia.getJSONPreferencia();

            final String mRequestBody = jsonBody.toString();
            System.out.println("---> " + mRequestBody);
            System.out.println(jsonBody.toString());

            StringRequest stringRequest = new StringRequest(Request.Method.POST, Constants.URL
                    + Constants.URL_PREFERENCIAS_API, new Response.Listener<String>() {

                @Override
                public void onResponse(String response) {
                    System.out.println(response);
                    cargarPreferencias();
                }
            }, new Response.ErrorListener() {

                @Override
                public void onErrorResponse(VolleyError error) {
                    Log.d("error", error.toString());
                }
            }) {
                @Override
                public Map<String, String> getHeaders() {
                    Map<String, String> params = new HashMap<>();
                    params.put("Content-Type", "application/json; charset=UTF-8");
                    params.put("Authorization", key);
                    return params;
                }

                @Override
                public String getBodyContentType() {
                    return "application/json; charset=utf-8";
                }

                @Override
                public byte[] getBody() {
                    return mRequestBody == null ? null : mRequestBody.getBytes(StandardCharsets.UTF_8);
                }

                @Override
                protected Response<String> parseNetworkResponse(NetworkResponse response) {
                    String responseString = "";
                    if (response != null) {
                        responseString = String.valueOf(response.statusCode);
                    }
                    return Response.success(responseString, HttpHeaderParser.parseCacheHeaders(response));
                }
            };

            requestQueue.add(stringRequest);

        } catch (JSONException e) {
            //e.printStackTrace();
        }
    }*/


    public void onSaveInstanceState(Bundle savedInstanceState) {
        // Save the user's current game state
        savedInstanceState.putInt(Constants.DEFAULT_TAB, default_tab);
        savedInstanceState.putSerializable("usuario", usuario);
        savedInstanceState.putSerializable("preferencia", preferencia);
        savedInstanceState.putString("key", key);

        // Always call the superclass so it can save the view hierarchy state
        super.onSaveInstanceState(savedInstanceState);
    }

    public void onRestoreInstanceState(Bundle savedInstanceState) {
        // Always call the superclass so it can restore the view hierarchy
        super.onRestoreInstanceState(savedInstanceState);

        // Restore state members from saved instance
        default_tab = savedInstanceState.getInt(Constants.DEFAULT_TAB);
        usuario = (Usuario) savedInstanceState.getSerializable("usuario");
        key = savedInstanceState.getString("key");
        preferencia = (Preferencia) savedInstanceState.getSerializable("preferencia");
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public Preferencia getPreferencia() {
        return preferencia;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public String getKey() {
        return key;
    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    public void logOut() {
        AlertDialog alertDialog;
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Confirmar");
        builder.setMessage("¿Desea salir de la aplicación?");
        builder.setPositiveButton("Si", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                firebaseAuth.signOut();

                Auth.GoogleSignInApi.signOut(googleApiClient).setResultCallback(new ResultCallback<Status>() {
                    @Override
                    public void onResult(@NonNull Status status) {
                        if (status.isSuccess()) {
                            goLogInScreen();
                        } else {
                            Snackbar.make(cContainer, "No se pudo cerrar sesión",
                                    Snackbar.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        alertDialog = builder.create();
        alertDialog.show();
    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {
    }

    @Override
    protected void onStop() {
        super.onStop();

        if (firebaseAuthListener != null) {
            firebaseAuth.removeAuthStateListener(firebaseAuthListener);
        }
    }

    private void goLogInScreen() {
        Intent intent = new Intent(this, LoginActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK
                | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }

}
