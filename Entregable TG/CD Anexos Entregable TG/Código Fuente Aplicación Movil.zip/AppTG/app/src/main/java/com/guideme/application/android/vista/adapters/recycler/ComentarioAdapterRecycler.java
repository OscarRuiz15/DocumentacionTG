package com.guideme.application.android.vista.adapters.recycler;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RatingBar;
import android.widget.TextView;

import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.guideme.application.android.R;
import com.guideme.application.android.modelo.Comentario;
import com.guideme.application.android.utils.ControladorFechas;
import com.guideme.application.android.vista.fragments.GlideApp;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;

import de.hdodenhof.circleimageview.CircleImageView;

public class ComentarioAdapterRecycler extends RecyclerView.Adapter<ComentarioAdapterRecycler.ComentarioViewHolder> {

    private Context context;
    private ArrayList<Comentario> comentarios;
    private ControladorFechas controladorFechas = new ControladorFechas();
    private ArrayList<String> coments;

    public ComentarioAdapterRecycler(Context context, ArrayList<Comentario> comentarios) {
        this.context = context;
        this.comentarios = comentarios;

        /*for (int i = 0; i < comentarios.size(); i++) {
            System.out.println(comentarios.get(i).getFecha()+" "+comentarios.get(i).getHora()+" "+comentarios.get(i).getId());
        }*/

        ordenar();
    }

    @NonNull
    @Override
    public ComentarioViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.cardview_comentario, parent, false);
        return new ComentarioViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ComentarioViewHolder holder, int position) {
        holder.txtcomentario.setText(comentarios.get(position).getMensaje());
        holder.txtnombre.setText(comentarios.get(position).getUsuario().getNombre());
        holder.ratingBar.setRating(comentarios.get(position).getCalificacion());
        holder.txtfecha.setText(coments.get(position));

        try {
            FirebaseStorage firebaseStorage = FirebaseStorage.getInstance();
            StorageReference storageReference = firebaseStorage.getReferenceFromUrl(comentarios.get(position).getUsuario().getFoto());
            GlideApp.with(context)
                    .load(storageReference)
                    .into(holder.circleImageView);
        } catch (Exception e) {
            GlideApp.with(context)
                    .load(comentarios.get(position).getUsuario().getFoto())
                    .into(holder.circleImageView);
        }
    }

    @Override
    public int getItemCount() {
        return comentarios.size();
    }

    class ComentarioViewHolder extends RecyclerView.ViewHolder {
        CircleImageView circleImageView;
        TextView txtnombre;
        RatingBar ratingBar;
        TextView txtcomentario;
        TextView txtfecha;

        ComentarioViewHolder(View itemView) {
            super(itemView);
            circleImageView = itemView.findViewById(R.id.image_user_comment);
            txtnombre = itemView.findViewById(R.id.name_user_comment);
            ratingBar = itemView.findViewById(R.id.ratingCardPlaceComment);
            txtcomentario = itemView.findViewById(R.id.commentComentario);
            txtfecha = itemView.findViewById(R.id.fecha_comentario);
        }
    }

    private ArrayList<Long> getDiferencia(Date fechaInicial, Date fechaFinal) {

        ArrayList<Long> total_diferencia = new ArrayList<>();

        long diferencia = fechaFinal.getTime() - fechaInicial.getTime();

        long segsMilli = 1000;
        long minsMilli = segsMilli * 60;
        long horasMilli = minsMilli * 60;
        long diasMilli = horasMilli * 24;
        long weekMilli = diasMilli * 7;
        long mesMilli = weekMilli * 4;
        long yearMilli = mesMilli * 12;

        long yearsTranscurridos = diferencia / yearMilli;
        diferencia = diferencia % yearMilli;

        long mesesTranscurridos = diferencia / mesMilli;
        diferencia = diferencia % mesMilli;

        long semanasTranscurridas = diferencia / weekMilli;
        diferencia = diferencia % weekMilli;

        long diasTranscurridos = diferencia / diasMilli;
        diferencia = diferencia % diasMilli;

        long horasTranscurridos = diferencia / horasMilli;
        diferencia = diferencia % horasMilli;

        long minutosTranscurridos = diferencia / minsMilli;
        diferencia = diferencia % minsMilli;

        long segsTranscurridos = diferencia / segsMilli;

        total_diferencia.add(yearsTranscurridos);
        total_diferencia.add(mesesTranscurridos);
        total_diferencia.add(semanasTranscurridas);
        total_diferencia.add(diasTranscurridos);
        total_diferencia.add(horasTranscurridos);
        total_diferencia.add(minutosTranscurridos);
        total_diferencia.add(segsTranscurridos);


        return total_diferencia;

    }

    public void ordenar() {
        //Collections.reverse(comentarios);

        Comparator<Comentario> comparator = new Comparator<Comentario>() {
            @Override
            public int compare(Comentario left, Comentario right) {
                SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
                ControladorFechas controladorFechas = new ControladorFechas();

                Date der = null;
                Date izq = null;
                try {
                    der = format.parse(right.getFecha()+ "T" +right.getHora()+ "Z");
                    izq = format.parse(left.getFecha()+ "T" +left.getHora()+ "Z");
                } catch (ParseException e) {
                    e.printStackTrace();
                }

                return der.compareTo(izq);
            }
        };

        Collections.sort(comentarios, comparator);

        /*System.out.println("==================");
        for (int i = 0; i < comentarios.size(); i++) {
            System.out.println(comentarios.get(i).getFecha() + " " + comentarios.get(i).getHora() + " " + comentarios.get(i).getId());
        }*/
        coments = new ArrayList<>();
        ArrayList<Long> diferencia;
        Date date;
        Date date_actual;
        String fecha;
        String fecha_actual = controladorFechas.getDate() + "T" + controladorFechas.getHour() + "Z";

        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");

        for (int i = 0; i < comentarios.size(); i++) {
            try {
                fecha = comentarios.get(i).getFecha() + "T" + comentarios.get(i).getHora() + "Z";
                date = format.parse(fecha);
                date_actual = format.parse(fecha_actual);
                diferencia = getDiferencia(date, date_actual);

                //0-> Años, 1-> Meses, 2-> Semanas, 3-> Dias, 4-> Horas, 5-> Minutos, 6-> Segundos
                if (diferencia.get(0) != 0) {
                    if (diferencia.get(0) == 1) {
                        coments.add("Hace " + diferencia.get(0) + " año");
                    } else {
                        coments.add("Hace " + diferencia.get(0) + " años");
                    }

                } else if (diferencia.get(1) != 0) {
                    if (diferencia.get(1) == 1) {
                        coments.add("Hace " + diferencia.get(1) + " mes");
                    } else {
                        coments.add("Hace " + diferencia.get(1) + " meses");
                    }
                } else if (diferencia.get(2) != 0) {
                    if (diferencia.get(2) == 1) {
                        coments.add("Hace " + diferencia.get(2) + " semana");
                    } else {
                        coments.add("Hace " + diferencia.get(2) + " semanas");
                    }
                } else if (diferencia.get(3) != 0) {
                    if (diferencia.get(3) == 1) {
                        coments.add("Ayer");
                    } else {
                        coments.add("Hace " + diferencia.get(3) + " dias");
                    }
                } else if (diferencia.get(4) != 0) {
                    if (diferencia.get(4) == 1) {
                        coments.add("Hace " + diferencia.get(4) + " hora");
                    } else {
                        coments.add("Hace " + diferencia.get(4) + " horas");
                    }
                } else if (diferencia.get(5) != 0) {
                    if (diferencia.get(5) == 1) {
                        coments.add("Hace " + diferencia.get(5) + " minuto");
                    } else {
                        coments.add("Hace " + diferencia.get(5) + " minutos");
                    }
                } else {
                    if (diferencia.get(6) == 1) {
                        coments.add("Hace " + diferencia.get(6) + " segundo");
                    } else {
                        coments.add("Hace " + diferencia.get(6) + " segundos");
                    }
                }

                /*if (diferencia.get(0) != 0) {
                    coments.add("Hace " + diferencia.get(0) + " dias");
                } else {
                    if (diferencia.get(1) != 0) {
                        coments.add("Hace " + diferencia.get(1) + " horas");
                    } else {
                        coments.add("Hace " + diferencia.get(2) + " minutos");
                    }
                }*/

            } catch (ParseException e) {
                //e.printStackTrace();
            }
        }
    }

}
