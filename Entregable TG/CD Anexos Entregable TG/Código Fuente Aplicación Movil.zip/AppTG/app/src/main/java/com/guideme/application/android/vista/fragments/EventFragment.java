package com.guideme.application.android.vista.fragments;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.SearchView;
import android.widget.TextView;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.guideme.application.android.utils.Constants;
import com.guideme.application.android.utils.Consultas;
import com.guideme.application.android.R;
import com.guideme.application.android.modelo.Evento;
import com.guideme.application.android.modelo.Usuario;
import com.guideme.application.android.vista.adapters.recycler.EventoAdapterRecycler;
import com.guideme.application.android.vista.activities.ActionBar;
import com.guideme.application.android.vista.activities.ContainerActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class EventFragment extends Fragment {

    private RecyclerView recyclerView;
    private TextView tvNotFound;
    private EventoAdapterRecycler eventoAdapterRecycler;
    private ProgressBar progressBar;
    private ArrayList<Evento> eventos;
    private Consultas consultas;

    private Usuario usuario;
    private String key;

    public EventFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_event, container, false);
        SearchView searchView = view.findViewById(R.id.search_view_event);
        recyclerView = view.findViewById(R.id.recyclerEvent);
        progressBar = view.findViewById(R.id.progressBar);
        tvNotFound = view.findViewById(R.id.tvNotFound);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(linearLayoutManager);
        eventos = new ArrayList<>();
        consultas = new Consultas();

        usuario = ((ContainerActivity) Objects.requireNonNull(getActivity())).getUsuario();
        key = ((ContainerActivity) getActivity()).getKey();

        ActionBar actionBar = new ActionBar();
        actionBar.showToolbar("Eventos", false, getActivity(), view);

        obtenerEventos();

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                if (!eventos.isEmpty()) {
                    ArrayList<Evento> eventosFiltrados = consultas.consultaEventosPorNombre(eventos, newText);
                    eventoAdapterRecycler.setFilter(eventosFiltrados);
                    if (eventosFiltrados.isEmpty()) {
                        tvNotFound.setVisibility(View.VISIBLE);
                    } else {
                        tvNotFound.setVisibility(View.GONE);
                    }
                }
                return false;
            }
        });
        searchView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            }
        });
        return view;
    }

    public void obtenerEventos() {
        String url = Constants.URL + Constants.URL_EVENTOS_API;

        RequestQueue requestQueue = Volley.newRequestQueue(Objects.requireNonNull(getContext()));
        final JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, url, null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                JSONObject jsonObject;
                for (int i = 0; i < response.length(); i++) {
                    try {
                        jsonObject = response.getJSONObject(i);
                        Evento evento = new Evento(jsonObject);
                        eventos.add(evento);
                    } catch (JSONException e) {
                        //e.printStackTrace();
                    }
                }

                progressBar.setVisibility(View.GONE);
                if (!eventos.isEmpty()) {
                    recyclerView.setVisibility(View.VISIBLE);
                    eventoAdapterRecycler = new EventoAdapterRecycler(getActivity(), eventos, usuario, key);
                    recyclerView.setAdapter(eventoAdapterRecycler);
                } else {
                    tvNotFound.setVisibility(View.VISIBLE);
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                tvNotFound.setVisibility(View.VISIBLE);
            }
        }) {
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> params = new HashMap<>();
                params.put("Content-Type", "application/json; charset=UTF-8");
                params.put("Authorization", key);
                return params;
            }
        };
        jsonArrayRequest.setRetryPolicy(new DefaultRetryPolicy(
                DefaultRetryPolicy.DEFAULT_TIMEOUT_MS * 3,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        requestQueue.add(jsonArrayRequest);
    }


}
