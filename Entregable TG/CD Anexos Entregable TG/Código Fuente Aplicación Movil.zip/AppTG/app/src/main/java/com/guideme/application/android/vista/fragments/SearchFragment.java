package com.guideme.application.android.vista.fragments;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.SearchView;
import android.widget.TextView;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.guideme.application.android.utils.Constants;
import com.guideme.application.android.utils.Consultas;
import com.guideme.application.android.utils.Operaciones;
import com.guideme.application.android.R;
import com.guideme.application.android.modelo.Categoria;
import com.guideme.application.android.modelo.Lugar;
import com.guideme.application.android.modelo.Usuario;
import com.guideme.application.android.vista.adapters.recycler.CategoryGridAdapter;
import com.guideme.application.android.vista.adapters.recycler.LugarAdapterRecycler;
import com.guideme.application.android.vista.activities.ActionBar;
import com.guideme.application.android.vista.activities.ContainerActivity;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class SearchFragment extends Fragment {

    private RecyclerView recyclerView;
    private RecyclerView recyclerViewPlace;
    private CategoryGridAdapter categoryGridAdapter;
    private ArrayList<Categoria> categorias;
    private Usuario usuario;
    private SearchView searchView;
    private TextView tvNotFound;
    private ArrayList<Lugar> lugares;
    private LugarAdapterRecycler lugarAdapterRecycler;
    LinearLayoutManager linearLayoutManager;
    private String key;
    private Consultas consultas;
    private boolean isCreated = false;

    public SearchFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_search, container, false);
        recyclerView = view.findViewById(R.id.recyclerCategorySearch);
        recyclerViewPlace = view.findViewById(R.id.recyclerPlace);
        linearLayoutManager = new LinearLayoutManager(getActivity());
        tvNotFound = view.findViewById(R.id.tvNotFound);
        recyclerViewPlace.setLayoutManager(linearLayoutManager);
        recyclerViewPlace.setVisibility(View.GONE);

        isCreated = true;

        key = ((ContainerActivity) Objects.requireNonNull(getActivity())).getKey();
        consultas = new Consultas();

        ActionBar actionBar = new ActionBar();
        actionBar.showToolbar("Buscar", false, getActivity(), view);
        categorias = new ArrayList<>();
        usuario = ((ContainerActivity) getActivity()).getUsuario();
        lugares = new ArrayList<>();

        getCategoriasVolley();
        getLugaresVolley();

        searchView = view.findViewById(R.id.searchview_search);
        searchView.setVisibility(View.GONE);
        searchView.setOnQueryTextListener(new android.widget.SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {

                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                ArrayList<Lugar> lugaresFiltrados = consultas.consultaLugaresPorNombre(lugares, newText);

                if (!lugaresFiltrados.isEmpty()) {
                    lugarAdapterRecycler.setFilter(lugaresFiltrados);
                    if (newText.equals("")) {
                        recyclerViewPlace.setVisibility(View.GONE);
                        recyclerView.setVisibility(View.VISIBLE);
                    } else {
                        recyclerViewPlace.setVisibility(View.VISIBLE);
                        recyclerView.setVisibility(View.GONE);
                        if (lugaresFiltrados.isEmpty()) {
                            tvNotFound.setVisibility(View.VISIBLE);
                        } else {
                            tvNotFound.setVisibility(View.GONE);
                        }
                    }
                }

                return false;
            }
        });
        searchView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            }
        });

        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        if (!isCreated){
            getCategoriasVolley();
            getLugaresVolley();
        }
    }

    private void getCategoriasVolley() {
        recyclerViewPlace.setVisibility(View.GONE);
        recyclerView.setVisibility(View.VISIBLE);

        String url = Constants.URL + Constants.URL_CATEGORIAS_API;
        RequestQueue requestQueue = Volley.newRequestQueue(Objects.requireNonNull(getContext()));
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, url, null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                for (int i = 0; i < response.length(); i++) {
                    try {
                        Categoria categoria = new Categoria(response.getJSONObject(i));
                        //System.out.println(categoria.toString());
                        categorias.add(categoria);
                        //Toast.makeText(getContext(), "Lugar " + i, Toast.LENGTH_LONG).show();
                    } catch (JSONException e) {
                        //e.printStackTrace();
                    }
                }
                GridLayoutManager gridLayoutManager = new GridLayoutManager(getActivity(), 3);
                categoryGridAdapter = new CategoryGridAdapter(getActivity(), categorias, usuario, key);
                recyclerView.setLayoutManager(gridLayoutManager);
                recyclerView.setAdapter(categoryGridAdapter);

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }) {
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> params = new HashMap<>();
                params.put("Content-Type", "application/json; charset=UTF-8");
                params.put("Authorization", key);
                return params;
            }
        };
        jsonArrayRequest.setRetryPolicy(new DefaultRetryPolicy(
                DefaultRetryPolicy.DEFAULT_TIMEOUT_MS * 3,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        requestQueue.add(jsonArrayRequest);

    }

    public void getLugaresVolley() {
        String url = Constants.URL + Constants.URL_LUGARES_API;
        final Operaciones operaciones = new Operaciones();
        RequestQueue requestQueue = Volley.newRequestQueue(Objects.requireNonNull(getContext()));
        final JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, url, null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                for (int i = 0; i < response.length(); i++) {
                    try {
                        Lugar lugar = new Lugar(response.getJSONObject(i));
                        lugar.setRating(operaciones.calcularCalificacion(lugar.getComentarios()));
                        lugares.add(lugar);
                    } catch (JSONException e) {
                        //e.printStackTrace();
                    }

                }
                searchView.setVisibility(View.VISIBLE);
                //recyclerView.setVisibility(View.GONE);
                //recyclerViewPlace.setVisibility(View.VISIBLE);
                lugarAdapterRecycler = new LugarAdapterRecycler(getActivity(), lugares, usuario, key);
                recyclerViewPlace.setAdapter(lugarAdapterRecycler);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }) {
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> params = new HashMap<>();
                params.put("Content-Type", "application/json; charset=UTF-8");
                params.put("Authorization", key);
                return params;
            }
        };
        jsonArrayRequest.setRetryPolicy(new DefaultRetryPolicy(
                DefaultRetryPolicy.DEFAULT_TIMEOUT_MS * 3,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        requestQueue.add(jsonArrayRequest);

    }
}
