package com.guideme.application.android.modelo;

import org.json.JSONException;
import org.json.JSONObject;

public class Categoria {
    private int id;
    private String nombre;
    private String descripcion;
    private String foto;

    public Categoria(JSONObject jsonObject) throws JSONException {
        //System.out.println(jsonObject.toString());
        this.id = jsonObject.getInt("id");
        this.nombre = jsonObject.getString("nombre");
        this.descripcion = jsonObject.getString("descripcion");
        this.foto = jsonObject.getString("foto");
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFoto() {
        return foto;
    }

    public void setFoto(String foto) {
        this.foto = foto;
    }

    @Override
    public String toString() {
        return "Categoria{" +
                "id=" + id +
                ", nombre='" + nombre + '\'' +
                ", foto='" + foto + '\'' +
                '}';
    }
}
