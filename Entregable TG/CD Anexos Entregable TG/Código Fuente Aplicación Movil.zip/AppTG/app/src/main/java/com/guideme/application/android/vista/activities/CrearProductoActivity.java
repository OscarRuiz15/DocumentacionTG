package com.guideme.application.android.vista.activities;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v4.app.NavUtils;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.guideme.application.android.utils.Alerts;
import com.guideme.application.android.utils.Constants;
import com.guideme.application.android.R;
import com.guideme.application.android.utils.ValidarTextos;
import com.guideme.application.android.modelo.Lugar;
import com.guideme.application.android.modelo.Producto;
import com.guideme.application.android.modelo.Usuario;

import org.json.JSONException;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class CrearProductoActivity extends AppCompatActivity {

    private Context context = this;
    private ImageView imagen;
    private EditText etnombre;
    private EditText etdescripcion;
    private EditText etprecio;
    private Button btnCrear;
    private StorageReference storageReference;
    private Uri getAbsolutePhotoPath;
    private AlertDialog alertDialog;
    private AlertDialog errorAlertDialog;

    private Lugar lugar;
    private Usuario usuario;
    private String key;

    private static int FOTO_DE_GALERIA = 10;
    // private static int TOMAR_FOTO = 20;

    // private Bitmap bitmap;
    // private String path;
    // private File fileImagen;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crear_producto);
        imagen = findViewById(R.id.imagenProducto);
        etnombre = findViewById(R.id.editTextNombre);
        etdescripcion = findViewById(R.id.editTextDescripcion);
        etprecio = findViewById(R.id.editTextPrecio);
        btnCrear = findViewById(R.id.btnCrearProducto);

        etprecio.addTextChangedListener(onTextChangedListener(etprecio));

        FirebaseStorage storage = FirebaseStorage.getInstance();
        storageReference = storage.getReferenceFromUrl(Constants.FIREBASE_STORAGE_URL_PRODUCTOS);

        ActionBar actionBar = new ActionBar();
        actionBar.showToolbar("Crear nuevo producto", true, this);

        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        if (savedInstanceState != null) {
            lugar = (Lugar) savedInstanceState.getSerializable("lugar");
            usuario = (Usuario) savedInstanceState.getSerializable("usuario");
            key = savedInstanceState.getString("key");
        } else {
            lugar = (Lugar) (bundle != null ? bundle.getSerializable("lugar") : null);
            usuario = (Usuario) (bundle != null ? bundle.getSerializable("usuario") : null);
            key = bundle != null ? bundle.getString("key") : null;
        }

        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Producto creado ");
        builder.setMessage("El producto ha sido creado con éxito. ¿Desea seguir creando productos?");
        builder.setPositiveButton("SI", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                imagen.setImageResource(R.drawable.img_unavaliable);
                getAbsolutePhotoPath = null;
                etdescripcion.setText("");
                etnombre.setText("");
                etprecio.setText("");
            }
        });
        builder.setNegativeButton("NO", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                irDetallesLugar();
            }
        });
        alertDialog = builder.create();

        btnCrear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    crearProducto();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        });

    }

    @Override
    protected void onSaveInstanceState(Bundle savedInstanceState) {
        savedInstanceState.putSerializable("lugar", lugar);
        savedInstanceState.putSerializable("usuario", usuario);
        savedInstanceState.putString("key", key);

        super.onSaveInstanceState(savedInstanceState);
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);

        lugar = (Lugar) savedInstanceState.getSerializable("lugar");
        usuario = (Usuario) savedInstanceState.getSerializable("usuario");
        key = savedInstanceState.getString("key");
    }

    private TextWatcher onTextChangedListener(final EditText editText) {
        return new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                editText.removeTextChangedListener(this);

                try {
                    String originalString = s.toString();

                    long longval;
                    if (originalString.contains(" ")) {
                        originalString = originalString.replaceAll(" ", "");
                    }
                    longval = Long.parseLong(originalString);

                    DecimalFormat formatter = (DecimalFormat) NumberFormat.getInstance(Locale.US);
                    formatter.applyPattern("#,###,###,###");
                    String formattedString = formatter.format(longval);

                    //setting text after format to EditText
                    if (formattedString.contains(",")) {
                        formattedString = formattedString.replaceAll(",", " ");
                    }
                    editText.setText(formattedString);
                    editText.setSelection(editText.getText().length());
                } catch (NumberFormatException nfe) {
                    //nfe.printStackTrace();
                }

                editText.addTextChangedListener(this);
            }
        };
    }

    public void agregarImagen(View view) {
        //mostrarDialogoOpciones();
        agregarImagenGaleria();
    }

    /*private void mostrarDialogoOpciones() {
        final CharSequence[] opciones = {"Elegir foto de la galería", "Tomar foto", "Cancelar"};
        final AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Elige una opción");
        builder.setItems(opciones, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int i) {
                if (opciones[i].equals("Elegir foto de la galería")) {
                    agregarImagenGaleria();
                } else {
                    if (opciones[i].equals("Tomar foto")) {
                        tomarFoto();
                    } else {
                        dialog.dismiss();
                    }
                }
            }
        });
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }*/

    /*private void tomarFoto() {
        if (validarPermisos()) {
            File file = new File(Environment.getExternalStorageDirectory(), "GuideMe");
            boolean isCreated = file.exists();

            if (!isCreated) isCreated = file.mkdirs();

            if (isCreated) {
                Long consecutivo = System.currentTimeMillis() / 1000;
                String nombre = consecutivo.toString() + ".jpg";

                path = Environment.getExternalStorageDirectory() +
                        File.separator + "GuideMe" + File.separator + nombre;

                fileImagen = new File(path);

                Uri uri = FileProvider.getUriForFile(context,
                        "provider", fileImagen);

                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                intent.putExtra(MediaStore.EXTRA_OUTPUT, uri);

                startActivityForResult(intent, TOMAR_FOTO);
            }
        }
    }*/

    private void agregarImagenGaleria() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (inputMethodManager != null) {
            inputMethodManager.hideSoftInputFromWindow(etnombre.getWindowToken(), 0);
            inputMethodManager.hideSoftInputFromWindow(etdescripcion.getWindowToken(), 0);
            inputMethodManager.hideSoftInputFromWindow(etprecio.getWindowToken(), 0);
        }

        startActivityForResult(Intent.createChooser(intent, "Selecciona la Aplicación"), 10);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if (requestCode == FOTO_DE_GALERIA) {
                Uri path = data.getData();
                imagen.setImageURI(path);
                getAbsolutePhotoPath = path;
            }
            /*if (requestCode == TOMAR_FOTO) {
                MediaScannerConnection.scanFile(context, new String[]{path}, null,
                        new MediaScannerConnection.OnScanCompletedListener() {
                            @Override
                            public void onScanCompleted(String path, Uri uri) {

                            }
                        });
                bitmap = BitmapFactory.decodeFile(path);
                getAbsolutePhotoPath = Uri.fromFile(fileImagen);
                imagen.setImageBitmap(bitmap);

            }*/
        }
    }

    public void crearProducto() throws JSONException {
        Alerts alerts = new Alerts(context);
        if (alerts.isConnected()) {
            ValidarTextos validarTextos = new ValidarTextos();
            boolean nombrevalido = validarTextos.validateBlank(etnombre, this);
            boolean descripcionvalido = validarTextos.validateBlank(etdescripcion, this);
            boolean precioovalido = validarTextos.validateBlank(etprecio, this);

            if (nombrevalido && descripcionvalido && precioovalido) {
                String nombre = etnombre.getText().toString().trim();
                String descripcion = etdescripcion.getText().toString().trim();
                String precio = etprecio.getText().toString().trim();
                String urlfoto;

                if (getAbsolutePhotoPath != null) {
                    urlfoto = uploadPhoto(getAbsolutePhotoPath.getLastPathSegment());
                } else {
                    urlfoto = "gs://trabajo-de-grado-f9cb8.appspot.com/productos/imgperfil.png";
                }
                Producto producto = new Producto(nombre, descripcion, precio, urlfoto, lugar.getId());
                postProductoVolley(producto, alerts);
            }
        }
    }

    private void postProductoVolley(Producto producto, final Alerts alerts) throws JSONException {
        btnCrear.setEnabled(false);
        btnCrear.setBackgroundResource(R.color.darker_gray);
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        JSONObject jsonBody = producto.getJSONProducto();
        //System.out.println(lugar.getId());

        final String mRequestBody = jsonBody.toString();
        //System.out.println("JSON: " + mRequestBody);

        StringRequest stringRequest = new StringRequest(Request.Method.POST, Constants.URL + Constants.URL_PRODUCTOS_API, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                getLugarJSONVolley();
            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                int statusCode = error.networkResponse.statusCode;
                String mensaje = "No se pudo crear el producto";
                errorAlertDialog = alerts.createErrorAlert(statusCode, mensaje).create();
                errorAlertDialog.show();
                btnCrear.setEnabled(true);
                btnCrear.setBackgroundResource(R.color.colorPrimaryDark);
            }
        }) {
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> params = new HashMap<>();
                params.put("Content-Type", "application/json; charset=UTF-8");
                params.put("Authorization", key);
                return params;
            }

            @Override
            public String getBodyContentType() {
                return "application/json; charset=utf-8";
            }

            @Override
            public byte[] getBody() {
                return mRequestBody == null ? null : mRequestBody.getBytes(StandardCharsets.UTF_8);
            }

            @Override
            protected Response<String> parseNetworkResponse(NetworkResponse response) {
                String responseString = "";
                if (response != null) {
                    responseString = String.valueOf(response.statusCode);
                }
                return Response.success(responseString, HttpHeaderParser.parseCacheHeaders(response));
            }
        };

        requestQueue.add(stringRequest);
    }

    public void irDetallesLugar() {
        Intent intent = new Intent(this, DetallesLugarActivity.class);
        Bundle bundle = new Bundle();
        bundle.putSerializable("lugar", lugar);
        bundle.putSerializable("usuario", usuario);
        bundle.putString("key", key);
        intent.putExtras(bundle);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
    }

    private String uploadPhoto(String child) {
        StorageReference imageReference = storageReference.child(child);

        UploadTask uploadTask = imageReference.putFile(getAbsolutePhotoPath);

        uploadTask.addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                /*Toast.makeText(CrearProductoActivity.this, "Mal",
                        Toast.LENGTH_SHORT).show();*/

            }
        }).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
            }
        });
        return Constants.FIREBASE_STORAGE_URL_PRODUCTOS + Constants.BAR + child;
    }

    public void getLugarJSONVolley() {
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        String url = Constants.URL + Constants.URL_LUGARES_API + lugar.getId() + Constants.BAR;

        final JsonObjectRequest jsObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {
                    lugar = new Lugar(response);
                    alertDialog.show();
                    btnCrear.setEnabled(true);
                    btnCrear.setBackgroundResource(R.color.colorPrimaryDark);
                    //irDetallesLugar(lugar, usuario);
                } catch (JSONException e) {
                    btnCrear.setEnabled(true);
                    btnCrear.setBackgroundResource(R.color.colorPrimaryDark);
                    //e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                //Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_LONG).show();
                //Log.d("TAG", "Error Respuesta en JSON: " + error.getMessage());
            }
        }) {
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> params = new HashMap<>();
                params.put("Content-Type", "application/json; charset=UTF-8");
                params.put("Authorization", key);
                return params;
            }
        };

        requestQueue.add(jsObjectRequest);
    }

    /*private boolean validarPermisos() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return true;

        if (checkSelfPermission(CAMERA) == PackageManager.PERMISSION_GRANTED &&
                (checkSelfPermission(WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED))
            return true;

        if (shouldShowRequestPermissionRationale(CAMERA)
                || (shouldShowRequestPermissionRationale(WRITE_EXTERNAL_STORAGE))) {
            dialogRecomendacion();
        } else {
            requestPermissions(new String[]{WRITE_EXTERNAL_STORAGE, CAMERA}, 100);
        }


        return false;

    }

    private void dialogRecomendacion() {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Permisos Desactivados");
        builder.setMessage("Debe activar los permisos para poder tomar una foto");

        builder.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    requestPermissions(new String[]{WRITE_EXTERNAL_STORAGE, CAMERA}, 100);
                }
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == 100) {
            if (grantResults.length == 2 && grantResults[0] == PackageManager.PERMISSION_GRANTED
                    && grantResults[1] == PackageManager.PERMISSION_GRANTED) {

            }
        }
    }*/

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            Intent intent = NavUtils.getParentActivityIntent(this);
            if (intent != null) {
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                NavUtils.navigateUpTo(this, intent);
            }
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
