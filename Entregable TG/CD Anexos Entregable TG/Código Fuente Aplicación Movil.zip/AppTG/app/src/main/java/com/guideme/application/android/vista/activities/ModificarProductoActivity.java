package com.guideme.application.android.vista.activities;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v4.app.NavUtils;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.guideme.application.android.utils.Alerts;
import com.guideme.application.android.utils.Constants;
import com.guideme.application.android.R;
import com.guideme.application.android.utils.ValidarTextos;
import com.guideme.application.android.modelo.Lugar;
import com.guideme.application.android.modelo.Producto;
import com.guideme.application.android.modelo.Usuario;
import com.guideme.application.android.vista.fragments.GlideApp;

import org.json.JSONException;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

import static android.content.Intent.createChooser;

public class ModificarProductoActivity extends AppCompatActivity {

    private ImageView imagen;
    private EditText etnombre;
    private EditText etdescripcion;
    private EditText etprecio;
    private Button btnModificar;
    private Producto producto;
    StorageReference storageReference;
    private Uri getAbsolutePhotoPath;
    private Lugar lugar;
    private Usuario usuario;
    private String key;

    private AlertDialog alertDialog;
    private AlertDialog errorAlertDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modificar_producto);
        ActionBar actionBar = new ActionBar();
        imagen = findViewById(R.id.imagenProducto);
        etnombre = findViewById(R.id.editTextNombre);
        etdescripcion = findViewById(R.id.editTextDescripcion);
        etprecio = findViewById(R.id.editTextPrecio);
        btnModificar = findViewById(R.id.btnModificarProducto);

        Bundle bundle = getIntent().getExtras();
        if (savedInstanceState != null) {
            producto = (Producto) savedInstanceState.getSerializable("producto");
            lugar = (Lugar) savedInstanceState.getSerializable("lugar");
            usuario = (Usuario) savedInstanceState.getSerializable("usuario");
            key = savedInstanceState.getString("key");
        } else {
            producto = (Producto) (bundle != null ? bundle.getSerializable("producto") : null);
            lugar = (Lugar) (bundle != null ? bundle.getSerializable("lugar") : null);
            usuario = (Usuario) (bundle != null ? bundle.getSerializable("usuario") : null);
            key = bundle != null ? bundle.getString("key") : null;
        }
        String title = getResources().getString(R.string.modificar) + " " + producto.getNombre();
        actionBar.showToolbar(title, true, this);

        FirebaseStorage storage = FirebaseStorage.getInstance();
        storageReference = storage.getReferenceFromUrl(producto.getFoto());

        ponerElementos(producto);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Producto modificado");
        builder.setMessage("El producto " + producto.getNombre() + " ha sido modificado con éxito");
        builder.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                irDetallesProducto(producto);
            }
        });
        alertDialog = builder.create();
        btnModificar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cambiarDatos();
            }
        });
    }

    @Override
    protected void onSaveInstanceState(Bundle savedInstanceState) {
        savedInstanceState.putSerializable("producto", producto);
        savedInstanceState.putSerializable("lugar", lugar);
        savedInstanceState.putSerializable("usuario", usuario);
        savedInstanceState.putString("key", key);

        super.onSaveInstanceState(savedInstanceState);
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);

        producto = (Producto) savedInstanceState.getSerializable("producto");
        lugar = (Lugar) savedInstanceState.getSerializable("lugar");
        usuario = (Usuario) savedInstanceState.getSerializable("usuario");
        key = savedInstanceState.getString("key");
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            Intent intent = NavUtils.getParentActivityIntent(this);
            if (intent != null) {
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                NavUtils.navigateUpTo(this, intent);
            }
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public void ponerElementos(Producto producto) {
        GlideApp.with(this)
                .load(storageReference)
                .into(imagen);

        etnombre.setText(producto.getNombre());
        etdescripcion.setText(producto.getDescripcion());
        etprecio.setText(producto.getPrecio());
    }

    public void agregarImagen(View view) {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (inputMethodManager != null) {
            inputMethodManager.hideSoftInputFromWindow(etnombre.getWindowToken(), 0);
            inputMethodManager.hideSoftInputFromWindow(etdescripcion.getWindowToken(), 0);
            inputMethodManager.hideSoftInputFromWindow(etprecio.getWindowToken(), 0);
        }

        startActivityForResult(createChooser(intent, "Selecciona la Aplicación"), 10);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            Uri path = data.getData();
            imagen.setImageURI(path);
            getAbsolutePhotoPath = path;
        }
    }

    private String uploadPhoto(String child) {
        FirebaseStorage firebaseStorage = FirebaseStorage.getInstance();
        StorageReference storageReference = firebaseStorage.getReferenceFromUrl(Constants.FIREBASE_STORAGE_URL_PRODUCTOS);

        StorageReference imageReference = storageReference.child(child);

        UploadTask uploadTask = imageReference.putFile(getAbsolutePhotoPath);

        uploadTask.addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                /*Toast.makeText(ModificarProductoActivity.this, "Mal",
                        Toast.LENGTH_SHORT).show();*/

            }
        }).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
            }
        });
        return Constants.FIREBASE_STORAGE_URL_PRODUCTOS + Constants.BAR + child;
    }

    public void cambiarDatos() {
        final Alerts alerts = new Alerts(this);

        if (alerts.isConnected()) {
            ValidarTextos validarTextos = new ValidarTextos();
            boolean nombrevalido = validarTextos.validateBlank(etnombre, this);
            boolean descripcionvalido = validarTextos.validateBlank(etdescripcion, this);
            boolean precioovalido = validarTextos.validateBlank(etprecio, this);

            if (nombrevalido && descripcionvalido && precioovalido) {
                final String nombre = etnombre.getText().toString().trim();
                final String descripcion = etdescripcion.getText().toString().trim();
                final String precio = etprecio.getText().toString().trim();

                if (getAbsolutePhotoPath != null) {
                    this.storageReference.delete().addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void aVoid) {
                            String foto = uploadPhoto("" + producto.getId());
                            producto.setFoto(foto);
                            producto.setNombre(nombre);
                            producto.setDescripcion(descripcion);
                            producto.setPrecio(precio);
                            putJSONVolley(producto);
                        }
                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {

                        }
                    });
                } else {
                    producto.setNombre(nombre);
                    producto.setDescripcion(descripcion);
                    producto.setPrecio(precio);
                    putJSONVolley(producto);
                }
            }
        }
    }

    public void putJSONVolley(Producto producto) {
        try {
            btnModificar.setEnabled(false);
            btnModificar.setBackgroundResource(R.color.darker_gray);
            final Alerts alerts = new Alerts(this);

            RequestQueue requestQueue = Volley.newRequestQueue(this);

            JSONObject jsonBody = producto.getJSONProducto();

            final String mRequestBody = jsonBody.toString();
            String url = Constants.URL + Constants.URL_PRODUCTOS_API + producto.getId() + Constants.BAR;
            //System.out.println("JSON: " + mRequestBody);

            StringRequest stringRequest = new StringRequest(Request.Method.PUT, url, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    //Log.i("LOG_VOLLEY", response);
                    getProductoJSONVolley();
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    int statusCode = error.networkResponse.statusCode;
                    String mensaje = "No se pudo modificar el producto";
                    errorAlertDialog = alerts.createErrorAlert(statusCode, mensaje).create();
                    errorAlertDialog.show();
                    btnModificar.setEnabled(true);
                    btnModificar.setBackgroundResource(R.color.colorPrimaryDark);
                }
            }) {
                @Override
                public Map<String, String> getHeaders() {
                    Map<String, String> params = new HashMap<>();
                    params.put("Content-Type", "application/json; charset=UTF-8");
                    params.put("Authorization", key);
                    return params;
                }

                @Override
                public String getBodyContentType() {
                    return "application/json; charset=utf-8";
                }

                @Override
                public byte[] getBody() {
                    return mRequestBody == null ? null : mRequestBody.getBytes(StandardCharsets.UTF_8);
                }

                @Override
                protected Response<String> parseNetworkResponse(NetworkResponse response) {
                    String responseString = "";
                    if (response != null) {
                        responseString = String.valueOf(response.statusCode);
                    }
                    return Response.success(responseString, HttpHeaderParser.parseCacheHeaders(response));
                }
            };

            requestQueue.add(stringRequest);

        } catch (JSONException e) {
            //e.printStackTrace();
        }
    }

    public void irDetallesProducto(Producto producto) {
        Intent intent = new Intent(this, DetallesProductoActivity.class);
        Bundle bundle = new Bundle();
        bundle.putSerializable("usuario", usuario);
        bundle.putSerializable("lugar", lugar);
        bundle.putSerializable("producto", producto);
        bundle.putString("key", key);
        intent.putExtras(bundle);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
    }

    public void getProductoJSONVolley() {
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        String url = Constants.URL + Constants.URL_PRODUCTOS_API + producto.getId() + Constants.BAR;

        final JsonObjectRequest jsObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {
                    producto = new Producto(response);
                    alertDialog.show();
                    btnModificar.setEnabled(true);
                    btnModificar.setBackgroundResource(R.color.colorPrimaryDark);
                    //irDetallesProducto(producto);
                } catch (JSONException e) {
                    //e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                //Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_LONG).show();
                //Log.d("TAG", "Error Respuesta en JSON: " + error.getMessage());

            }
        }) {
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> params = new HashMap<>();
                params.put("Content-Type", "application/json; charset=UTF-8");
                params.put("Authorization", key);
                return params;
            }
        };

        requestQueue.add(jsObjectRequest);
    }

}
