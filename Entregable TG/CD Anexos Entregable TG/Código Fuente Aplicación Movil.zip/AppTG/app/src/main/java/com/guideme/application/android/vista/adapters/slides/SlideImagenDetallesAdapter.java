package com.guideme.application.android.vista.adapters.slides;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v4.view.PagerAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.guideme.application.android.R;
import com.guideme.application.android.vista.dialog.ImageDialog;
import com.guideme.application.android.vista.fragments.GlideApp;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;
import java.util.Objects;

public class SlideImagenDetallesAdapter extends PagerAdapter {
    private Context context;
    private ArrayList<String> fotos;

    public SlideImagenDetallesAdapter(Context context, ArrayList<String> fotos) {
        this.context = context;
        this.fotos = fotos;
    }

    @Override
    public int getCount() {
        return fotos.size();
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        return view == object;
    }

    @NonNull
    @Override
    public Object instantiateItem(@NonNull ViewGroup container, final int position) {
        FirebaseStorage firebaseStorage = FirebaseStorage.getInstance();
        StorageReference storageReference;

        LayoutInflater layoutInflater = Objects.requireNonNull
                ((LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE));
        View view = layoutInflater.inflate(R.layout.slide_imagenes, container, false);

        ImageView imageView = view.findViewById(R.id.imageSlider);

        storageReference = firebaseStorage.getReferenceFromUrl(fotos.get(position));
        GlideApp.with(context)
                .load(storageReference)
                .into(imageView);

        container.addView(view);

        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new ImageDialog(context, fotos.get(position));
            }
        });

        return view;
    }

    @Override
    public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
        container.removeView((LinearLayout) object);
    }
}
