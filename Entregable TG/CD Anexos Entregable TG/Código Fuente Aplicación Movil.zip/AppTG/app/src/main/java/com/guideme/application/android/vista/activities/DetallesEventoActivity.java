package com.guideme.application.android.vista.activities;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.NavUtils;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.TextView;

import com.guideme.application.android.utils.Alerts;
import com.guideme.application.android.utils.Constants;
import com.guideme.application.android.R;
import com.guideme.application.android.modelo.Evento;
import com.guideme.application.android.modelo.Lugar;
import com.guideme.application.android.modelo.Usuario;
import com.guideme.application.android.vista.adapters.recycler.ComentarioAdapterRecycler;
import com.guideme.application.android.vista.adapters.slides.SlideImagenDetallesAdapter;
import com.guideme.application.android.vista.dialog.ComentarioDialog;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;

public class DetallesEventoActivity extends AppCompatActivity {

    private LinearLayout dotsLayout;
    private RecyclerView recyclerView;
    private RatingBar ratingBar;

    private Evento evento;
    private Usuario usuario;
    private Lugar lugarE;

    //Adapters
    private ComentarioAdapterRecycler comentarioAdapterRecycler;

    Context context = this;

    private int camino;
    private String key;

    private AlertDialog errorAlertDialog;
    private Alerts alerts;

    // Componentes dialogo comentario
    final private static int DIALOG_LOGIN = 1;
    AlertDialog alertDialogComent;
    private RatingBar ratingComent;
    private CircleImageView perfilUsuario;
    private ImageButton btnCrearComentario;
    private EditText comentarioUsuario;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalles_evento);

        alerts = new Alerts(this);
        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        if (savedInstanceState != null) {
            evento = (Evento) savedInstanceState.getSerializable("evento");
            lugarE = (Lugar) savedInstanceState.getSerializable("lugar");
            usuario = (Usuario) savedInstanceState.getSerializable("usuario");
            camino = savedInstanceState.getInt("camino");
            key = savedInstanceState.getString("key");
        } else {
            evento = (Evento) (bundle != null ? bundle.getSerializable("evento") : null);
            lugarE = (Lugar) (bundle != null ? bundle.getSerializable("lugar") : null);
            usuario = (Usuario) (bundle != null ? bundle.getSerializable("usuario") : null);
            camino = bundle != null ? bundle.getInt("camino") : 0;
            key = bundle != null ? bundle.getString("key") : null;
        }

        ArrayList<String> fotos = new ArrayList<>();
        fotos.add(evento.getFoto());
        SlideImagenDetallesAdapter slideImagenDetallesAdapter = new SlideImagenDetallesAdapter(this, fotos);

        //Inicializacion de Elementos
        //Elementos del View
        ViewPager slideImagenes = findViewById(R.id.slideFotosDetallesEvento);
        dotsLayout = findViewById(R.id.dotsLayoutDetallesEvento);
        TextView tipoEvento = findViewById(R.id.tipoEventoDetalles);
        TextView descripcionEvento = findViewById(R.id.descripcionEventoDetalles);
        TextView estadoEvento = findViewById(R.id.estadoEventoDetalles);
        TextView inicioEvento = findViewById(R.id.inicioEventoDetalles);
        TextView finEvento = findViewById(R.id.finEventoDetalles);
        TextView organizadores = findViewById(R.id.organizadoresEventoDetalles);
        TextView direccion = findViewById(R.id.direccionDetallesEvento);
        TextView lugar = findViewById(R.id.lugarDetallesEvento);
        recyclerView = findViewById(R.id.recyclerComentario);
        ratingBar = findViewById(R.id.ratingComment);
        RatingBar ratingLugar = findViewById(R.id.ratingCardDetails);
        //////////////////////////////////////////////////////////////////

        //Slide
        addDotsIndicator(0);
        slideImagenes.addOnPageChangeListener(viewListener);
        slideImagenes.setAdapter(slideImagenDetallesAdapter);

        //Recycler
        comentarioAdapterRecycler = new ComentarioAdapterRecycler(this, evento.getComentarios());
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        recyclerView.setAdapter(comentarioAdapterRecycler);
        recyclerView.setLayoutManager(linearLayoutManager);

        //Poner Elementos
        tipoEvento.setText(evento.getTipo());

        descripcionEvento.setText(evento.getDescripcion());
        if (evento.isFinalizado()) {
            estadoEvento.setText(getResources().getString(R.string.finevento));
        } else {
            estadoEvento.setText(getResources().getString(R.string.inicioevento));
        }

        inicioEvento.setText(evento.getFechainicio() + " " + evento.getHorainicio());
        finEvento.setText(evento.getFechafin() + " " + evento.getHorafin());
        direccion.setText(evento.getDireccion());

        ratingLugar.setRating(evento.getRating());

        if (camino == 2) {
            organizadores.setText(lugarE.getNombre());
            lugar.setText(lugarE.getMunicipio());
        }

        ActionBar actionBar = new ActionBar();
        actionBar.showToolbar(evento.getNombre(), true, this);

        ratingBar.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                String url = Constants.URL + Constants.URL_EVENTOS_API + evento.getId() + Constants.BAR;
                agregarComentario(url);
            }
        });
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        try {
            boolean escomerciante = lugarE.getId_propietario() == usuario.getId();
            if (escomerciante) {
                inflater.inflate(R.menu.menu_modificar_producto_evento, menu);

            }
        } catch (Exception e) {
            inflater.inflate(R.menu.menu_compartir, menu);
        }
        return true;
    }

    @Override
    protected void onSaveInstanceState(Bundle savedInstanceState) {
        savedInstanceState.putSerializable("evento", evento);
        savedInstanceState.putSerializable("lugar", lugarE);
        savedInstanceState.putSerializable("usuario", usuario);
        savedInstanceState.putInt("camino", camino);
        savedInstanceState.putString("key", key);

        super.onSaveInstanceState(savedInstanceState);
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);

        evento = (Evento) savedInstanceState.getSerializable("evento");
        lugarE = (Lugar) savedInstanceState.getSerializable("lugar");
        usuario = (Usuario) savedInstanceState.getSerializable("usuario");
        camino = savedInstanceState.getInt("camino");
        key = savedInstanceState.getString("key");
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Intent intent;
        Bundle bundle;
        switch (item.getItemId()) {
            case R.id.menu_modificar_producto_evento:
                intent = new Intent(this, ModificarEventoActivity.class);
                bundle = new Bundle();
                bundle.putSerializable("evento", evento);
                bundle.putSerializable("lugar", lugarE);
                bundle.putSerializable("usuario", usuario);
                bundle.putString("key", key);
                bundle.putInt("camino", camino);
                intent.putExtras(bundle);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                break;
            case android.R.id.home:
                if (camino == 2) {
                    intent = new Intent(this, DetallesLugarActivity.class);
                    bundle = new Bundle();
                    bundle.putSerializable("lugar", lugarE);
                    bundle.putSerializable("usuario", usuario);
                    bundle.putString("key", key);
                    intent.putExtras(bundle);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                } else {
                    intent = NavUtils.getParentActivityIntent(this);
                    if (intent != null) {
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        NavUtils.navigateUpTo(this, intent);
                    }

                }
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public void addDotsIndicator(int position) {
        dotsLayout.removeAllViews();
        TextView[] dots = new TextView[1];
        for (int i = 0; i < dots.length; i++) {
            dots[i] = new TextView(this);
            dots[i].setText(Html.fromHtml("&#8226;"));
            dots[i].setTextSize(35);
            dots[i].setTextColor(getResources().getColor(R.color.transparentwhite));

            dotsLayout.addView(dots[i]);
        }
        dots[position].setTextColor(getResources().getColor(R.color.white));

    }

    ViewPager.OnPageChangeListener viewListener = new ViewPager.OnPageChangeListener() {
        @Override
        public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

        }

        @Override
        public void onPageSelected(int position) {
            addDotsIndicator(position);
        }

        @Override
        public void onPageScrollStateChanged(int state) {

        }
    };

    public void agregarComentario(String url) {
        if (alerts.isConnected()) {
            new ComentarioDialog(context, evento, usuario, ratingBar.getRating(), key, url, comentarioAdapterRecycler, recyclerView);
        }
    }
}
