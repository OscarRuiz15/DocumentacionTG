package com.guideme.application.android.modelo;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.Serializable;

public class Comentario implements Serializable {

    private int id;
    private String mensaje;
    private Usuario usuario;
    private String fecha;
    private String hora;
    private float calificacion;

    public Comentario() {
    }

    public Comentario(String mensaje, Usuario usuario, String fecha, String hora, float calificacion) {

        this.mensaje = mensaje;
        this.usuario = usuario;
        this.fecha = fecha;
        this.hora = hora;
        this.calificacion = calificacion;
    }

    public Comentario(JSONObject jsonObject) throws JSONException {
        this.id = jsonObject.getInt("id");
        this.mensaje = jsonObject.getString("mensaje");
        this.usuario = new Usuario(jsonObject.getJSONObject("usuario"), 0);
        this.fecha = jsonObject.getString("fecha");
        this.hora = jsonObject.getString("hora");
        this.calificacion = (int) jsonObject.getDouble("calificacion");
        ;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String comentario) {
        this.mensaje = comentario;
    }

    public float getCalificacion() {
        return calificacion;
    }

    public void setCalificacion(float calificacion) {
        this.calificacion = calificacion;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }

    public JSONObject getJSONComentario() throws JSONException {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("id", id);
        jsonObject.put("mensaje", mensaje);
        jsonObject.put("usuario", usuario.getJSONUsuario());
        jsonObject.put("fecha", fecha);
        jsonObject.put("hora", hora);
        jsonObject.put("calificacion", calificacion);

        return jsonObject;
    }
}
