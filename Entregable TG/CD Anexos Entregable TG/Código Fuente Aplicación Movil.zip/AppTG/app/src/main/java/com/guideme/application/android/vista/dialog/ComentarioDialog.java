package com.guideme.application.android.vista.dialog;

import android.app.Dialog;
import android.content.Context;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.Window;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RatingBar;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.guideme.application.android.utils.Alerts;
import com.guideme.application.android.utils.ControladorFechas;
import com.guideme.application.android.utils.Operaciones;
import com.guideme.application.android.R;
import com.guideme.application.android.modelo.Comentario;
import com.guideme.application.android.modelo.Evento;
import com.guideme.application.android.modelo.Lugar;
import com.guideme.application.android.modelo.Usuario;
import com.guideme.application.android.vista.adapters.recycler.ComentarioAdapterRecycler;
import com.guideme.application.android.vista.fragments.GlideApp;

import org.json.JSONException;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

import de.hdodenhof.circleimageview.CircleImageView;

public class ComentarioDialog {

    private Dialog dialog;
    private RatingBar ratingComent;
    private CircleImageView perfilUsuario;
    private ImageButton btnCrearComentario;
    private EditText comentarioUsuario;
    private final Usuario usuario;
    private Lugar lugar;
    private Evento evento;
    private final Context context;
    private float rating;
    private String key;
    private String url;
    private ControladorFechas controladorFechas = new ControladorFechas();
    private AlertDialog errorAlertDialog;
    private Alerts alerts;
    private ComentarioAdapterRecycler comentarioAdapterRecycler;
    private RecyclerView recyclerView;
    private final Operaciones operaciones = new Operaciones();

    public ComentarioDialog(Context context, Lugar lugar, Usuario usuario, float rating, String key, String url, ComentarioAdapterRecycler comentarioAdapterRecycler, RecyclerView recyclerView) {
        this.usuario = usuario;
        this.context = context;
        this.lugar = lugar;
        this.rating = rating;
        this.key = key;
        this.url = url;
        this.comentarioAdapterRecycler = comentarioAdapterRecycler;
        this.recyclerView = recyclerView;

        crearDialogo();
    }

    public ComentarioDialog(Context context, Evento evento, Usuario usuario, float rating, String key, String url, ComentarioAdapterRecycler comentarioAdapterRecycler, RecyclerView recyclerView) {
        this.usuario = usuario;
        this.context = context;
        this.evento = evento;
        this.rating = rating;
        this.key = key;
        this.url = url;
        this.comentarioAdapterRecycler = comentarioAdapterRecycler;
        this.recyclerView = recyclerView;

        crearDialogo();
    }

    public void crearDialogo() {
        dialog = new Dialog(context);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(true);
        dialog.setContentView(R.layout.dialogo_comentario);

        alerts = new Alerts(context);

        comentarioUsuario = dialog.findViewById(R.id.comentarioDialog);
        ratingComent = dialog.findViewById(R.id.ratingCommentDialog);

        perfilUsuario = dialog.findViewById(R.id.imageProfileComentario);
        try {
            FirebaseStorage firebaseStorage = FirebaseStorage.getInstance();
            StorageReference storageReference = firebaseStorage.getReferenceFromUrl(usuario.getFoto());

            GlideApp.with(context)
                    .load(storageReference)
                    .into(perfilUsuario);
        } catch (Exception e) {
            GlideApp.with(context)
                    .load(usuario.getFoto())
                    .into(perfilUsuario);
        }

        ratingComent.setRating(rating);

        btnCrearComentario = dialog.findViewById(R.id.botonSubirComentario);
        btnCrearComentario.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String mensaje = comentarioUsuario.getText().toString().trim();
                float rating = ratingComent.getRating();
                postComentarioVolley(mensaje, rating);
            }
        });

        dialog.show();
    }

    private void postComentarioVolley(String mensaje, float rating) {
        /*System.out.println("MENSAJE " + mensaje);
        System.out.println("RATING " + rating);*/

        String fecha = controladorFechas.getDate();
        String hora = controladorFechas.getHour();

        if (rating != 0) {
            final Comentario comentario = new Comentario(mensaje, usuario, fecha, hora, rating);

            if (lugar != null) {
                lugar.getComentarios().add(0, comentario);
                lugar.setRating(operaciones.calcularCalificacion(lugar.getComentarios()));
            } else {
                evento.getComentarios().add(0, comentario);
                evento.setRating(operaciones.calcularCalificacion(evento.getComentarios()));
            }

            try {
                RequestQueue requestQueue = Volley.newRequestQueue(context);
                JSONObject json;

                if (lugar != null) {
                    json = lugar.getJSONLugar();
                } else {
                    json = evento.getJsonObject();
                }

                final String mRequestBodyLugar = json.toString();
                /*System.out.println("---> " + mRequestBodyLugar);
                System.out.println(json.toString());*/

                StringRequest stringRequestLugar = new StringRequest(Request.Method.PUT, url, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        //Log.i("LOG_VOLLEY", response);
                        comentarioUsuario.setText("");


                        if (lugar != null) {
                            comentarioAdapterRecycler = new ComentarioAdapterRecycler(context, lugar.getComentarios());
                        } else {
                            comentarioAdapterRecycler = new ComentarioAdapterRecycler(context, evento.getComentarios());
                        }

                        LinearLayoutManager linearLayoutManager1 = new LinearLayoutManager(context);
                        recyclerView.setAdapter(comentarioAdapterRecycler);
                        recyclerView.setLayoutManager(linearLayoutManager1);

                        dialog.dismiss();
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        int statusCode = error.networkResponse.statusCode;
                        String mensaje = "No se pudo guardar tú comentario";
                        errorAlertDialog = alerts.createErrorAlert(statusCode, mensaje).create();
                        errorAlertDialog.show();
                    }
                }) {
                    @Override
                    public Map<String, String> getHeaders() {
                        Map<String, String> params = new HashMap<>();
                        params.put("Content-Type", "application/json; charset=UTF-8");
                        params.put("Authorization", key);
                        return params;
                    }

                    @Override
                    public String getBodyContentType() {
                        return "application/json; charset=utf-8";
                    }

                    @Override
                    public byte[] getBody() {
                        return mRequestBodyLugar == null ? null : mRequestBodyLugar.getBytes(StandardCharsets.UTF_8);
                    }

                    @Override
                    protected Response<String> parseNetworkResponse(NetworkResponse response) {
                        String responseString = "";
                        if (response != null) {
                            responseString = String.valueOf(response.statusCode);
                        }
                        return Response.success(responseString, HttpHeaderParser.parseCacheHeaders(response));
                    }
                };

                stringRequestLugar.setRetryPolicy(new DefaultRetryPolicy(
                        DefaultRetryPolicy.DEFAULT_TIMEOUT_MS * 5,
                        DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                        DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

                requestQueue.add(stringRequestLugar);

            } catch (JSONException e) {
                //e.printStackTrace();
            }
        }
    }
}
