package com.guideme.application.android.vista.activities;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.NavUtils;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.GridLayout;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.guideme.application.android.R;
import com.guideme.application.android.modelo.Preferencia;
import com.guideme.application.android.modelo.Tag;
import com.guideme.application.android.modelo.Usuario;
import com.guideme.application.android.utils.Alerts;
import com.guideme.application.android.utils.Constants;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import static android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP;

public class ModificarPreferencias extends AppCompatActivity {

    private String key;
    private Usuario usuario;

    private ArrayList<CheckBox> cbTags;
    private ArrayList<Tag> tags;
    private Preferencia preferencia;
    private ArrayList<String> tagsPreferencias;

    private GridLayout layoutTags;
    private Button btnGuardar;

    private AlertDialog alertDialog;
    private AlertDialog errorAlertDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modificar_preferencias);

        ActionBar actionBar = new ActionBar();
        actionBar.showToolbar("Modificar Preferencias", true, this);

        Bundle bundle = getIntent().getExtras();
        if (savedInstanceState != null) {
            usuario = (Usuario) savedInstanceState.getSerializable("usuario");
            key = savedInstanceState.getString("key");
        } else {
            usuario = (Usuario) (bundle != null ? bundle.getSerializable("usuario") : null);
            key = bundle != null ? bundle.getString("key") : null;
        }

        tags = new ArrayList<>();
        cbTags = new ArrayList<>();
        layoutTags = findViewById(R.id.layoutTags);
        tagsPreferencias = new ArrayList<>();
        btnGuardar = findViewById(R.id.btnGuardar);

        obtenerPreferencias();

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Has cambiado tus preferencias");
        builder.setMessage("Preferencias modificadas con éxito");
        builder.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        });
        alertDialog = builder.create();

    }

    @Override
    protected void onSaveInstanceState(Bundle savedInstanceState) {
        savedInstanceState.putSerializable("usuario", usuario);
        savedInstanceState.putString("key", key);

        super.onSaveInstanceState(savedInstanceState);
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);

        usuario = (Usuario) savedInstanceState.getSerializable("usuario");
        key = savedInstanceState.getString("key");
    }

    public void obtenerPreferencias() {
        String url = Constants.URL + Constants.URL_PREFERENCIAS_API + Constants.CONSULTA_USUARIOS + usuario.getUid();
        RequestQueue requestQueue = Volley.newRequestQueue(Objects.requireNonNull(this));
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, url, null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                for (int i = 0; i < response.length(); i++) {
                    try {
                        preferencia = new Preferencia(response.getJSONObject(i));
                    } catch (JSONException e) {
                        //e.printStackTrace();
                    }
                }
                cargarTags();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }) {
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> params = new HashMap<>();
                params.put("Content-Type", "application/json; charset=UTF-8");
                params.put("Authorization", key);
                return params;
            }
        };
        jsonArrayRequest.setRetryPolicy(new DefaultRetryPolicy(
                DefaultRetryPolicy.DEFAULT_TIMEOUT_MS * 3,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        requestQueue.add(jsonArrayRequest);
    }

    public void cargarTags() {
        String url = Constants.URL + Constants.URL_TAGS_API;
        RequestQueue requestQueue = Volley.newRequestQueue(Objects.requireNonNull(this));
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, url, null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                for (int i = 0; i < response.length(); i++) {
                    try {
                        Tag tag = new Tag(response.getJSONObject(i));
                        tags.add(tag);
                    } catch (JSONException e) {
                        //e.printStackTrace();
                    }
                }
                mostrarTags();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }) {
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> params = new HashMap<>();
                params.put("Content-Type", "application/json; charset=UTF-8");
                params.put("Authorization", key);
                return params;
            }
        };
        jsonArrayRequest.setRetryPolicy(new DefaultRetryPolicy(
                DefaultRetryPolicy.DEFAULT_TIMEOUT_MS * 3,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        requestQueue.add(jsonArrayRequest);
    }

    public void mostrarTags() {
        for (int i = 0; i < tags.size(); i++) {
            CheckBox cb = new CheckBox(this);
            cb.setText(tags.get(i).getNombre());
            cb.setTag(tags.get(i).getId());

            layoutTags.addView(cb);
            cbTags.add(cb);
        }

        if (preferencia != null) {
            for (int i = 0; i < cbTags.size(); i++) {
                for (int j = 0; j < preferencia.getTags().size(); j++) {
                    if (preferencia.getTags().get(j).equals(cbTags.get(i).getText())) {
                        cbTags.get(i).setChecked(true);
                    }
                }
            }
        }


        btnGuardar.setVisibility(View.VISIBLE);
    }

    public void modificar(View view) {
        btnGuardar.setEnabled(false);
        btnGuardar.setBackgroundResource(R.color.darker_gray);
        for (int i = 0; i < cbTags.size(); i++) {
            if (cbTags.get(i).isChecked()) {
                tagsPreferencias.add("" + cbTags.get(i).getText());
            }
        }

        if (preferencia != null) {
            preferencia.setTags(tagsPreferencias);
            putJSONVolley();
        } else {
            postJSONPreferencia();
        }


    }

    public void putJSONVolley() {
        try {
            final Alerts alerts = new Alerts(this);

            RequestQueue requestQueue = Volley.newRequestQueue(this);

            JSONObject jsonBody = preferencia.getJSONPreferencia();

            final String mRequestBody = jsonBody.toString();
            String url = Constants.URL + Constants.URL_PREFERENCIAS_API + preferencia.getId() + Constants.BAR;

            StringRequest stringRequest = new StringRequest(Request.Method.PUT, url, new Response.Listener<String>() {

                @Override
                public void onResponse(String response) {
                    alertDialog.show();
                    btnGuardar.setEnabled(true);
                    btnGuardar.setBackgroundResource(R.color.colorPrimaryDark);

                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    int statusCode = error.networkResponse.statusCode;
                    String mensaje = "No se pudo modificar las preferencias";
                    errorAlertDialog = alerts.createErrorAlert(statusCode, mensaje).create();
                    errorAlertDialog.show();
                    btnGuardar.setEnabled(true);
                    btnGuardar.setBackgroundResource(R.color.colorPrimaryDark);
                }
            }) {
                @Override
                public Map<String, String> getHeaders() {
                    Map<String, String> params = new HashMap<>();
                    params.put("Content-Type", "application/json; charset=UTF-8");
                    params.put("Authorization", key);
                    return params;
                }

                @Override
                public String getBodyContentType() {
                    return "application/json; charset=utf-8";
                }

                @Override
                public byte[] getBody() {
                    return mRequestBody == null ? null : mRequestBody.getBytes(StandardCharsets.UTF_8);
                }

                @Override
                protected Response<String> parseNetworkResponse(NetworkResponse response) {
                    String responseString = "";
                    if (response != null) {
                        responseString = String.valueOf(response.statusCode);
                    }
                    return Response.success(responseString, HttpHeaderParser.parseCacheHeaders(response));
                }
            };


            requestQueue.add(stringRequest);
        } catch (JSONException e) {
            //e.printStackTrace();
        }
    }

    public void postJSONPreferencia() {
        try {
            final Alerts alerts = new Alerts(this);
            RequestQueue requestQueue = Volley.newRequestQueue(this);

            Preferencia preferencia = new Preferencia();
            preferencia.setUsuario(usuario.getId());
            preferencia.setTags(tagsPreferencias);

            JSONObject jsonBody = preferencia.getJSONPreferencia();
            final String mRequestBody = jsonBody.toString();

            StringRequest stringRequest = new StringRequest(Request.Method.POST, Constants.URL + Constants.URL_PREFERENCIAS_API, new Response.Listener<String>() {

                @Override
                public void onResponse(String response) {
                    alertDialog.show();
                    btnGuardar.setEnabled(true);
                    btnGuardar.setBackgroundResource(R.color.colorPrimaryDark);
                }
            }, new Response.ErrorListener() {

                @Override
                public void onErrorResponse(VolleyError error) {
                    int statusCode = error.networkResponse.statusCode;
                    String mensaje = "No se pudo modificar las preferencias";
                    errorAlertDialog = alerts.createErrorAlert(statusCode, mensaje).create();
                    errorAlertDialog.show();
                    btnGuardar.setEnabled(true);
                    btnGuardar.setBackgroundResource(R.color.colorPrimaryDark);
                }
            }) {
                @Override
                public Map<String, String> getHeaders() {
                    Map<String, String> params = new HashMap<>();
                    params.put("Content-Type", "application/json; charset=UTF-8");
                    params.put("Authorization", key);
                    return params;
                }

                @Override
                public String getBodyContentType() {
                    return "application/json; charset=utf-8";
                }

                @Override
                public byte[] getBody() {
                    return mRequestBody == null ? null : mRequestBody.getBytes(StandardCharsets.UTF_8);
                }

                @Override
                protected Response<String> parseNetworkResponse(NetworkResponse response) {
                    String responseString = "";
                    if (response != null) {
                        responseString = String.valueOf(response.statusCode);
                    }
                    return Response.success(responseString, HttpHeaderParser.parseCacheHeaders(response));
                }
            };

            requestQueue.add(stringRequest);

        } catch (JSONException e) {
            //e.printStackTrace();
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            Intent intent = NavUtils.getParentActivityIntent(this);
            if (intent != null) {
                intent.setFlags(FLAG_ACTIVITY_CLEAR_TOP);
                NavUtils.navigateUpTo(this, intent);
            }
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
