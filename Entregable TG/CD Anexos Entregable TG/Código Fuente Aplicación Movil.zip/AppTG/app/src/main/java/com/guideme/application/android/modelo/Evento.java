package com.guideme.application.android.modelo;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.Serializable;
import java.util.ArrayList;

public class Evento implements Serializable {

    private int id;
    private String nombre;
    private String descripcion;
    private int lugar;
    private ArrayList<Comentario> comentarios;
    private String direccion;
    private String foto;
    private float rating;
    private String tipo;
    private String fechainicio;
    private String fechafin;
    private String horainicio;
    private String horafin;
    private boolean finalizado;

    public Evento() {
    }

    private ArrayList<Comentario> comentariosJSONArray(JSONArray jsonArray) {
        ArrayList<Comentario> comentarios = new ArrayList<>();
        for (int i = 0; i < jsonArray.length(); i++) {
            try {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                comentarios.add(new Comentario(jsonObject));
            } catch (JSONException e) {
                //e.printStackTrace();
            }
        }
        return comentarios;
    }

    public Evento(JSONObject jsonObject) throws JSONException {
        this.id = jsonObject.getInt("id");
        this.nombre = jsonObject.getString("nombre");
        this.descripcion = jsonObject.getString("descripcion");
        this.lugar = jsonObject.getInt("lugar");
        this.comentarios = comentariosJSONArray(jsonObject.getJSONArray("comentario"));
        this.direccion = jsonObject.getString("direccion");
        this.foto = jsonObject.getString("foto");
        this.rating = (float) jsonObject.getDouble("calificacion");
        this.tipo = jsonObject.getString("tipo");
        this.fechainicio = jsonObject.getString("fecha_inicio");
        this.fechafin = jsonObject.getString("fecha_fin");
        this.horainicio = jsonObject.getString("hora_inicio");
        this.horafin = jsonObject.getString("hora_fin");
        this.finalizado = jsonObject.getBoolean("finalizado");
    }

    public Evento(int id, String nombre, String descripcion, int lugar,
                  ArrayList<Comentario> comentarios, String direccion, String foto, float rating,
                  String tipo, String fechainicio, String fechafin, String horainicio,
                  String horafin, boolean finalizado) {
        this.id = id;
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.lugar = lugar;
        this.comentarios = comentarios;
        this.direccion = direccion;
        this.foto = foto;
        this.rating = rating;
        this.tipo = tipo;
        this.fechainicio = fechainicio;
        this.fechafin = fechafin;
        this.horainicio = horainicio;
        this.horafin = horafin;
        this.finalizado = finalizado;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public ArrayList<Comentario> getComentarios() {
        return comentarios;
    }

    public void setComentarios(ArrayList<Comentario> comentarios) {
        this.comentarios = comentarios;
    }

    public String getFechainicio() {
        return fechainicio;
    }

    public void setFechainicio(String fechainicio) {
        this.fechainicio = fechainicio;
    }

    public String getFechafin() {
        return fechafin;
    }

    public void setFechafin(String fechafin) {
        this.fechafin = fechafin;
    }

    public boolean isFinalizado() {
        return finalizado;
    }

    public void setFinalizado(boolean finalizado) {
        this.finalizado = finalizado;
    }

    public float getRating() {
        return rating;
    }

    public void setRating(float rating) {
        this.rating = rating;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getHorainicio() {
        return horainicio;
    }

    public void setHorainicio(String horainicio) {
        this.horainicio = horainicio;
    }

    public String getHorafin() {
        return horafin;
    }

    public void setHorafin(String horafin) {
        this.horafin = horafin;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getLugar() {
        return lugar;
    }

    public void setLugar(int lugar) {
        this.lugar = lugar;
    }

    public String getFoto() {
        return foto;
    }

    public void setFoto(String foto) {
        this.foto = foto;
    }

    public JSONArray comentariosListToJSONArray(ArrayList<Comentario> comentarios) throws JSONException {
        JSONArray jsonArray = new JSONArray();
        for (Comentario comentario : comentarios) {
            JSONObject jsonObject = comentario.getJSONComentario();
            jsonArray.put(jsonObject);
        }
        return jsonArray;
    }

    public JSONObject getJsonObject() throws JSONException {
        JSONObject jsonObject = new JSONObject();

        jsonObject.put("id", id);
        jsonObject.put("nombre", nombre);
        jsonObject.put("descripcion", descripcion);
        jsonObject.put("lugar", lugar);
        if (comentarios != null) {
            jsonObject.put("comentario", comentariosListToJSONArray(comentarios));
        } else {
            JSONArray jsonArray = new JSONArray();
            jsonObject.put("comentario", jsonArray);
        }
        jsonObject.put("direccion", direccion);
        jsonObject.put("foto", foto);
        jsonObject.put("calificacion", rating);
        jsonObject.put("tipo", tipo);
        jsonObject.put("fecha_inicio", fechainicio);
        jsonObject.put("fecha_fin", fechafin);
        jsonObject.put("hora_inicio", horainicio);
        jsonObject.put("hora_fin", horafin);
        jsonObject.put("finalizado", finalizado);

        return jsonObject;
    }

    @Override
    public String toString() {
        return "Evento{" +
                "id=" + id +
                ", nombre='" + nombre + '\'' +
                ", descripcion='" + descripcion + '\'' +
                ", lugar=" + lugar +
                ", comentarios=" + comentarios +
                ", direccion='" + direccion + '\'' +
                ", foto='" + foto + '\'' +
                ", rating=" + rating +
                ", tipo='" + tipo + '\'' +
                ", fechainicio='" + fechainicio + '\'' +
                ", fechafin='" + fechafin + '\'' +
                ", horainicio='" + horainicio + '\'' +
                ", horafin='" + horafin + '\'' +
                ", finalizado=" + finalizado +
                '}';
    }
}
