package com.guideme.application.android.utils;

import android.support.v4.content.FileProvider;

//Clase para generar permiso

public class GenericFileProvider extends FileProvider {
}
