package com.guideme.application.android.vista.adapters.recycler;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.guideme.application.android.R;
import com.guideme.application.android.modelo.Tag;

import java.util.ArrayList;

public class TagGridAdapter extends RecyclerView.Adapter<TagGridAdapter.TagViewHolder> {

    private ArrayList<Tag> tags;

    public TagGridAdapter(ArrayList<Tag> tags) {
        this.tags = tags;
    }

    @NonNull
    @Override
    public TagViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.card_view_tag, parent, false);
        return new TagGridAdapter.TagViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TagViewHolder holder, int position) {
        holder.tvTag.setText(tags.get(position).getNombre());
    }

    @Override
    public int getItemCount() {
        return tags.size();
    }


    static class TagViewHolder extends RecyclerView.ViewHolder {
        TextView tvTag;

        TagViewHolder(View itemView) {
            super(itemView);
            tvTag = itemView.findViewById(R.id.tagName);
        }
    }
}
