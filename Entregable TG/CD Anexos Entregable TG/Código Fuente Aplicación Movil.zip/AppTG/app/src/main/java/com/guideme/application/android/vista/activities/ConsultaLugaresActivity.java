package com.guideme.application.android.vista.activities;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.NavUtils;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.MenuItem;
import android.view.View;
import android.widget.SearchView;
import android.widget.TextView;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.guideme.application.android.utils.Consultas;
import com.guideme.application.android.utils.Operaciones;
import com.guideme.application.android.R;
import com.guideme.application.android.modelo.Lugar;
import com.guideme.application.android.modelo.Usuario;
import com.guideme.application.android.vista.adapters.recycler.LugarAdapterRecycler;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class ConsultaLugaresActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private LugarAdapterRecycler lugarAdapterRecycler;
    private TextView tvNotFound;
    private Usuario usuario;
    private ArrayList<Lugar> lugares;
    private String url;
    Context context = this;
    private String nombre;
    private Consultas consultas;
    private String key;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_consulta_lugares);

        Bundle bundle = getIntent().getExtras();

        if (savedInstanceState != null) {
            nombre = savedInstanceState.getString("nombre");
            url = savedInstanceState.getString("url");
            lugares = (ArrayList<Lugar>) savedInstanceState.getSerializable("lugares");
            usuario = (Usuario) savedInstanceState.getSerializable("usuario");
            key = savedInstanceState.getString("key");
        } else {
            nombre = bundle != null ? bundle.getString("nombre") : null;
            usuario = (Usuario) (bundle != null ? bundle.getSerializable("usuario") : null);
            url = bundle != null ? bundle.getString("url") : null;
            lugares = (ArrayList<Lugar>) ((bundle == null) ? null : bundle.getSerializable("lugares"));
            key = bundle != null ? bundle.getString("key") : null;
        }

        consultas = new Consultas();

        recyclerView = findViewById(R.id.recyclerPlaceCategorySearch);
        tvNotFound = findViewById(R.id.tvNotFound);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(linearLayoutManager);

        if (lugares == null) {
            lugares = new ArrayList<>();
            getLugaresVolley();
        } else {
            lugarAdapterRecycler = new LugarAdapterRecycler(context, lugares, usuario, key);
            recyclerView.setAdapter(lugarAdapterRecycler);
        }

        ActionBar actionBar = new ActionBar();
        actionBar.showToolbar(nombre, true, this);

        SearchView searchView = findViewById(R.id.search_view_categoty_search);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                ArrayList<Lugar> lugaresFiltrados = consultas.consultaLugaresPorNombre(lugares, newText);
                lugarAdapterRecycler.setFilter(lugaresFiltrados);
                if (lugaresFiltrados.isEmpty())
                    tvNotFound.setVisibility(View.VISIBLE);
                recyclerView.setVisibility(View.GONE);
                return true;
            }
        });
        searchView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            }
        });
    }

    private void getLugaresVolley() {
        final Operaciones operaciones = new Operaciones();
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        //System.out.println(url);
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, url, null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                for (int i = 0; i < response.length(); i++) {
                    //System.out.println(response.length());
                    try {
                        Lugar lugar = new Lugar(response.getJSONObject(i));
                        lugar.setRating(operaciones.calcularCalificacion(lugar.getComentarios()));
                        lugares.add(lugar);
                    } catch (JSONException e) {
                        //e.printStackTrace();
                    }
                }
                if (!lugares.isEmpty()) {
                    lugarAdapterRecycler = new LugarAdapterRecycler(context, lugares, usuario, key);
                    recyclerView.setAdapter(lugarAdapterRecycler);
                } else {
                    recyclerView.setVisibility(View.GONE);
                    tvNotFound.setVisibility(View.VISIBLE);
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                recyclerView.setVisibility(View.GONE);
                tvNotFound.setVisibility(View.VISIBLE);
            }
        }) {
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> params = new HashMap<>();
                params.put("Content-Type", "application/json; charset=UTF-8");
                params.put("Authorization", key);
                return params;
            }
        };
        jsonArrayRequest.setRetryPolicy(new DefaultRetryPolicy(
                DefaultRetryPolicy.DEFAULT_TIMEOUT_MS * 3,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        requestQueue.add(jsonArrayRequest);
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            Intent intent = NavUtils.getParentActivityIntent(this);
            if (intent != null) {
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                NavUtils.navigateUpTo(this, intent);
            }
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public void goToMaps(View view) {
        Intent intent = new Intent(this, MapsCategoriaActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        Bundle bundle = new Bundle();
        bundle.putSerializable("lugares", lugares);
        bundle.putSerializable("titulo", nombre);
        intent.putExtras(bundle);
        startActivity(intent);
    }

    @Override
    public void onSaveInstanceState(Bundle savedInstanceState) {
        // Save the user's current game state
        savedInstanceState.putSerializable("lugares", lugares);
        savedInstanceState.putSerializable("usuario", usuario);
        savedInstanceState.putString("nombre", nombre);
        savedInstanceState.putString("url", url);
        savedInstanceState.putString("key", key);

        // Always call the superclass so it can save the view hierarchy state
        super.onSaveInstanceState(savedInstanceState);
    }

    public void onRestoreInstanceState(Bundle savedInstanceState) {
        // Always call the superclass so it can restore the view hierarchy
        super.onRestoreInstanceState(savedInstanceState);

        // Restore state members from saved instance
        nombre = savedInstanceState.getString("nombre");
        url = savedInstanceState.getString("url");
        lugares = (ArrayList<Lugar>) savedInstanceState.getSerializable("lugares");
        usuario = (Usuario) savedInstanceState.getSerializable("usuario");
        key = savedInstanceState.getString("key");
    }

}
