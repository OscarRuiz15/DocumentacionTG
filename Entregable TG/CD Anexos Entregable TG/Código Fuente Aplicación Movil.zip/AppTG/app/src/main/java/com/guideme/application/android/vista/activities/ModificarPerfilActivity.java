package com.guideme.application.android.vista.activities;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.design.widget.TextInputLayout;
import android.support.v4.app.NavUtils;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;

import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.guideme.application.android.utils.Alerts;
import com.guideme.application.android.utils.Constants;
import com.guideme.application.android.R;
import com.guideme.application.android.utils.ValidarTextos;
import com.guideme.application.android.modelo.Usuario;
import com.guideme.application.android.vista.fragments.GlideApp;

import org.json.JSONException;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

import static android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP;

public class ModificarPerfilActivity extends AppCompatActivity {

    private ImageView imagen;
    private EditText etnombre;
    private EditText ettelefono;
    private EditText etemail;
    private Spinner spDepartamento;
    private Spinner spMunicipio;
    private Button btnModificar;

    private Usuario usuario;

    //Firebase Storage/////////////////////////
    private StorageReference storageReference;

    //Ruta del Archivo
    private Uri getAbsolutePhotoPath;

    private AlertDialog alertDialog;

    private String key;

    private String correoAux;

    private AlertDialog errorAlertDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modificar_perfil);
        ActionBar actionBar = new ActionBar();
        actionBar.showToolbar("Modificar Perfil", true, this);

        imagen = findViewById(R.id.imagenPerfil);
        etnombre = findViewById(R.id.name);
        etemail = findViewById(R.id.email);
        ettelefono = findViewById(R.id.editTextTelefono);

        spDepartamento = findViewById(R.id.spinnerDepartamento);
        spMunicipio = findViewById(R.id.spinnerMunicipio);

        btnModificar = findViewById(R.id.btnModificarPerfil);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.departamentos_array, R.layout.spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spDepartamento.setAdapter(adapter);
        spDepartamento.setSelection(30);

        spDepartamento.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                switch (spDepartamento.getSelectedItemPosition()) {
                    case 30:
                        spMunicipio.setVisibility(View.VISIBLE);
                        break;
                    default:
                        spMunicipio.setVisibility(View.GONE);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        adapter = ArrayAdapter.createFromResource(this,
                R.array.municipios_valle, R.layout.spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spMunicipio.setAdapter(adapter);
        spMunicipio.setSelection(19);


        Bundle bundle = getIntent().getExtras();
        if (savedInstanceState != null) {
            usuario = (Usuario) savedInstanceState.getSerializable("usuario");
            key = savedInstanceState.getString("key");
        } else {
            usuario = (Usuario) (bundle != null ? bundle.getSerializable("usuario") : null);
            key = bundle != null ? bundle.getString("key") : null;
        }

        ponerElementos(usuario);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Has cambiado tu perfil");
        builder.setMessage("Perfil modificado con éxito");
        builder.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
                //irContainer();
            }
        });
        alertDialog = builder.create();

        //REMOVER
        LinearLayout layout = findViewById(R.id.layout_Contacto);
        TextInputLayout tileditTextNacimiento = findViewById(R.id.tileditTextNacimiento);
        Spinner spGenero = findViewById(R.id.spinnerGenero);
        TextInputLayout tilpassword_create = findViewById(R.id.tilpassword_create);
        TextInputLayout tilconfirm_password = findViewById(R.id.tilconfirm_password);
        layout.removeView(tileditTextNacimiento);
        layout.removeView(spGenero);
        layout.removeView(tilpassword_create);
        layout.removeView(tilconfirm_password);

        correoAux = usuario.getEmail();
        btnModificar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cambiarDatos();
            }
        });

    }

    private void ponerElementos(Usuario usuario) {
        try {
            FirebaseStorage storage = FirebaseStorage.getInstance();
            storageReference = storage.getReferenceFromUrl(usuario.getFoto());
            GlideApp.with(this)
                    .load(storageReference)
                    .into(imagen);
        } catch (Exception e) {
            GlideApp.with(this)
                    .load(usuario.getFoto())
                    .into(imagen);
        }

        etemail.setText(usuario.getEmail());
        //etfecha.setText(usuario.getFecha());
        etnombre.setText(usuario.getNombre());
        ettelefono.setText(usuario.getTelefono());
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            Intent intent = NavUtils.getParentActivityIntent(this);
            if (intent != null) {
                intent.setFlags(FLAG_ACTIVITY_CLEAR_TOP);
                NavUtils.navigateUpTo(this, intent);
            }
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onSaveInstanceState(Bundle savedInstanceState) {
        savedInstanceState.putSerializable("usuario", usuario);
        savedInstanceState.putString("key", key);

        super.onSaveInstanceState(savedInstanceState);
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);

        usuario = (Usuario) savedInstanceState.getSerializable("usuario");
        key = savedInstanceState.getString("key");
    }

    public void agregarImagen(View view) {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (inputMethodManager != null) {
            inputMethodManager.hideSoftInputFromWindow(etnombre.getWindowToken(), 0);
            inputMethodManager.hideSoftInputFromWindow(etemail.getWindowToken(), 0);
            inputMethodManager.hideSoftInputFromWindow(ettelefono.getWindowToken(), 0);
        }

        startActivityForResult(Intent.createChooser(intent, "Selecciona la Aplicación"), 10);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            Uri path = data.getData();
            imagen.setImageURI(path);
            getAbsolutePhotoPath = path;
        }
    }

    public void cambiarDatos() {
        final Alerts alerts = new Alerts(this);

        if (alerts.isConnected()) {
            ValidarTextos validarTextos = new ValidarTextos();
            boolean nombrevalido = validarTextos.validateBlank(etnombre, this);
            boolean correovalido = validarTextos.validateEmail(etemail, this);
            boolean telefonovalido = validarTextos.validatePhone(ettelefono, this);

            if (nombrevalido && correovalido && telefonovalido) {
                final String nombre = etnombre.getText().toString().trim();
                final String email = etemail.getText().toString().trim();
                final String telefono = ettelefono.getText().toString().trim();
                //final String genero = spGenero.getSelectedItem() + "";
                final String departamento = spDepartamento.getSelectedItem() + "";
                String municipio = "";
                if (spMunicipio.getVisibility() != View.GONE) {
                    municipio = spMunicipio.getSelectedItem() + "";
                }

                final String municipioAux = municipio;

                if (!correoAux.equals(email)) {
                    cambiarCorreoFirebase();
                }

                if (getAbsolutePhotoPath != null) {
                    try {
                        this.storageReference.delete().addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void aVoid) {
                                String foto = uploadPhoto(usuario.getUid());
                                usuario.setFoto(foto);
                                usuario.setNombre(nombre);
                                usuario.setTelefono(telefono);
                                usuario.setMunicipio(municipioAux);
                                usuario.setDepartamento(departamento);
                                usuario.setEmail(email);
                                putJSONVolley(usuario);
                            }
                        }).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {

                            }
                        });
                    } catch (Exception e) {
                        String foto = uploadPhoto(usuario.getUid());
                        usuario.setFoto(foto);
                        usuario.setNombre(nombre);
                        usuario.setTelefono(telefono);
                        usuario.setMunicipio(municipioAux);
                        usuario.setDepartamento(departamento);
                        usuario.setEmail(email);
                        putJSONVolley(usuario);
                    }
                } else {
                    usuario.setNombre(nombre);
                    usuario.setTelefono(telefono);
                    usuario.setMunicipio(municipio);
                    usuario.setDepartamento(departamento);
                    usuario.setEmail(email);
                    putJSONVolley(usuario);
                }
            }
        }
    }

    private String uploadPhoto(String child) {
        FirebaseStorage firebaseStorage = FirebaseStorage.getInstance();
        StorageReference storageReference = firebaseStorage.getReferenceFromUrl(Constants.FIREBASE_STORAGE_URL);

        StorageReference imageReference = storageReference.child(child);

        UploadTask uploadTask = imageReference.putFile(getAbsolutePhotoPath);

        uploadTask.addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                /*Toast.makeText(ModificarPerfilActivity.this, "Mal",
                        Toast.LENGTH_SHORT).show();*/

            }
        }).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
            }
        });
        return Constants.FIREBASE_STORAGE_URL + Constants.BAR + child;
    }

    public void putJSONVolley(Usuario usuario) {
        try {
            btnModificar.setEnabled(false);
            btnModificar.setBackgroundResource(R.color.darker_gray);
            final Alerts alerts = new Alerts(this);

            RequestQueue requestQueue = Volley.newRequestQueue(this);

            JSONObject jsonBody = usuario.getJSONUsuario();

            final String mRequestBody = jsonBody.toString();
            String url = Constants.URL + Constants.URL_USUARIOS_API + usuario.getUid() + Constants.BAR;

            StringRequest stringRequest = new StringRequest(Request.Method.PUT, url, new Response.Listener<String>() {

                @Override
                public void onResponse(String response) {
                    alertDialog.show();
                    btnModificar.setEnabled(true);
                    btnModificar.setBackgroundResource(R.color.colorPrimaryDark);

                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    int statusCode = error.networkResponse.statusCode;
                    String mensaje = "No se pudo modificar el perfil";
                    errorAlertDialog = alerts.createErrorAlert(statusCode, mensaje).create();
                    errorAlertDialog.show();
                    btnModificar.setEnabled(true);
                    btnModificar.setBackgroundResource(R.color.colorPrimaryDark);
                }
            }) {
                @Override
                public Map<String, String> getHeaders() {
                    Map<String, String> params = new HashMap<>();
                    params.put("Content-Type", "application/json; charset=UTF-8");
                    params.put("Authorization", key);
                    return params;
                }

                @Override
                public String getBodyContentType() {
                    return "application/json; charset=utf-8";
                }

                @Override
                public byte[] getBody() {
                    return mRequestBody == null ? null : mRequestBody.getBytes(StandardCharsets.UTF_8);
                }

                @Override
                protected Response<String> parseNetworkResponse(NetworkResponse response) {
                    String responseString = "";
                    if (response != null) {
                        responseString = String.valueOf(response.statusCode);
                    }
                    return Response.success(responseString, HttpHeaderParser.parseCacheHeaders(response));
                }
            };


            requestQueue.add(stringRequest);
        } catch (JSONException e) {
            //e.printStackTrace();
        }
    }

    public void cambiarCorreoFirebase() {
        final FirebaseAuth firebaseAuth = FirebaseAuth.getInstance();
        FirebaseUser user = firebaseAuth.getCurrentUser();
        final String correo = etemail.getText().toString().trim();

        if (user != null) {
            user.updateEmail(correo).addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {
                    task.isSuccessful();
                }
            });
        }
    }

    public void irContainer() {
        Intent intent = new Intent(this, ContainerActivity.class);
        Bundle bundle = new Bundle();
        bundle.putSerializable("usuario", usuario);
        bundle.putString("key", key);
        bundle.putInt("item", 4);
        intent.putExtras(bundle);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
    }
}
