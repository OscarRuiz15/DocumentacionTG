package com.guideme.application.android.vista.adapters.recycler;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.guideme.application.android.R;
import com.guideme.application.android.modelo.Suscripcion;
import com.guideme.application.android.vista.fragments.GlideApp;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;

public class SuscriptoresAdapterRecycler extends RecyclerView.Adapter<SuscriptoresAdapterRecycler.SuscriptoresViewHolder> {

    private Context context;
    private ArrayList<Suscripcion> suscripciones;

    public SuscriptoresAdapterRecycler(Context context, ArrayList<Suscripcion> suscripciones) {
        this.context = context;
        this.suscripciones = suscripciones;
    }

    @NonNull
    @Override
    public SuscriptoresAdapterRecycler.SuscriptoresViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.cardview_suscriptores, parent, false);
        return new SuscriptoresAdapterRecycler.SuscriptoresViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull SuscriptoresViewHolder holder, int position) {
        try {
            FirebaseStorage firebaseStorage = FirebaseStorage.getInstance();
            StorageReference storageReference = firebaseStorage.getReferenceFromUrl(suscripciones.get(position).getUsuario().getFoto());
            GlideApp.with(context)
                    .load(storageReference)
                    .into(holder.circleImageView);
        } catch (Exception e) {
            GlideApp.with(context)
                    .load(suscripciones.get(position).getUsuario().getFoto())
                    .into(holder.circleImageView);
        }

        holder.txtnombre.setText(suscripciones.get(position).getUsuario().getNombre());
        holder.txtfecha.setText(" " + suscripciones.get(position).getFecha_suscripcion());

    }

    @Override
    public int getItemCount() {
        return suscripciones.size();
    }

    class SuscriptoresViewHolder extends RecyclerView.ViewHolder {
        CircleImageView circleImageView;
        TextView txtnombre;
        TextView txtfecha;

        SuscriptoresViewHolder(View itemView) {
            super(itemView);
            circleImageView = itemView.findViewById(R.id.image_user_suscript);
            txtnombre = itemView.findViewById(R.id.name_user_suscript);
            txtfecha = itemView.findViewById(R.id.fecha_suscripcion);
        }
    }

}
