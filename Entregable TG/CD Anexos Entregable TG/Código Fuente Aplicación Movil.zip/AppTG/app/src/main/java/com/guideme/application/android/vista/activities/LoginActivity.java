package com.guideme.application.android.vista.activities;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GetTokenResult;
import com.google.firebase.auth.GoogleAuthProvider;
import com.guideme.application.android.R;
import com.guideme.application.android.modelo.Usuario;
import com.guideme.application.android.utils.Alerts;
import com.guideme.application.android.utils.Constants;
import com.guideme.application.android.utils.ValidarTextos;
import com.guideme.application.android.vista.dialog.TagsDialog;
import com.pusher.pushnotifications.PushNotifications;

import org.json.JSONException;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class LoginActivity extends AppCompatActivity implements GoogleApiClient.OnConnectionFailedListener, View.OnClickListener {

    public final Calendar c = Calendar.getInstance();

    //Variables para obtener la fecha
    private int mes = c.get(Calendar.MONTH);
    private int dia = c.get(Calendar.DAY_OF_MONTH);
    private int anio = c.get(Calendar.YEAR);

    private EditText correo_electronico, password;
    private FirebaseAuth auth;
    private ProgressDialog progressDialog;
    private ProgressBar progressBar;
    private LinearLayout linearLayout;
    private LinearLayout layout_Completar;

    private EditText inputCorreo;
    private Button botonRestablecer;

    private Context context = this;

    private SignInButton signInButton;
    private GoogleApiClient googleApiClient;

    private EditText tffecha;
    private Spinner spDepartamento;
    private Spinner spMunicipio;
    private Spinner spGenero;
    private EditText ettelefono;
    private Button botonContinuar;

    private Alerts alerts;
    private AlertDialog errorAlertDialog;

    private String idToken;

    FirebaseUser userG;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        alerts = new Alerts(this);

        auth = FirebaseAuth.getInstance();


        correo_electronico = findViewById(R.id.correo_electronico);
        password = findViewById(R.id.password);
        linearLayout = findViewById(R.id.linearlayout);
        layout_Completar = findViewById(R.id.layout_Completar);

        progressBar = findViewById(R.id.progressBar);

        progressDialog = new ProgressDialog(LoginActivity.this);
        progressDialog.setMessage("Iniciando sesión");

        inputCorreo = findViewById(R.id.tfCorreo);
        inputCorreo.setVisibility(View.GONE);
        botonRestablecer = findViewById(R.id.btnRestablecer);
        botonRestablecer.setVisibility(View.GONE);

        ////////////////////////////////////
        botonContinuar = findViewById(R.id.btnContinuar);

        tffecha = findViewById(R.id.tfFecha);
        spGenero = findViewById(R.id.spinnerGeneroCompletar);
        spDepartamento = findViewById(R.id.spinnerDepartamentoCompletar);
        spMunicipio = findViewById(R.id.spinnerMunicipioCompletar);
        ettelefono = findViewById(R.id.editTextTelefono2);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.genero_array, R.layout.spinner_item);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spGenero.setAdapter(adapter);


        adapter = ArrayAdapter.createFromResource(this,
                R.array.departamentos_array, R.layout.spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spDepartamento.setAdapter(adapter);
        spDepartamento.setSelection(30);

        spDepartamento.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                switch (spDepartamento.getSelectedItemPosition()) {
                    case 30:
                        spMunicipio.setVisibility(View.VISIBLE);
                        break;
                    default:
                        spMunicipio.setVisibility(View.GONE);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        adapter = ArrayAdapter.createFromResource(this,
                R.array.municipios_valle, R.layout.spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spMunicipio.setAdapter(adapter);
        spMunicipio.setSelection(19);

        tffecha.setOnClickListener(this);

        linearLayout.removeView(layout_Completar);

        //////////////////////////////////////////////////////////////////////////////////
        final FirebaseUser user = auth.getCurrentUser();
        if (user != null) {
            linearLayout.setVisibility(View.GONE);
            progressBar.setVisibility(View.VISIBLE);

            FirebaseUser mUser = FirebaseAuth.getInstance().getCurrentUser();
            if (mUser != null) {
                mUser.getIdToken(true)
                        .addOnCompleteListener(new OnCompleteListener<GetTokenResult>() {
                            public void onComplete(@NonNull Task<GetTokenResult> task) {
                                if (task.isSuccessful()) {
                                    progressBar.setVisibility(View.VISIBLE);
                                    idToken = Objects.requireNonNull(task.getResult()).getToken();

                                    userG = user;
                                    getJSONVolley(userG, idToken);
                                    // Send token to your backend via HTTPS
                                    // ...
                                } else {
                                    linearLayout.setVisibility(View.VISIBLE);
                                    progressBar.setVisibility(View.GONE);
                                    // Handle error -> task.getException();
                                }
                            }
                        });
            }

            //loginDjango(auth.getUid(),1);

        }

        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail()
                .build();

        googleApiClient = new GoogleApiClient.Builder(this)
                .enableAutoManage(this, this)
                .addApi(Auth.GOOGLE_SIGN_IN_API, gso)
                .build();

        signInButton = findViewById(R.id.sign_in);
        signInButton.setOnClickListener(this);

        PushNotifications.start(getApplicationContext(), Constants.BEAMS_NOTIFICATIONS_INSTANCE_ID);
        /*System.out.println("<<!");
        PushNotifications.subscribe(9+"");
        System.out.println("<<2");*/


        botonContinuar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                crearCuenta(userG);
            }
        });

    }

    public void goToCreate(View v) {
        Intent intent = new Intent(this, CreateAccountActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(intent);
    }

    public void goToContainer(View v) {


        ValidarTextos validarTextos = new ValidarTextos();
        boolean validar = validarTextos.validateEmail(correo_electronico, this) && validarTextos.validateBlank(password, this);
        String correo = correo_electronico.getText().toString().trim();
        String pass = password.getText().toString().trim();

        //Login con firebase
        if (validar) {
            linearLayout.setVisibility(View.GONE);
            progressBar.setVisibility(View.VISIBLE);
            auth.signInWithEmailAndPassword(correo, pass).
                    addOnCompleteListener(LoginActivity.this, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (!task.isSuccessful()) {
                                Toast.makeText(getApplicationContext(), "Email o contraseña incorrecto", Toast.LENGTH_LONG).show();
                                progressDialog.hide();
                                linearLayout.setVisibility(View.VISIBLE);
                                progressBar.setVisibility(View.GONE);
                            } else {
                                final FirebaseUser firebaseUser = auth.getCurrentUser();

                                FirebaseUser mUser = FirebaseAuth.getInstance().getCurrentUser();
                                if (mUser != null) {
                                    mUser.getIdToken(true)
                                            .addOnCompleteListener(new OnCompleteListener<GetTokenResult>() {
                                                public void onComplete(@NonNull Task<GetTokenResult> task) {
                                                    if (task.isSuccessful()) {
                                                        String idToken = Objects.requireNonNull
                                                                (task.getResult()).getToken();
                                                        if (firebaseUser != null) {
                                                            getJSONVolley(firebaseUser, idToken);
                                                        }
                                                        // Send token to your backend via HTTPS
                                                        // ...
                                                    }  // Handle error -> task.getException();

                                                }
                                            });
                                }

                                //loginDjango(firebaseUser.getUid(),1);
                                if (mUser != null) {
                                    mUser.getIdToken(true)
                                            .addOnCompleteListener(new OnCompleteListener<GetTokenResult>() {
                                                public void onComplete(@NonNull Task<GetTokenResult> task) {
                                                    if (task.isSuccessful()) {
                                                        String idToken = Objects.requireNonNull(task.getResult()).getToken();
                                                        getJSONVolley(Objects.requireNonNull(firebaseUser), idToken);
                                                        // Send token to your backend via HTTPS
                                                        // ...
                                                    }  // Handle error -> task.getException();

                                                }
                                            });
                                }


                            }
                        }
                    });
        }
    }

    private void getJSONVolley(FirebaseUser user, final String key) {
        linearLayout.setVisibility(View.GONE);
        progressBar.setVisibility(View.VISIBLE);

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        String url = Constants.URL + Constants.URL_USUARIOS_API + user.getUid() + Constants.GET_JSON;
        JsonObjectRequest jsObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {
                    Intent intent = new Intent(LoginActivity.this, ContainerActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
                    Usuario usuario = new Usuario(response);
                    Bundle bundle = new Bundle();
                    bundle.putSerializable("usuario", usuario);
                    System.out.println("INICIO TODO "+key);
                    bundle.putString("key", key);
                    intent.putExtras(bundle);
                    startActivity(intent);
                    finish();

                    //System.out.println("Todo Bien");
                } catch (JSONException e) {
                    //e.printStackTrace();
                    //System.out.println("Todo Malo");
                    //Toast.makeText(getApplicationContext(), "Mal", Toast.LENGTH_LONG).show();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                verInterfaz();

            }
        }) {
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> params = new HashMap<>();
                params.put("Content-Type", "application/json; charset=UTF-8");
                params.put("Authorization", key);
                return params;
            }
        };
        jsObjectRequest.setRetryPolicy(new DefaultRetryPolicy(
                DefaultRetryPolicy.DEFAULT_TIMEOUT_MS * 3,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        requestQueue.add(jsObjectRequest);

    }

    public void verRestablecer(View v) {
        inputCorreo.setVisibility(View.VISIBLE);
        botonRestablecer.setVisibility(View.VISIBLE);
    }

    public void restablecerCuenta(View v) {
        FirebaseAuth auth = FirebaseAuth.getInstance();
        String emailAddress = inputCorreo.getText().toString().trim();

        auth.sendPasswordResetEmail(emailAddress)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            String message = "Se ha enviado un correo electronico con un enlace para restablecer tu contraseña";
                            AlertDialog alertDialog = new AlertDialog.Builder(context).create();
                            alertDialog.setMessage(message);
                            alertDialog.show();
                        } else {
                            String message = "Hubo un problema al enviar el enlace para restablecer tu contraseña";
                            AlertDialog alertDialog = new AlertDialog.Builder(context).create();
                            alertDialog.setMessage(message);
                            alertDialog.show();
                        }
                    }
                });
    }

    ////////////////////// LOGIN CON GOOGLE
    private void signIn() {
        Intent signInIntent = Auth.GoogleSignInApi.getSignInIntent(googleApiClient);
        startActivityForResult(signInIntent, Constants.RC_SIGN_IN);
        signInButton.setEnabled(false);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        // Result returned from launching the Intent from GoogleSignInApi.getSignInIntent(...);
        if (requestCode == Constants.RC_SIGN_IN) {
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            try {
                // Google Sign In was successful, authenticate with Firebase
                GoogleSignInAccount account = task.getResult(ApiException.class);
                if (account != null) {
                    firebaseAuthWithGoogle(account);
                }
            } catch (ApiException e) {
                // Google Sign In failed, update UI appropriately

                // ...
            }
        }
    }

    private void firebaseAuthWithGoogle(GoogleSignInAccount acct) {

        AuthCredential credential = GoogleAuthProvider.getCredential(acct.getIdToken(), null);
        auth.signInWithCredential(credential)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            userG = auth.getCurrentUser();

                            progressBar.setVisibility(View.VISIBLE);

                            /*System.out.println(userG.getDisplayName());
                            System.out.println(userG.getEmail());
                            System.out.println(userG.getUid());*/

                            FirebaseUser mUser = FirebaseAuth.getInstance().getCurrentUser();
                            if (mUser != null) {
                                mUser.getIdToken(true)
                                        .addOnCompleteListener(new OnCompleteListener<GetTokenResult>() {
                                            public void onComplete(@NonNull Task<GetTokenResult> task) {
                                                if (task.isSuccessful()) {
                                                    idToken = Objects.requireNonNull(task.getResult()).getToken();
                                                    getJSONVolley(userG, idToken);
                                                    // Send token to your backend via HTTPS
                                                    // ...
                                                }
                                            }
                                        });
                            }


                            //loginDjango(user.getUid(),2);


                        }  // If sign in fails, display a message to the user.


                        // ...
                    }
                });
    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.sign_in:
                signIn();
                break;
            case R.id.tfFecha:
                obtenerFecha(tffecha);
                break;
        }
    }

    private void obtenerFecha(final EditText editText) {

        DatePickerDialog recogerFecha = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                //Esta variable lo que realiza es aumentar en uno el mes ya que comienza desde 0 = enero
                final int mesActual = month + 1;

                //Formateo el día obtenido: antepone el 0 si son menores de 10
                String diaFormateado = (dayOfMonth < 10) ? Constants.CERO + String.valueOf(dayOfMonth) : String.valueOf(dayOfMonth);

                //Formateo el mes obtenido: antepone el 0 si son menores de 10
                String mesFormateado = (mesActual < 10) ? Constants.CERO + String.valueOf(mesActual) : String.valueOf(mesActual);
                Calendar calendar = Calendar.getInstance();
                calendar.set(year, month, dayOfMonth);

                //Muestro la fecha con el formato deseado
                String fecha = String.valueOf(year) + Constants.GUION + mesFormateado + Constants.GUION + diaFormateado;
                editText.setText(fecha);
                anio = year;
                mes = month;
                dia = dayOfMonth;
            }
            //Estos valores deben ir en ese orden, de lo contrario no mostrara la fecha actual
        }, anio, mes, dia);

        //Muestro el widget
        recogerFecha.show();

    }

    public void verInterfaz() {
        progressBar.setVisibility(View.GONE);

        linearLayout.setVisibility(View.VISIBLE);
        linearLayout.removeAllViews();
        linearLayout.addView(layout_Completar);
    }

    public void crearCuenta(FirebaseUser user) {
        if (alerts.isConnected()) {
            ValidarTextos validarTextos = new ValidarTextos();
            boolean fechavalido = validarTextos.validateBlank(tffecha, this);

            boolean telefonovalido = true;
            if (!ettelefono.getText().toString().trim().equals("")) {
                telefonovalido = validarTextos.validatePhone(ettelefono, this);
            }
            if (fechavalido && telefonovalido) {
                final String uid = user.getUid();
                final String nombre = user.getDisplayName();
                final String email = user.getEmail();
                final String foto_url = "" + user.getPhotoUrl();
                final String fecha_nacimiento = tffecha.getText().toString().trim();
                final String telefono = ettelefono.getText().toString().trim(); //Dato a completar
                String genero = spGenero.getSelectedItem() + "";
                String departamento = spDepartamento.getSelectedItem() + "";
                String municipio = "";
                if (spMunicipio.getVisibility() != View.GONE) {
                    municipio = spMunicipio.getSelectedItem() + "";
                }

                Usuario usuario = new Usuario();
                usuario.setUid(uid);
                usuario.setNombre(nombre);
                usuario.setEmail(email);
                usuario.setFoto(foto_url);
                usuario.setFecha(fecha_nacimiento);
                usuario.setTelefono(telefono);
                usuario.setGenero(genero);
                usuario.setDepartamento(departamento);
                usuario.setMunicipio(municipio);

                postJSONVolley(usuario, idToken);
            }
        }
    }

    public void postJSONVolley(final Usuario usuario, final String idToken) {
        botonContinuar.setEnabled(false);
        botonContinuar.setBackgroundResource(R.color.darker_gray);
        try {
            RequestQueue requestQueue = Volley.newRequestQueue(this);

            JSONObject jsonBody = new JSONObject();
            jsonBody.put("uid", usuario.getUid());
            jsonBody.put("nombre", usuario.getNombre());
            jsonBody.put("foto", usuario.getFoto());
            jsonBody.put("fecha_nacimiento", usuario.getFecha());
            jsonBody.put("telefono", usuario.getTelefono());
            jsonBody.put("email", usuario.getEmail());
            jsonBody.put("genero", usuario.getGenero());
            jsonBody.put("departamento", usuario.getDepartamento());
            jsonBody.put("municipio", usuario.getMunicipio());
            final String mRequestBody = jsonBody.toString();

            //System.out.println("JSON: " + mRequestBody);

            StringRequest stringRequest = new StringRequest(Request.Method.POST, Constants.URL + Constants.URL_USUARIOS_API, new Response.Listener<String>() {

                @Override
                public void onResponse(String response) {
                    getJSONUsuario(idToken, usuario);
                    /*Intent intent = new Intent(LoginActivity.this, ContainerActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
                    Bundle bundle = new Bundle();
                    bundle.putSerializable("usuario", usuario);
                    bundle.putString("key", idToken);
                    intent.putExtras(bundle);
                    startActivity(intent);
                    finish();*/
                }
            }, new Response.ErrorListener() {

                @Override
                public void onErrorResponse(VolleyError error) {
                    //System.out.println(error.toString());
                    String mensaje = "Hay un error al crear tu " +
                            "cuenta, intenta de nuevo";
                    errorAlertDialog = alerts.createErrorAlert(400, mensaje).create();
                    errorAlertDialog.show();
                    progressDialog.dismiss();
                    botonContinuar.setEnabled(true);
                    botonContinuar.setBackgroundResource(R.color.colorPrimaryDark);
                }
            }) {
                @Override
                public String getBodyContentType() {
                    return "application/json; charset=utf-8";
                }

                @Override
                public byte[] getBody() {
                    return mRequestBody == null ? null : mRequestBody.getBytes(StandardCharsets.UTF_8);
                }

                @Override
                protected Response<String> parseNetworkResponse(NetworkResponse response) {
                    String responseString = "";
                    if (response != null) {
                        responseString = String.valueOf(response.statusCode);
                    }
                    return Response.success(responseString, HttpHeaderParser.parseCacheHeaders(response));
                }
            };

            requestQueue.add(stringRequest);
        } catch (JSONException e) {
            //e.printStackTrace();
        }
    }

    private void getJSONUsuario(final String key, Usuario usuario) {
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        String url = Constants.URL + Constants.URL_USUARIOS_API + usuario.getUid() + Constants.GET_JSON;
        JsonObjectRequest jsObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {
                    Usuario usuario = new Usuario(response);
                    new TagsDialog(context, key, usuario);
                } catch (JSONException e) {
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                botonContinuar.setEnabled(true);
                botonContinuar.setBackgroundResource(R.color.colorPrimaryDark);
            }
        }) {
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> params = new HashMap<>();
                params.put("Content-Type", "application/json; charset=UTF-8");
                params.put("Authorization", key);
                return params;
            }
        };
        jsObjectRequest.setRetryPolicy(new DefaultRetryPolicy(
                DefaultRetryPolicy.DEFAULT_TIMEOUT_MS * 3,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        requestQueue.add(jsObjectRequest);

    }

}
