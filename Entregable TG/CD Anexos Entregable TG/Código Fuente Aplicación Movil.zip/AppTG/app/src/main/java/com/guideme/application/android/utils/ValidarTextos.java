package com.guideme.application.android.utils;

import android.app.Activity;
import android.util.Patterns;
import android.widget.EditText;

import com.guideme.application.android.R;

public class ValidarTextos {

    public ValidarTextos() {
    }

    public boolean validateBlank(EditText editText, Activity activity) {
        String text = editText.getText().toString().trim();
        if (isBlank(text)) {
            editText.setError(activity.getResources().getString(R.string.campo_vacio));
            editText.requestFocus();
            return false;
        } else {
            editText.setError(null);
            return true;
        }
    }

    public boolean validateEmail(EditText editText, Activity activity) {
        String email = editText.getText().toString().trim();
        if (!validateBlank(editText, activity)) {
            return false;
        } else if (!isEmail(email)) {
            editText.setError(activity.getResources().getString(R.string.email_incorrecto));
            editText.requestFocus();
            return false;
        } else {
            editText.setError(null);
            return true;
        }

    }

    public boolean validatePhone(EditText editText, Activity activity) {
        String phone = editText.getText().toString().trim();
        if (validateBlank(editText, activity)) {
            return true;
        } else if (!isPhone(phone)) {
            editText.setError(activity.getResources().getString(R.string.telefono_incorrecto));
            editText.requestFocus();
            return false;
        } else {
            editText.setError(null);
            return true;
        }

    }

    public boolean validateWEB(EditText editText, Activity activity) {
        String web = editText.getText().toString().trim();
        if (validateBlank(editText, activity)) {
            return true;
        } else if (!isWeb(web)) {
            editText.setError(activity.getResources().getString(R.string.telefono_incorrecto));
            editText.requestFocus();
            return false;
        } else {
            editText.setError(null);
            return true;
        }

    }

    public boolean validatePassword(EditText password, EditText confirmPassword, Activity activity) {
        String pass = password.getText().toString().trim();
        String conf = confirmPassword.getText().toString().trim();
        if (validateBlank(password, activity) && validateBlank(confirmPassword, activity)) {
            if(pass.length() >= 6) {
                if (pass.equals(conf)) {
                    return true;
                } else {
                    confirmPassword.setError(activity.getResources().getString(R.string.password_no_match));
                    confirmPassword.requestFocus();
                    return false;
                }
            } else{
                password.setError(activity.getResources().getString(R.string.invalid_password_length));
                password.requestFocus();
                return false;
            }
        } else {
            return false;
        }

    }

    public boolean isBlank(String text){
        return text.isEmpty();
    }

    public boolean isEmail(String text){
        return Patterns.EMAIL_ADDRESS.matcher(text).matches();
    }

    public boolean isPhone(String text){
        return Patterns.PHONE.matcher(text).matches();
    }

    public boolean isWeb(String text){
        return Patterns.WEB_URL.matcher(text).matches();
    }


}
