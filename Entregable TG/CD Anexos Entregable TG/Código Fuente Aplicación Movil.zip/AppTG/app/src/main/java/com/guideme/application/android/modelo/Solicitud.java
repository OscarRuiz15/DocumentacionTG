package com.guideme.application.android.modelo;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.Serializable;
import java.util.ArrayList;

public class Solicitud implements Serializable {

    private int id;
    private Usuario usuario;
    private String nombre_lugar;
    private String direccion;
    private String telefono;
    private ArrayList<String> email;
    private String informacion;
    private boolean aceptado;
    private ArrayList<String> hora_abierto;
    private ArrayList<String> hora_cerrado;
    private ArrayList<String> dias_servicio;
    private String foto;
    private Double latitud;
    private Double longitud;

    public Solicitud(int id, Usuario usuario, String nombre_lugar, String direccion, String telefono, ArrayList<String> email, String informacion, boolean aceptado, ArrayList<String> hora_abierto, ArrayList<String> hora_cerrado, ArrayList<String> dias_servicio, String foto, Double latitud, Double longitud) {
        this.id = id;
        this.usuario = usuario;
        this.nombre_lugar = nombre_lugar;
        this.direccion = direccion;
        this.telefono = telefono;
        this.email = email;
        this.informacion = informacion;
        this.aceptado = aceptado;
        this.hora_abierto = hora_abierto;
        this.hora_cerrado = hora_cerrado;
        this.dias_servicio = dias_servicio;
        this.foto = foto;
        this.latitud = latitud;
        this.longitud = longitud;
    }

    public Solicitud(JSONObject jsonObject) throws JSONException {
        this.id = jsonObject.getInt("id");
        this.nombre_lugar = jsonObject.getString("nombre_lugar");
        this.direccion = jsonObject.getString("direccion");
        this.telefono = jsonObject.getString("telefono");
        this.informacion = jsonObject.getString("informacion");
        this.email = stringJSONArray(jsonObject.getJSONArray("email"));
        this.hora_abierto = stringJSONArray(jsonObject.getJSONArray("hora_abierto"));
        this.hora_cerrado = stringJSONArray(jsonObject.getJSONArray("hora_cerrado"));
        this.dias_servicio = stringJSONArray(jsonObject.getJSONArray("dias_servicio"));
        this.foto = jsonObject.getString("foto");
        this.latitud = jsonObject.getDouble("latitud");
        this.longitud = jsonObject.getDouble("longitud");
    }

    public Solicitud() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public String getNombre_lugar() {
        return nombre_lugar;
    }

    public void setNombre_lugar(String nombre_lugar) {
        this.nombre_lugar = nombre_lugar;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public ArrayList<String> getEmail() {
        return email;
    }

    public void setEmail(ArrayList<String> email) {
        this.email = email;
    }

    public String getInformacion() {
        return informacion;
    }

    public void setInformacion(String informacion) {
        this.informacion = informacion;
    }

    public boolean isAceptado() {
        return aceptado;
    }

    public void setAceptado(boolean aceptado) {
        this.aceptado = aceptado;
    }

    public ArrayList<String> getHora_abierto() {
        return hora_abierto;
    }

    public void setHora_abierto(ArrayList<String> hora_abierto) {
        this.hora_abierto = hora_abierto;
    }

    public ArrayList<String> getHora_cerrado() {
        return hora_cerrado;
    }

    public void setHora_cerrado(ArrayList<String> hora_cerrado) {
        this.hora_cerrado = hora_cerrado;
    }

    public ArrayList<String> getDias_servicio() {
        return dias_servicio;
    }

    public void setDias_servicio(ArrayList<String> dias_servicio) {
        this.dias_servicio = dias_servicio;
    }

    public String getFoto() {
        return foto;
    }

    public void setFoto(String foto) {
        this.foto = foto;
    }

    public Double getLatitud() {
        return latitud;
    }

    public void setLatitud(Double latitud) {
        this.latitud = latitud;
    }

    public Double getLongitud() {
        return longitud;
    }

    public void setLongitud(Double longitud) {
        this.longitud = longitud;
    }

    private JSONArray stringListToJSONArray(ArrayList<String> lista) {
        JSONArray jsonArray = new JSONArray();
        for (String str : lista) {
            jsonArray.put(str);
        }
        return jsonArray;
    }

    private ArrayList<String> stringJSONArray(JSONArray jsonArray) {
        ArrayList<String> lista = new ArrayList<>();
        for (int i = 0; i < jsonArray.length(); i++) {
            try {
                String str = jsonArray.getString(i);
                lista.add(str);
            } catch (JSONException e) {
                //e.printStackTrace();
            }
        }
        return lista;
    }

    public JSONObject getJsonObject() throws JSONException {

        JSONObject jsonObject = new JSONObject();
        jsonObject.put("id", id);
        jsonObject.put("nombre_lugar", nombre_lugar);
        jsonObject.put("usuario", usuario.getId());
        jsonObject.put("direccion", direccion);
        jsonObject.put("telefono", telefono);
        jsonObject.put("informacion", informacion);
        jsonObject.put("email", stringListToJSONArray(email));
        jsonObject.put("aceptado", aceptado);
        jsonObject.put("hora_abierto", stringListToJSONArray(hora_abierto));
        jsonObject.put("hora_cerrado", stringListToJSONArray(hora_cerrado));
        jsonObject.put("dias_servicio", stringListToJSONArray(dias_servicio));
        jsonObject.put("foto", foto);
        jsonObject.put("latitud", latitud);
        jsonObject.put("longitud", longitud);
        return jsonObject;

    }
}
