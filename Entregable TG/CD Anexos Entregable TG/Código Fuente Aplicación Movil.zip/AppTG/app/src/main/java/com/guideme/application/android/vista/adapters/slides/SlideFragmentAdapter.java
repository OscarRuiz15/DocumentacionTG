package com.guideme.application.android.vista.adapters.slides;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

import java.util.ArrayList;

public class SlideFragmentAdapter extends FragmentPagerAdapter {

    private ArrayList<Fragment> fragments;

    public SlideFragmentAdapter(FragmentManager fm) {
        super(fm);
        fragments = new ArrayList<>();
    }

    @Override
    public Fragment getItem(int position) {
        return fragments.get(position);
    }

    @Override
    public int getCount() {
        return fragments.size();
    }

    public void agregarFragment(Fragment fragment) {

        fragments.add(fragment);
    }
}
