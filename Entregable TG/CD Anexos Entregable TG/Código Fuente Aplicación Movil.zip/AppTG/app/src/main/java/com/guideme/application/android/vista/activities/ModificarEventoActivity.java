package com.guideme.application.android.vista.activities;


import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v4.app.NavUtils;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TimePicker;

import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.guideme.application.android.R;
import com.guideme.application.android.modelo.Evento;
import com.guideme.application.android.modelo.Lugar;
import com.guideme.application.android.modelo.Usuario;
import com.guideme.application.android.utils.Alerts;
import com.guideme.application.android.utils.Constants;
import com.guideme.application.android.utils.ControladorFechas;
import com.guideme.application.android.utils.ValidarTextos;
import com.guideme.application.android.vista.fragments.GlideApp;

import org.json.JSONException;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class ModificarEventoActivity extends AppCompatActivity implements View.OnClickListener {
    public final Calendar c = Calendar.getInstance();

    final int hora = c.get(Calendar.HOUR_OF_DAY);
    final int minuto = c.get(Calendar.MINUTE);

    int mes = c.get(Calendar.MONTH);
    int dia = c.get(Calendar.DAY_OF_MONTH);
    int anio = c.get(Calendar.YEAR);

    private EditText etnombre;
    private EditText etdescripicon;
    private EditText etdireccion;
    private EditText tipoevento;
    private EditText ethorainicio;
    private EditText ethorafin;
    private EditText etfechainicio;
    private EditText etfechafin;
    private Button btnCrear;
    private ImageView imagen;
    private Evento evento;
    private Lugar lugar;
    private Usuario usuario;
    StorageReference storageReference;
    private Uri getAbsolutePhotoPath;

    private AlertDialog alertDialog;
    private AlertDialog alertDialog2;

    private String key;
    private int camino;

    private AlertDialog errorAlertDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modificar_evento);

        etnombre = findViewById(R.id.editTextNombre);
        etdescripicon = findViewById(R.id.editTextDescripcion);
        etdireccion = findViewById(R.id.editTextDireccion);
        tipoevento = findViewById(R.id.editTextTipo);
        ethorainicio = findViewById(R.id.editTextHoraInicio);
        ethorafin = findViewById(R.id.editTextHoraFin);
        etfechainicio = findViewById(R.id.editTextFechaInicio);
        etfechafin = findViewById(R.id.editTextFechaFin);
        imagen = findViewById(R.id.imagenEvento);
        btnCrear = findViewById(R.id.btCrearEvento);
        btnCrear.setText(getResources().getString(R.string.modificar_evento));

        Bundle bundle = getIntent().getExtras();

        if (savedInstanceState != null) {
            evento = (Evento) savedInstanceState.getSerializable("evento");
            lugar = (Lugar) savedInstanceState.getSerializable("lugar");
            usuario = (Usuario) savedInstanceState.getSerializable("usuario");
            camino = savedInstanceState.getInt("camino");
            key = savedInstanceState.getString("key");
        } else {
            evento = (Evento) (bundle != null ? bundle.getSerializable("evento") : null);
            lugar = (Lugar) (bundle != null ? bundle.getSerializable("lugar") : null);
            usuario = (Usuario) (bundle != null ? bundle.getSerializable("usuario") : null);
            camino = bundle != null ? bundle.getInt("camino") : 0;
            key = bundle != null ? bundle.getString("key") : null;
        }

        FirebaseStorage storage = FirebaseStorage.getInstance();
        storageReference = storage.getReferenceFromUrl(evento.getFoto());

        ponerElementos(evento);

        btnCrear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cambiarDatos();
            }
        });


        imagen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                agregarImagen();
            }
        });

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Evento modificado");
        builder.setMessage("El evento ha sido modificado con éxito");
        builder.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                irDetallesEvento(evento);
            }
        });
        alertDialog = builder.create();

        AlertDialog.Builder builder2 = new AlertDialog.Builder(this);
        builder2.setTitle("Error al modificar evento");
        builder2.setMessage("Las fechas de inicio y fin del evento no puede ser anterior a la fecha actual");
        builder2.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                //irDetallesEvento(evento);
            }
        });
        alertDialog2 = builder2.create();
        ActionBar actionBar = new ActionBar();
        String title = getResources().getString(R.string.modificar) + " " + evento.getNombre();
        actionBar.showToolbar(title, true, this);

        ethorainicio.setOnClickListener(this);
        ethorafin.setOnClickListener(this);
        etfechainicio.setOnClickListener(this);
        etfechafin.setOnClickListener(this);
    }

    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.editTextHoraInicio:
                obtenerHora(ethorainicio);
                break;
            case R.id.editTextHoraFin:
                obtenerHora(ethorafin);
                break;
            case R.id.editTextFechaInicio:
                obtenerFecha(etfechainicio);
                break;
            case R.id.editTextFechaFin:
                obtenerFecha(etfechafin);
                break;

        }
    }

    private void obtenerHora(final EditText editText) {
        TimePickerDialog recogerHora = new TimePickerDialog(this, new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                //Formateo el hora obtenido: antepone el 0 si son menores de 10
                String horaFormateada = (hourOfDay < 10) ? String.valueOf(Constants.CERO + hourOfDay) : String.valueOf(hourOfDay);
                //Formateo el minuto obtenido: antepone el 0 si son menores de 10
                String minutoFormateado = (minute < 10) ? String.valueOf(Constants.CERO + minute) : String.valueOf(minute);
                //Obtengo el valor a.m. o p.m., dependiendo de la selección del usuario

                //Muestro la hora con el formato deseado
                String hora = horaFormateada + Constants.DOS_PUNTOS + minutoFormateado;
                editText.setText(hora);
            }
            //Estos valores deben ir en ese orden
            //Al colocar en false se muestra en formato 12 horas y true en formato 24 horas
            //Pero el sistema devuelve la hora en formato 24 horas
        }, hora, minuto, true);

        recogerHora.show();
    }

    private void obtenerFecha(final EditText editText) {
        final ControladorFechas controladorFechas = new ControladorFechas();
        DatePickerDialog recogerFecha = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                final int mesActual = month + 1;

                //Formateo el día obtenido: antepone el 0 si son menores de 10
                String diaFormateado = (dayOfMonth < 10) ? Constants.CERO + String.valueOf(dayOfMonth) : String.valueOf(dayOfMonth);

                //Formateo el mes obtenido: antepone el 0 si son menores de 10
                String mesFormateado = (mesActual < 10) ? Constants.CERO + String.valueOf(mesActual) : String.valueOf(mesActual);
                Calendar calendar = Calendar.getInstance();
                calendar.set(year, month, dayOfMonth);

                //Muestro la fecha con el formato deseado
                String fecha = year + Constants.GUION + mesFormateado + Constants.GUION + diaFormateado;
                editText.setText(fecha);
                anio = year;
                mes = month;
                dia = dayOfMonth;
            }
            //Estos valores deben ir en ese orden, de lo contrario no mostrara la fecha actual
        }, anio, mes, dia);
        //Muestro el widget
        recogerFecha.show();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                Intent intent = NavUtils.getParentActivityIntent(this);
                if (intent != null) {
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    NavUtils.navigateUpTo(this, intent);
                }
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onSaveInstanceState(Bundle savedInstanceState) {
        savedInstanceState.putSerializable("evento", evento);
        savedInstanceState.putSerializable("lugar", lugar);
        savedInstanceState.putSerializable("usuario", usuario);
        savedInstanceState.putInt("camino", camino);
        savedInstanceState.putString("key", key);

        super.onSaveInstanceState(savedInstanceState);
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);

        evento = (Evento) savedInstanceState.getSerializable("evento");
        lugar = (Lugar) savedInstanceState.getSerializable("lugar");
        usuario = (Usuario) savedInstanceState.getSerializable("usuario");
        camino = savedInstanceState.getInt("camino");
        key = savedInstanceState.getString("key");
    }

    public void ponerElementos(Evento evento) {
        GlideApp.with(this)
                .load(storageReference)
                .into(imagen);

        etnombre.setText(evento.getNombre());
        etdescripicon.setText(evento.getDescripcion());
        etdireccion.setText(evento.getDireccion());
        tipoevento.setText(evento.getTipo());
        ethorainicio.setText(evento.getHorainicio());
        ethorafin.setText(evento.getHorafin());
        etfechainicio.setText(evento.getFechainicio());
        etfechafin.setText(evento.getFechafin());

    }

    public void cambiarDatos() {
        final Alerts alerts = new Alerts(this);

        if (alerts.isConnected()) {
            ValidarTextos validarTextos = new ValidarTextos();
            boolean nombrevalido = validarTextos.validateBlank(etnombre, this);
            boolean descripcionvalido = validarTextos.validateBlank(etdescripicon, this);
            boolean direccionvalido = validarTextos.validateBlank(etdireccion, this);
            boolean tipovalido = validarTextos.validateBlank(tipoevento, this);
            boolean fechainiciovalido = validarTextos.validateBlank(etfechainicio, this);
            boolean fechafinvalido = validarTextos.validateBlank(etfechafin, this);
            boolean horainiciovalido = validarTextos.validateBlank(ethorainicio, this);
            boolean horafinvalido = validarTextos.validateBlank(ethorafin, this);

            if (nombrevalido && descripcionvalido && direccionvalido && tipovalido && fechainiciovalido && fechafinvalido && horainiciovalido && horafinvalido) {

                SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
                ControladorFechas controladorFechas = new ControladorFechas();
                String fecha_actual = controladorFechas.getDate() + "T" + controladorFechas.getHour() + "Z";
                String fecha_inicio_evento = etfechainicio.getText().toString().trim() + "T" + ethorainicio.getText().toString().trim();
                String fecha_fin_evento = etfechafin.getText().toString().trim() + "T" + ethorafin.getText().toString().trim();

                if (fecha_inicio_evento.length() == 16) {
                    fecha_inicio_evento += ":00Z";
                } else {
                    fecha_inicio_evento += "Z";
                }

                if (fecha_fin_evento.length() == 16) {
                    fecha_fin_evento += ":00Z";
                } else {
                    fecha_fin_evento += "Z";
                }

                //System.out.println(fecha_inicio_evento);
                //System.out.println(fecha_fin_evento);
                Date dateActual = null;
                Date dateInicioEvento = null;
                Date dateFinEvento = null;
                try {
                    dateActual = format.parse(fecha_actual);
                    dateInicioEvento = format.parse(fecha_inicio_evento);
                    dateFinEvento = format.parse(fecha_fin_evento);
                } catch (ParseException e) {
                    e.printStackTrace();
                }


                if (dateInicioEvento.getTime() >= dateActual.getTime() && dateFinEvento.getTime() >= dateActual.getTime()) {
                    final String nombre = etnombre.getText().toString().trim();
                    final String descripcion = etdescripicon.getText().toString().trim();
                    final String direccion = etdireccion.getText().toString().trim();
                    final int idlugar = evento.getLugar();
                    final String tipo = tipoevento.getText().toString().trim();
                    final String fechainicio = etfechainicio.getText().toString().trim();
                    final String fechafin = etfechafin.getText().toString().trim();
                    final String horainicio = ethorainicio.getText().toString().trim();
                    final String horafin = ethorafin.getText().toString().trim();

                    evento.setNombre(nombre);
                    evento.setDescripcion(descripcion);
                    evento.setDireccion(direccion);
                    evento.setLugar(idlugar);
                    evento.setTipo(tipo);
                    evento.setFechainicio(fechainicio);
                    evento.setFechafin(fechafin);
                    evento.setHorainicio(horainicio);
                    evento.setHorafin(horafin);


                    if (getAbsolutePhotoPath != null) {
                        this.storageReference.delete().addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void aVoid) {
                                String foto = uploadPhoto("" + evento.getId());
                                evento.setFoto(foto);
                                putJSONVolley(evento);
                            }
                        }).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {

                            }
                        });
                    } else {
                        putJSONVolley(evento);
                    }
                } else {
                    alertDialog2.show();
                }
            }
        }
    }

    private String uploadPhoto(String child) {
        FirebaseStorage firebaseStorage = FirebaseStorage.getInstance();
        StorageReference storageReference = firebaseStorage.getReferenceFromUrl(Constants.FIREBASE_STORAGE_URL_EVENTOS);

        StorageReference imageReference = storageReference.child(child);

        UploadTask uploadTask = imageReference.putFile(getAbsolutePhotoPath);

        uploadTask.addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                /*Toast.makeText(ModificarEventoActivity.this, "Mal",
                        Toast.LENGTH_SHORT).show();*/

            }
        }).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
            }
        });
        return Constants.FIREBASE_STORAGE_URL_EVENTOS + Constants.BAR + child;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            Uri path = data.getData();
            imagen.setImageURI(path);
            getAbsolutePhotoPath = path;
        }
    }

    public void putJSONVolley(Evento evento) {
        btnCrear.setEnabled(false);
        btnCrear.setBackgroundResource(R.color.darker_gray);
        try {
            final Alerts alerts = new Alerts(this);

            RequestQueue requestQueue = Volley.newRequestQueue(this);

            JSONObject jsonBody = evento.getJsonObject();

            final String mRequestBody = jsonBody.toString();
            String url = Constants.URL + Constants.URL_EVENTOS_API + evento.getId() + Constants.BAR;

            StringRequest stringRequest = new StringRequest(Request.Method.PUT, url, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    btnCrear.setEnabled(true);
                    btnCrear.setBackgroundResource(R.color.colorPrimaryDark);
                    getEventoJSONVolley();
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    int statusCode = error.networkResponse.statusCode;
                    String mensaje = "No se pudo modificar el evento";
                    errorAlertDialog = alerts.createErrorAlert(statusCode, mensaje).create();
                    errorAlertDialog.show();
                    btnCrear.setEnabled(true);
                    btnCrear.setBackgroundResource(R.color.colorPrimaryDark);
                }
            }) {
                @Override
                public Map<String, String> getHeaders() {
                    Map<String, String> params = new HashMap<>();
                    params.put("Content-Type", "application/json; charset=UTF-8");
                    params.put("Authorization", key);
                    return params;
                }

                @Override
                public String getBodyContentType() {
                    return "application/json; charset=utf-8";
                }

                @Override
                public byte[] getBody() {
                    return mRequestBody == null ? null : mRequestBody.getBytes(StandardCharsets.UTF_8);
                }

                @Override
                protected Response<String> parseNetworkResponse(NetworkResponse response) {
                    String responseString = "";
                    if (response != null) {
                        responseString = String.valueOf(response.statusCode);
                    }
                    return Response.success(responseString, HttpHeaderParser.parseCacheHeaders(response));
                }
            };

            requestQueue.add(stringRequest);

        } catch (JSONException e) {
            //e.printStackTrace();
        }
    }

    public void getEventoJSONVolley() {
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        String url = Constants.URL + Constants.URL_EVENTOS_API + evento.getId() + Constants.BAR;

        final JsonObjectRequest jsObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {
                    evento = new Evento(response);
                    alertDialog.show();
                    //irDetallesEvento(evento);
                } catch (JSONException e) {
                    //e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                //Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_LONG).show();
                //Log.d("TAG", "Error Respuesta en JSON: " + error.getMessage());

            }
        }) {
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> params = new HashMap<>();
                params.put("Content-Type", "application/json; charset=UTF-8");
                params.put("Authorization", key);
                return params;
            }
        };

        requestQueue.add(jsObjectRequest);
    }

    public void irDetallesEvento(Evento evento) {
        Intent intent = new Intent(this, DetallesEventoActivity.class);
        Bundle bundle = new Bundle();
        bundle.putSerializable("evento", evento);
        bundle.putSerializable("usuario", usuario);
        bundle.putSerializable("lugar", lugar);
        bundle.putInt("camino", camino);
        bundle.putString("key", key);
        intent.putExtras(bundle);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
    }

    public void agregarImagen() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (inputMethodManager != null) {
            inputMethodManager.hideSoftInputFromWindow(etnombre.getWindowToken(), 0);
            inputMethodManager.hideSoftInputFromWindow(etdescripicon.getWindowToken(), 0);
            inputMethodManager.hideSoftInputFromWindow(etdireccion.getWindowToken(), 0);
            inputMethodManager.hideSoftInputFromWindow(tipoevento.getWindowToken(), 0);
        }

        startActivityForResult(Intent.createChooser(intent, "Selecciona la Aplicación"), 10);

    }
}