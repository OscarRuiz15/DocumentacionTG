package com.guideme.application.android.utils;

import android.content.DialogInterface;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.v7.app.AlertDialog;
import android.content.Context;

import com.guideme.application.android.modelo.Solicitud;
import com.guideme.application.android.vista.adapters.recycler.SolicitudesAdapterRecycler;

public class Alerts {
    private Context context;

    public Alerts(Context context) {
        this.context = context;
    }

    public AlertDialog.Builder createErrorAlert(int statusCode, String mensaje) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Hay un error");
        if (statusCode >= 400 && statusCode < 500) {
            builder.setMessage(mensaje);
        }
        if (statusCode >= 500) {
            builder.setMessage("Existe un error en el servidor, estamos trabajando para solucionarlo");
        }

        builder.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });

        return builder;
    }

    public boolean isConnected() {
        ConnectivityManager connectivityManager = (ConnectivityManager)
                context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager != null ? connectivityManager.getActiveNetworkInfo() : null;
        if (networkInfo != null && networkInfo.isConnected()) {
            return true;
        } else {
            AlertDialog alertDialog;
            AlertDialog.Builder builder = new AlertDialog.Builder(context);
            builder.setTitle("No hay conexion a internet");
            builder.setMessage("Conectate a internet poder realizar la operación");
            builder.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {

                }
            });
            alertDialog = builder.create();
            alertDialog.show();
            return false;
        }


    }

    public void menorDeEdadAlert() {
        AlertDialog alertDialog;
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("No puedes ingresar a este sitio");
        builder.setMessage("Este sitio no está permitido para menores de edad");
        builder.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        alertDialog = builder.create();
        alertDialog.show();


    }

    public void confirmAlert(final Solicitud solicitud, final SolicitudesAdapterRecycler solicitudesAdapterRecycler) {

        AlertDialog alertDialog;
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Confirmar");
        builder.setMessage("¿Desea eliminar la solicitud para " + solicitud.getNombre_lugar() + "?");
        builder.setPositiveButton("Si", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                solicitudesAdapterRecycler.eliminarSolicitud(solicitud);
            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        alertDialog = builder.create();
        alertDialog.show();


    }
}
