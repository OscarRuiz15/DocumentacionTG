package com.guideme.application.android.vista.activities;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.NavUtils;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.guideme.application.android.utils.Constants;
import com.guideme.application.android.R;
import com.guideme.application.android.modelo.Lugar;
import com.guideme.application.android.modelo.Suscripcion;
import com.guideme.application.android.vista.adapters.recycler.SuscriptoresAdapterRecycler;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class VerSuscriptoresActivity extends AppCompatActivity {

    SuscriptoresAdapterRecycler suscriptoresAdapterRecycler;
    private RecyclerView recyclerView;
    private Lugar lugar;
    private TextView tvNotFound;
    Context context = this;
    private String key;

    private ArrayList<Suscripcion> suscripciones;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ver_suscriptores);

        Bundle bundle = getIntent().getExtras();

        if (savedInstanceState != null) {
            lugar = (Lugar) savedInstanceState.getSerializable("lugar");
            key = savedInstanceState.getString("key");
        } else {
            lugar = (Lugar) (bundle != null ? bundle.getSerializable("lugar") : null);
            key = bundle != null ? bundle.getString("key") : null;
        }

        suscripciones = new ArrayList<>();

        recyclerView = findViewById(R.id.recyclerSuscriptores);
        tvNotFound = findViewById(R.id.tvNotFound);

        ActionBar actionBar = new ActionBar();
        actionBar.showToolbar(lugar.getNombre(), true, this);

        consultarSuscriptores();

    }

    @Override
    protected void onSaveInstanceState(Bundle savedInstanceState) {
        savedInstanceState.putSerializable("lugar", lugar);
        savedInstanceState.putString("key", key);

        super.onSaveInstanceState(savedInstanceState);
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);

        lugar = (Lugar) savedInstanceState.getSerializable("lugar");
        key = savedInstanceState.getString("key");
    }

    private void consultarSuscriptores() {
        String url = Constants.URL + Constants.URL_SUSCRIPCIONES_API + Constants.CONSULTA_LUGAR + lugar.getId();
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        final JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, url, null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {

                for (int i = 0; i < response.length(); i++) {
                    try {
                        Suscripcion suscripcion = new Suscripcion(response.getJSONObject(i));
                        suscripciones.add(suscripcion);
                    } catch (JSONException e) {
                        //e.printStackTrace();
                    }
                }

                if (!suscripciones.isEmpty()) {
                    suscriptoresAdapterRecycler = new SuscriptoresAdapterRecycler(context, suscripciones);
                    LinearLayoutManager linearLayoutManager1 = new LinearLayoutManager(context);
                    recyclerView.setAdapter(suscriptoresAdapterRecycler);
                    recyclerView.setLayoutManager(linearLayoutManager1);
                } else {
                    tvNotFound.setVisibility(View.VISIBLE);
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                tvNotFound.setVisibility(View.VISIBLE);
            }
        }) {
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> params = new HashMap<>();
                params.put("Content-Type", "application/json; charset=UTF-8");
                params.put("Authorization", key);
                return params;
            }
        };
        jsonArrayRequest.setRetryPolicy(new DefaultRetryPolicy(
                DefaultRetryPolicy.DEFAULT_TIMEOUT_MS * 3,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        requestQueue.add(jsonArrayRequest);

    }

    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            Intent intent = NavUtils.getParentActivityIntent(this);
            if (intent != null) {
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                NavUtils.navigateUpTo(this, intent);
            }

            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
