package com.guideme.application.android.vista.activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.NavUtils;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import com.guideme.application.android.R;
import com.guideme.application.android.modelo.Evento;
import com.guideme.application.android.modelo.Usuario;
import com.guideme.application.android.vista.adapters.recycler.EventoAdapterRecycler;

import java.util.ArrayList;

public class VerEventosActivity extends AppCompatActivity {


    private ArrayList<Evento> eventos;
    private String key;
    private Usuario usuario;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ver_eventos);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        Bundle bundle = getIntent().getExtras();

        if (savedInstanceState != null) {
            eventos = (ArrayList<Evento>) savedInstanceState.getSerializable("eventos");
            usuario = (Usuario) savedInstanceState.getSerializable("usuario");
            key = savedInstanceState.getString("key");
        } else {
            eventos = (ArrayList<Evento>) bundle.getSerializable("eventos");
            usuario = (Usuario) bundle.getSerializable("usuario");
            key = bundle.getString("key");
        }
        TextView tvNotFound = findViewById(R.id.tvNotFound);

        if (eventos.isEmpty()) {
            tvNotFound.setVisibility(View.VISIBLE);
        }

        RecyclerView recyclerView = findViewById(R.id.recyclerEventos);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(linearLayoutManager);

        EventoAdapterRecycler eventoAdapterRecycler = new EventoAdapterRecycler(this, eventos, usuario, key);
        recyclerView.setAdapter(eventoAdapterRecycler);

        ActionBar actionBar = new ActionBar();
        actionBar.showToolbar("Eventos", true, this);
    }

    @Override
    protected void onSaveInstanceState(Bundle savedInstanceState) {
        savedInstanceState.putSerializable("eventos", eventos);
        savedInstanceState.putSerializable("usuario", usuario);
        savedInstanceState.putString("key", key);

        super.onSaveInstanceState(savedInstanceState);
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);

        eventos = (ArrayList<Evento>) savedInstanceState.getSerializable("eventos");
        usuario = (Usuario) savedInstanceState.getSerializable("usuario");
        key = savedInstanceState.getString("key");
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            Intent intent = NavUtils.getParentActivityIntent(this);
            if (intent != null) {
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                NavUtils.navigateUpTo(this, intent);
            }
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
