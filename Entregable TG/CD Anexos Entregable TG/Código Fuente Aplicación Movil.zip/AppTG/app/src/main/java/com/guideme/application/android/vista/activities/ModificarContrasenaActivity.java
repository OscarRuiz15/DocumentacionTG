package com.guideme.application.android.vista.activities;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.NavUtils;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.AnalogClock;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.guideme.application.android.R;
import com.guideme.application.android.modelo.Usuario;
import com.guideme.application.android.utils.Alerts;
import com.guideme.application.android.utils.ValidarTextos;

import static android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP;

public class ModificarContrasenaActivity extends AppCompatActivity implements GoogleApiClient.OnConnectionFailedListener {

    private EditText etpass;
    private EditText passconf;
    private Usuario usuario;
    private String key;
    private GoogleApiClient googleApiClient;
    private AlertDialog alertDialog;
    private Button btnGuardar;

    private Alerts alerts;

    private Context context = this;

    public ModificarContrasenaActivity() {
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modificar_contrasena);

        ActionBar actionBar = new ActionBar();
        actionBar.showToolbar("Modificar Contraseña", true, this);

        etpass = findViewById(R.id.password1);
        passconf = findViewById(R.id.password2);
        btnGuardar = findViewById(R.id.btnGuardar);

        Bundle bundle = getIntent().getExtras();
        if (savedInstanceState != null) {
            usuario = (Usuario) savedInstanceState.getSerializable("usuario");
            key = savedInstanceState.getString("key");
        } else {
            usuario = (Usuario) (bundle != null ? bundle.getSerializable("usuario") : null);
            key = bundle != null ? bundle.getString("key") : null;
        }

        alerts = new Alerts(this);

        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .build();

        googleApiClient = new GoogleApiClient.Builder(this)
                .enableAutoManage(this, (GoogleApiClient.OnConnectionFailedListener) this)
                .addApi(Auth.GOOGLE_SIGN_IN_API, gso)
                .build();

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Perfil modificado con éxito");
        builder.setMessage("Por favor, vuelve a ingresar a la aplicación");
        builder.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                goLogInScreen();
            }
        });
        alertDialog = builder.create();
    }

    @Override
    protected void onSaveInstanceState(Bundle savedInstanceState) {
        savedInstanceState.putSerializable("usuario", key);
        savedInstanceState.putString("key", key);

        super.onSaveInstanceState(savedInstanceState);
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);

        usuario = (Usuario) savedInstanceState.getSerializable("usuario");
        key = savedInstanceState.getString("key");
    }

    public void CambiarContra(View view) {
        ValidarTextos validarTextos = new ValidarTextos();
        boolean passvalido = validarTextos.validatePassword(etpass, passconf, this);

        if (passvalido) {
            final FirebaseAuth firebaseAuth = FirebaseAuth.getInstance();
            FirebaseUser user = firebaseAuth.getCurrentUser();
            final String newPassword = etpass.getText().toString().trim();

            if (user != null) {
                btnGuardar.setEnabled(false);
                btnGuardar.setBackgroundResource(R.color.darker_gray);
                user.updatePassword(newPassword).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            try {
                                btnGuardar.setEnabled(true);
                                btnGuardar.setBackgroundResource(R.color.colorPrimaryDark);
                                firebaseAuth.signOut();

                                Auth.GoogleSignInApi.signOut(googleApiClient).setResultCallback(new ResultCallback<Status>() {
                                    @Override
                                    public void onResult(@NonNull Status status) {
                                        if (status.isSuccess()) {
                                            alertDialog.show();
                                        } else {
                                            Toast.makeText(getApplicationContext(), "No se pudo cerrar sesión", Toast.LENGTH_SHORT).show();
                                            btnGuardar.setBackgroundResource(R.color.colorPrimaryDark);
                                        }
                                    }
                                });
                            } catch (Exception e) {
                                alerts.isConnected();
                                btnGuardar.setEnabled(true);
                                btnGuardar.setBackgroundResource(R.color.colorPrimaryDark);
                            }
                        } else {
                            AlertDialog.Builder builder = new AlertDialog.Builder(context);
                            builder.setTitle("Error");
                            builder.setMessage("No se pudo cambiar la contraseña");
                            builder.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    goLogInScreen();
                                }
                            });
                            alertDialog = builder.create();
                            alertDialog.show();
                            btnGuardar.setEnabled(true);
                            btnGuardar.setBackgroundResource(R.color.colorPrimaryDark);
                        }
                    }
                });
            }
        }
    }

    private void goLogInScreen() {
        Intent intent = new Intent(this, LoginActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            Intent intent = NavUtils.getParentActivityIntent(this);
            if (intent != null) {
                intent.setFlags(FLAG_ACTIVITY_CLEAR_TOP);
                NavUtils.navigateUpTo(this, intent);
            }

            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {
        alerts.isConnected();
    }
}
