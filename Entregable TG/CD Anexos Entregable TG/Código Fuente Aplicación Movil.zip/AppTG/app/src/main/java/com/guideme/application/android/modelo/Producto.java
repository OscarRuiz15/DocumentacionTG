package com.guideme.application.android.modelo;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.Serializable;

public class Producto implements Serializable {

    private int id;
    private String foto;
    private String nombre;
    private String descripcion;
    private String precio;
    private int lugar;

    public Producto() {
    }

    public Producto(int id, String foto, String nombre, String descripcion, String precio, int lugar) {
        this.id = id;
        this.foto = foto;
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.precio = precio;
        this.lugar = lugar;
    }

    public Producto(String nombre, String descripcion, String precio, String foto, int lugar) {
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.precio = precio;
        this.foto = foto;
        this.lugar = lugar;
    }

    public Producto(JSONObject jsonObject) throws JSONException {
        this.id = jsonObject.getInt("id");
        this.foto = jsonObject.getString("foto");
        this.nombre = jsonObject.getString("nombre");
        this.descripcion = jsonObject.getString("descripcion");
        this.precio = jsonObject.getString("precio");
        this.lugar = jsonObject.getInt("lugar");
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getPrecio() {
        return precio;
    }

    public void setPrecio(String precio) {
        this.precio = precio;
    }

    public String getFoto() {
        return foto;
    }

    public void setFoto(String foto) {
        this.foto = foto;
    }

    public int getLugar() {
        return lugar;
    }

    public void setLugar(int lugar) {
        this.lugar = lugar;
    }

    public JSONObject getJSONProducto() throws JSONException {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("id", id);
        jsonObject.put("foto", foto);
        jsonObject.put("nombre", nombre);
        jsonObject.put("descripcion", descripcion);
        jsonObject.put("precio", precio);
        jsonObject.put("lugar", lugar);
        return jsonObject;
    }
}
