package com.guideme.application.android.vista.dialog;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.GridLayout;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.guideme.application.android.R;
import com.guideme.application.android.modelo.Preferencia;
import com.guideme.application.android.modelo.Tag;
import com.guideme.application.android.modelo.Usuario;
import com.guideme.application.android.utils.Constants;
import com.guideme.application.android.vista.activities.ContainerActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class TagsDialog {

    private Dialog dialog;
    private GridLayout layoutTags;
    private Button btnGuardar;
    private Button btnDespues;
    private ArrayList<CheckBox> cbTags;
    private ArrayList<Tag> tags;
    private ArrayList<String> tagsPreferencias;

    private Context context;
    private String key;
    private Usuario usuario;

    public TagsDialog(Context context, String key, Usuario usuario) {
        this.context = context;
        this.key = key;
        this.usuario = usuario;

        crearDialogo();
    }

    public void crearDialogo() {
        dialog = new Dialog(context);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialogo_tags);
        dialog.setCancelable(false);
        dialog.setCanceledOnTouchOutside(false);

        layoutTags = dialog.findViewById(R.id.layoutTags);
        btnGuardar = dialog.findViewById(R.id.btnGuardar);
        btnDespues = dialog.findViewById(R.id.btnDespues);

        tags = new ArrayList<>();
        cbTags = new ArrayList<>();
        tagsPreferencias = new ArrayList<>();

        cargarTags();

        btnGuardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                capturarTagsPreferencia();
            }
        });

        btnDespues.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btnDespues.setEnabled(false);
                btnDespues.setBackgroundResource(R.color.darker_gray);
                dialog.dismiss();
                Intent intent = new Intent(context, ContainerActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
                Bundle bundle = new Bundle();
                bundle.putSerializable("usuario", usuario);
                bundle.putString("key", key);
                intent.putExtras(bundle);
                context.startActivity(intent);
            }
        });

        dialog.show();

    }

    public void cargarTags() {
        String url = Constants.URL + Constants.URL_TAGS_API;
        RequestQueue requestQueue = Volley.newRequestQueue(Objects.requireNonNull(context));
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, url, null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                for (int i = 0; i < response.length(); i++) {
                    try {
                        Tag tag = new Tag(response.getJSONObject(i));
                        tags.add(tag);
                    } catch (JSONException e) {
                        //e.printStackTrace();
                    }
                }
                mostrarTags();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }) {
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> params = new HashMap<>();
                params.put("Content-Type", "application/json; charset=UTF-8");
                params.put("Authorization", key);
                return params;
            }
        };
        jsonArrayRequest.setRetryPolicy(new DefaultRetryPolicy(
                DefaultRetryPolicy.DEFAULT_TIMEOUT_MS * 3,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        requestQueue.add(jsonArrayRequest);
    }

    public void mostrarTags() {
        for (int i = 0; i < tags.size(); i++) {
            CheckBox cb = new CheckBox(context);
            cb.setText(tags.get(i).getNombre());
            cb.setTag(tags.get(i).getId());

            layoutTags.addView(cb);
            cbTags.add(cb);
        }
    }

    public void capturarTagsPreferencia() {
        btnGuardar.setEnabled(false);
        btnGuardar.setBackgroundResource(R.color.darker_gray);
        for (int i = 0; i < cbTags.size(); i++) {
            if (cbTags.get(i).isChecked()) {
                tagsPreferencias.add("" + cbTags.get(i).getText());
            }
        }

        try {
            RequestQueue requestQueue = Volley.newRequestQueue(context);

            Preferencia preferencia = new Preferencia();
            preferencia.setUsuario(usuario.getId());
            preferencia.setTags(tagsPreferencias);

            JSONObject jsonBody = preferencia.getJSONPreferencia();
            final String mRequestBody = jsonBody.toString();

            StringRequest stringRequest = new StringRequest(Request.Method.POST, Constants.URL + Constants.URL_PREFERENCIAS_API, new Response.Listener<String>() {

                @Override
                public void onResponse(String response) {
                    dialog.dismiss();
                    Intent intent = new Intent(context, ContainerActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
                    Bundle bundle = new Bundle();
                    bundle.putSerializable("usuario", usuario);
                    bundle.putString("key", key);
                    intent.putExtras(bundle);
                    context.startActivity(intent);
                }
            }, new Response.ErrorListener() {

                @Override
                public void onErrorResponse(VolleyError error) {
                    btnGuardar.setEnabled(true);
                    btnGuardar.setBackgroundResource(R.color.colorPrimaryDark);
                }
            }) {
                @Override
                public Map<String, String> getHeaders() {
                    Map<String, String> params = new HashMap<>();
                    params.put("Content-Type", "application/json; charset=UTF-8");
                    params.put("Authorization", key);
                    return params;
                }

                @Override
                public String getBodyContentType() {
                    return "application/json; charset=utf-8";
                }

                @Override
                public byte[] getBody() {
                    return mRequestBody == null ? null : mRequestBody.getBytes(StandardCharsets.UTF_8);
                }

                @Override
                protected Response<String> parseNetworkResponse(NetworkResponse response) {
                    String responseString = "";
                    if (response != null) {
                        responseString = String.valueOf(response.statusCode);
                    }
                    return Response.success(responseString, HttpHeaderParser.parseCacheHeaders(response));
                }
            };

            requestQueue.add(stringRequest);

        } catch (JSONException e) {
            //e.printStackTrace();
        }

    }
}
