package com.guideme.application.android.vista.activities;

import android.app.Activity;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;

import com.guideme.application.android.R;

public class ActionBar extends AppCompatActivity {

    public ActionBar() {
    }

    //Toolbar Activities
    public void showToolbar(String title, boolean upbutton, Activity activity) {
        Toolbar toolbar = (Toolbar) activity.findViewById(R.id.toolbar);

        ((AppCompatActivity) activity).setSupportActionBar(toolbar);
        ((AppCompatActivity) activity).getSupportActionBar().setTitle(title);
        ((AppCompatActivity) activity).getSupportActionBar().setDisplayHomeAsUpEnabled(upbutton);
    }

    //Toolbar Fragments
    public void showToolbar(String title, boolean upbutton, Activity activity, View v) {
        Toolbar toolbar = (Toolbar) v.findViewById(R.id.toolbar);

        ((AppCompatActivity) activity).setSupportActionBar(toolbar);
        ((AppCompatActivity) activity).getSupportActionBar().setTitle(title);
        ((AppCompatActivity) activity).getSupportActionBar().setDisplayHomeAsUpEnabled(upbutton);
    }
}
