package com.guideme.application.android.modelo;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.Serializable;
import java.util.ArrayList;

public class Preferencia implements Serializable {
    private int id;
    //private Usuario usuario;
    //private ArrayList<Tag> tags;
    private ArrayList<String> tags;
    private int usuario;

    public Preferencia(){

    }

    /*public Preferencia(int id, Usuario usuario, ArrayList<Tag> tags) {
        this.id = id;
        this.usuario = usuario;
        this.tags = tags;
    }*/

    public Preferencia(int id, int usuario, ArrayList<String> tags) {
        this.id = id;
        this.usuario = usuario;
        this.tags = tags;
    }

    public Preferencia(JSONObject jsonObject) throws JSONException {
        this.id = jsonObject.getInt("id");
        this.usuario = jsonObject.getInt("usuario");
        //this.tags = tagsJSONArray(jsonObject.getJSONArray("tag"));
        this.tags = stringJSONArray(jsonObject.getJSONArray("tags"));
    }

    private ArrayList<Tag> tagsJSONArray(JSONArray jsonArray) {
        ArrayList<Tag> tags = new ArrayList<>();
        for (int i = 0; i < jsonArray.length(); i++) {
            try {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                tags.add(new Tag(jsonObject));
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        return tags;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    /*public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }*/

    /*public ArrayList<Tag> getTags() {
        return tags;
    }

    public void setTags(ArrayList<Tag> tags) {
        this.tags = tags;
    }*/

    public int getUsuario() {
        return usuario;
    }

    public void setUsuario(int usuario) {
        this.usuario = usuario;
    }

    public ArrayList<String> getTags() {
        return tags;
    }

    public void setTags(ArrayList<String> tags) {
        this.tags = tags;
    }

    private JSONArray tagListToJSONArray(ArrayList<Tag> tags) throws JSONException {
        JSONArray jsonArray = new JSONArray();
        for (Tag tag : tags) {
            JSONObject jsonObject = tag.getJSONProducto();
            jsonArray.put(jsonObject);
        }
        return jsonArray;
    }

    public JSONObject getJSONPreferencia() throws JSONException {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("id", id);
        jsonObject.put("usuario", usuario);
        jsonObject.put("tags", stringListToJSONArray(tags));

        return jsonObject;
    }

    private ArrayList<String> stringJSONArray(JSONArray jsonArray) {
        ArrayList<String> lista = new ArrayList<>();
        for (int i = 0; i < jsonArray.length(); i++) {
            try {
                String str = jsonArray.getString(i);
                lista.add(str);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        return lista;
    }

    private JSONArray stringListToJSONArray(ArrayList<String> lista) {
        JSONArray jsonArray = new JSONArray();
        for (String str : lista) {
            jsonArray.put(str);
        }
        return jsonArray;
    }
}
