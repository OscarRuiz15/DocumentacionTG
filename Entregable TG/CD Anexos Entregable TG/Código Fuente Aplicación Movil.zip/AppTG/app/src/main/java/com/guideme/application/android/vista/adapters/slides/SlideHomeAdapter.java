package com.guideme.application.android.vista.adapters.slides;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.view.PagerAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RatingBar;
import android.widget.TextView;

import com.guideme.application.android.R;
import com.guideme.application.android.modelo.Lugar;
import com.guideme.application.android.modelo.Usuario;
import com.guideme.application.android.utils.Alerts;
import com.guideme.application.android.utils.ControladorFechas;
import com.guideme.application.android.vista.activities.DetallesLugarActivity;
import com.guideme.application.android.vista.fragments.GlideApp;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;
import java.util.Objects;

public class SlideHomeAdapter extends PagerAdapter {
    private Context context;
    private ArrayList<Lugar> lugares;
    private Usuario usuario;
    private String key;
    private boolean esRecomendado;


    public SlideHomeAdapter(Context context, ArrayList<Lugar> lugares, Usuario usuario, String key, boolean esRecomendado) {
        this.context = context;
        this.lugares = lugares;
        this.usuario = usuario;
        this.key = key;
        this.esRecomendado = esRecomendado;
    }

    @Override
    public int getCount() {
        return lugares.size();
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        return view == object;
    }

    @NonNull
    @Override
    public Object instantiateItem(@NonNull ViewGroup container, final int position) {
        FirebaseStorage firebaseStorage = FirebaseStorage.getInstance();
        StorageReference storageReference = firebaseStorage
                .getReferenceFromUrl(lugares.get(position).getFoto().get(0));

        LayoutInflater layoutInflater = Objects.requireNonNull
                ((LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE));
        View view = layoutInflater.inflate(R.layout.slide_home, container, false);

        LinearLayout linearLayout = view.findViewById(R.id.linearlayout);
        ProgressBar progressBar = view.findViewById(R.id.progressBar);
        ImageView imagen = view.findViewById(R.id.imageCardDetail);
        TextView txtnombre = view.findViewById(R.id.placenameCardDetail);
        TextView txtlugar = view.findViewById(R.id.lugarDetail);
        TextView txtdescripcion = view.findViewById(R.id.detalleslugarcardDetail);
        TextView txtdireccion = view.findViewById(R.id.direccionDetail);
        RatingBar rbrating = view.findViewById(R.id.ratingCardPlaceDetailsDetail);

        System.out.println("========================================= " + storageReference);
        GlideApp.with(context)
                .load(storageReference)
                .into(imagen);
        txtnombre.setText(lugares.get(position).getNombre());
        txtlugar.setText(lugares.get(position).getMunicipio());
        txtdescripcion.setText(lugares.get(position).getDescripcion());
        txtdireccion.setText(lugares.get(position).getDireccion());
        rbrating.setRating(lugares.get(position).getRating());
        linearLayout.setVisibility(View.VISIBLE);
        progressBar.setVisibility(View.GONE);
        imagen.setVisibility(View.VISIBLE);

        imagen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ControladorFechas controladorFechas = new ControladorFechas();
                if (!controladorFechas.esMayordeEdad(usuario.getFecha()) &&
                        lugares.get(position).getCategoria() == 1){
                    Alerts alerts = new Alerts(context);
                    alerts.menorDeEdadAlert();
                }else {
                    Intent intent = new Intent(context, DetallesLugarActivity.class);
                    Bundle bundle = new Bundle();
                    bundle.putSerializable("lugar", lugares.get(position));
                    bundle.putSerializable("usuario", usuario);
                    bundle.putString("key", key);
                    bundle.putBoolean("recomendado", esRecomendado);
                    intent.putExtras(bundle);
                    context.startActivity(intent);
                }
            }
        });

        container.addView(view);

        return view;
    }

    @Override
    public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
        container.removeView((LinearLayout) object);
    }

}
