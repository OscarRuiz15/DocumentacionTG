package com.guideme.application.android.vista.adapters.recycler;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import com.guideme.application.android.utils.ControladorFechas;
import com.guideme.application.android.R;
import com.guideme.application.android.modelo.Evento;
import com.guideme.application.android.modelo.Usuario;
import com.guideme.application.android.vista.activities.DetallesEventoActivity;
import com.guideme.application.android.vista.fragments.GlideApp;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;

public class EventoAdapterRecycler extends RecyclerView.Adapter<EventoAdapterRecycler.EventoHolder> {


    private Context context;
    private ArrayList<Evento> eventos;
    private Usuario usuario;
    private String key;

    public EventoAdapterRecycler(Context context, ArrayList<Evento> eventos, Usuario usuario, String key) {
        this.context = context;
        this.eventos = eventos;
        this.usuario = usuario;
        this.key = key;
    }

    @NonNull
    @Override
    public EventoHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.cardview_evento_detalles, parent, false);
        return new EventoHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull EventoHolder holder, int position) {
        position = holder.getAdapterPosition();
        FirebaseStorage firebaseStorage = FirebaseStorage.getInstance();
        StorageReference storageReference = firebaseStorage.getReferenceFromUrl(eventos.get(position).getFoto());

        ControladorFechas controladorFechas = new ControladorFechas();

        GlideApp.with(context)
                .load(storageReference)
                .into(holder.imagen);

        holder.txtnombre.setText(eventos.get(position).getNombre());
        holder.txtdireccion.setText(eventos.get(position).getDireccion());

        String fechas[] = controladorFechas.obtenerFecha(eventos.get(position).getFechainicio());
        /////Fechas
        ///// 0 Inicial mes ENE, FEB,....
        ///// 1 Dia de la semana Lunes, Mates...
        ///// 2 Numero del dia del Mes
        holder.txtmes.setText(fechas[0]);
        holder.txtdia.setText(fechas[2]);
        holder.txtdiainicio.setText(fechas[1]);
        holder.txthorainicio.setText(eventos.get(position).getHorainicio());

        holder.txtdescripcion.setText(eventos.get(position).getDescripcion());

        holder.rbrating.setRating(eventos.get(position).getRating());

        final int finalPosition = position;
        holder.imagen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, DetallesEventoActivity.class);
                Bundle bundle = new Bundle();
                bundle.putSerializable("evento", eventos.get(finalPosition));
                bundle.putSerializable("usuario", usuario);
                bundle.putString("key", key);
                intent.putExtras(bundle);
                context.startActivity(intent);
            }
        });

    }

    @Override
    public int getItemCount() {
        return eventos.size();
    }

    public void setFilter(ArrayList<Evento> eventosFiltrados) {
        eventos = new ArrayList<>();
        eventos.addAll(eventosFiltrados);
        notifyDataSetChanged();
    }

    class EventoHolder extends RecyclerView.ViewHolder {
        ImageView imagen;
        TextView txtnombre;
        TextView txtlugar;
        TextView txtdireccion;
        TextView txtdescripcion;
        TextView txtmes;
        TextView txtdia;
        TextView txtdiainicio;
        TextView txthorainicio;
        RatingBar rbrating;

        EventoHolder(View itemView) {
            super(itemView);
            imagen = itemView.findViewById(R.id.imageCardEvento);
            txtnombre = itemView.findViewById(R.id.eventnameCardDetail);
            txtlugar = itemView.findViewById(R.id.lugarEventoDetail);
            txtdireccion = itemView.findViewById(R.id.direccionEventoDetail);
            txtdescripcion = itemView.findViewById(R.id.detallesEventoCard);
            txtmes = itemView.findViewById(R.id.mesEvento);
            txtdia = itemView.findViewById(R.id.diaEvento);
            txtdiainicio = itemView.findViewById(R.id.diaInicioEvento);
            txthorainicio = itemView.findViewById(R.id.horaInicioEvento);
            rbrating = itemView.findViewById(R.id.ratingCardEventDetails);
        }
    }
}
