package com.guideme.application.android.vista.activities;

import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.TextInputEditText;
import android.support.design.widget.TextInputLayout;
import android.support.v4.app.NavUtils;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.text.InputType;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.TimePicker;

import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.firebase.storage.StorageReference;
import com.guideme.application.android.utils.Alerts;
import com.guideme.application.android.utils.Constants;
import com.guideme.application.android.utils.CrearTextos;
import com.guideme.application.android.R;
import com.guideme.application.android.utils.ValidarTextos;
import com.guideme.application.android.modelo.Lugar;
import com.guideme.application.android.modelo.Usuario;

import org.json.JSONException;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

public class ModificarLugarActivity extends AppCompatActivity implements View.OnClickListener {

    private static final String CERO = "0";
    private static final String DOS_PUNTOS = ":";

    //Calendario para obtener fecha & hora
    public final Calendar c = Calendar.getInstance();

    //Variables para obtener la hora hora
    final int hora = c.get(Calendar.HOUR_OF_DAY);
    final int minuto = c.get(Calendar.MINUTE);


    private EditText nombrelugar;
    private EditText etdescripcion;
    private EditText etdireccion;

    //Telefonos
    private ArrayList<TextInputEditText> ettelefonos;
    private LinearLayout linearLayoutTelefono;

    //Redes Sociales
    private ArrayList<TextInputEditText> etredes;
    private LinearLayout linearLayoutRedes;

    //Email
    private ArrayList<TextInputEditText> etemail;
    private LinearLayout linearLayoutEmail;

    //Email
    private ArrayList<TextInputEditText> etweb;
    private LinearLayout linearLayoutWeb;

    //Dias
    private CheckBox cbLunes;
    private CheckBox cbMartes;
    private CheckBox cbMiercoles;
    private CheckBox cbJueves;
    private CheckBox cbViernes;
    private CheckBox cbSabado;
    private CheckBox cbDomingo;

    //Atencion abierto
    private TextView tvAbreLunes;
    private TextView tvAbreMartes;
    private TextView tvAbreMiercoles;
    private TextView tvAbreJueves;
    private TextView tvAbreViernes;
    private TextView tvAbreSabado;
    private TextView tvAbreDomingo;

    //Atencion cerrado
    private TextView tvCierraLunes;
    private TextView tvCierraMartes;
    private TextView tvCierraMiercoles;
    private TextView tvCierraJueves;
    private TextView tvCierraViernes;
    private TextView tvCierraSabado;
    private TextView tvCierraDomingo;

    private Button btnModificar;

    TextInputLayout.LayoutParams layoutParams;

    private Lugar lugar;
    private Usuario usuario;

    StorageReference storageReference;

    private AlertDialog alertDialog;

    private CrearTextos crearTextos;

    private String key;

    private AlertDialog errorAlertDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modificar_lugar);
        ActionBar actionBar = new ActionBar();
        crearTextos = new CrearTextos(this);

        nombrelugar = findViewById(R.id.editTextNombre);
        etdescripcion = findViewById(R.id.editTextDescripcion);
        etdireccion = findViewById(R.id.editTextDireccion);

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //////////////////////////Lista de edit text que se crean cuando se escriba en este///////////////////////////
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////

        //////////////////////////////////Telefonos///////////////////////////////////////////////////////////////////
        ettelefonos = new ArrayList<>();
        TextInputEditText telefono = findViewById(R.id.editTextTelefono);

        TextInputLayout textInputLayoutTel = findViewById(R.id.textInputTel);
        linearLayoutTelefono = findViewById(R.id.linearLayoutTelefono);
        ettelefonos.add(telefono);
        layoutParams = (TextInputLayout.LayoutParams) textInputLayoutTel.getLayoutParams();

        telefono.addTextChangedListener(crearTextos.onTextChangedListener(telefono, true,
                ettelefonos, layoutParams, linearLayoutTelefono, getResources().getString(R.string.telefono2), InputType.TYPE_CLASS_PHONE));
        /////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //////////////////////////////////REDES SOCIALES///////////////////////////////////////////////////////////////////
        etredes = new ArrayList<>();
        TextInputEditText redes = findViewById(R.id.editTextRedes);

        linearLayoutRedes = findViewById(R.id.linearLayoutRedes);
        etredes.add(redes);

        redes.addTextChangedListener(crearTextos.onTextChangedListener(redes, true,
                etredes, layoutParams, linearLayoutRedes, getResources().getString(R.string.redessociales), InputType.TYPE_TEXT_VARIATION_WEB_EDIT_TEXT));
        /////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //////////////////////////////////Email///////////////////////////////////////////////////////////////////
        etemail = new ArrayList<>();
        TextInputEditText email = findViewById(R.id.editTextEmail);

        linearLayoutEmail = findViewById(R.id.linearLayoutEmail);
        etemail.add(email);

        email.addTextChangedListener(crearTextos.onTextChangedListener(email, true,
                etemail, layoutParams, linearLayoutEmail, getResources().getString(R.string.hint_email), InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS));
        /////////////////////////////////////////////////////////////////////////////////////////////////////////////

        //////////////////////////////////Email///////////////////////////////////////////////////////////////////
        etweb = new ArrayList<>();
        TextInputEditText web = findViewById(R.id.editTextWeb);

        linearLayoutWeb = findViewById(R.id.linearLayoutWeb);
        etweb.add(web);

        web.addTextChangedListener(crearTextos.onTextChangedListener(web, true,
                etweb, layoutParams, linearLayoutWeb, getResources().getString(R.string.paginaweb), InputType.TYPE_TEXT_VARIATION_WEB_EDIT_TEXT));
        /////////////////////////////////////////////////////////////////////////////////////////////////////////////

        ///////////////////////Inicializar Servicio//////////////////////////
        cbLunes = findViewById(R.id.checkboxLUN);
        cbMartes = findViewById(R.id.checkboxMAR);
        cbMiercoles = findViewById(R.id.checkboxMIE);
        cbJueves = findViewById(R.id.checkboxJUE);
        cbViernes = findViewById(R.id.checkboxVIE);
        cbSabado = findViewById(R.id.checkboxSAB);
        cbDomingo = findViewById(R.id.checkboxDOM);

        tvAbreLunes = findViewById(R.id.editTextHoraAbrirLUN);
        tvAbreMartes = findViewById(R.id.editTextHoraAbrirMAR);
        tvAbreMiercoles = findViewById(R.id.editTextHoraAbrirMIE);
        tvAbreJueves = findViewById(R.id.editTextHoraAbrirJUE);
        tvAbreViernes = findViewById(R.id.editTextHoraAbrirVIE);
        tvAbreSabado = findViewById(R.id.editTextHoraAbrirSAB);
        tvAbreDomingo = findViewById(R.id.editTextHoraAbrirDOM);

        tvCierraLunes = findViewById(R.id.editTextHoraCerrarLUN);
        tvCierraMartes = findViewById(R.id.editTextHoraCerrarMAR);
        tvCierraMiercoles = findViewById(R.id.editTextHoraCerrarMIE);
        tvCierraJueves = findViewById(R.id.editTextHoraCerrarJUE);
        tvCierraViernes = findViewById(R.id.editTextHoraCerrarVIE);
        tvCierraSabado = findViewById(R.id.editTextHoraCerrarSAB);
        tvCierraDomingo = findViewById(R.id.editTextHoraCerrarDOM);

        btnModificar = findViewById(R.id.btnModificarLugar);

        tvAbreLunes.setOnClickListener(this);
        tvAbreMartes.setOnClickListener(this);
        tvAbreMiercoles.setOnClickListener(this);
        tvAbreJueves.setOnClickListener(this);
        tvAbreViernes.setOnClickListener(this);
        tvAbreSabado.setOnClickListener(this);
        tvAbreDomingo.setOnClickListener(this);

        tvCierraLunes.setOnClickListener(this);
        tvCierraMartes.setOnClickListener(this);
        tvCierraMiercoles.setOnClickListener(this);
        tvCierraJueves.setOnClickListener(this);
        tvCierraViernes.setOnClickListener(this);
        tvCierraSabado.setOnClickListener(this);
        tvCierraDomingo.setOnClickListener(this);

        Bundle bundle = getIntent().getExtras();

        if (savedInstanceState != null) {
            lugar = (Lugar) savedInstanceState.getSerializable("lugar");
            usuario = (Usuario) savedInstanceState.getSerializable("usuario");
            key = savedInstanceState.getString("key");
        } else {
            lugar = (Lugar) (bundle != null ? bundle.getSerializable("lugar") : null);
            usuario = (Usuario) (bundle != null ? bundle.getSerializable("usuario") : null);
            key = bundle != null ? bundle.getString("key") : null;
        }
        String title = getResources().getString(R.string.modificar) + " " + lugar.getNombre();
        actionBar.showToolbar(title, true, this);
        ponerElementos(lugar);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(lugar.getNombre() + " modificado");
        builder.setMessage("El lugar " + lugar.getNombre() + " ha sido modificado con éxito");
        builder.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                irDetallesLugar(lugar);
            }
        });
        alertDialog = builder.create();
        btnModificar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cambiarDatos();
            }
        });
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            Intent intent = NavUtils.getParentActivityIntent(this);
            if (intent != null) {
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                NavUtils.navigateUpTo(this, intent);
            }
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onSaveInstanceState(Bundle savedInstanceState) {
        savedInstanceState.putSerializable("lugar", lugar);
        savedInstanceState.putSerializable("usuario", usuario);
        savedInstanceState.putString("key", key);

        super.onSaveInstanceState(savedInstanceState);
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);

        lugar = (Lugar) savedInstanceState.getSerializable("lugar");
        usuario = (Usuario) savedInstanceState.getSerializable("usuario");
        key = savedInstanceState.getString("key");
    }

    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.editTextHoraAbrirLUN:
                obtenerHora(tvAbreLunes);
                break;
            case R.id.editTextHoraAbrirMAR:
                obtenerHora(tvAbreMartes);
                break;
            case R.id.editTextHoraAbrirMIE:
                obtenerHora(tvAbreMiercoles);
                break;
            case R.id.editTextHoraAbrirJUE:
                obtenerHora(tvAbreJueves);
                break;
            case R.id.editTextHoraAbrirVIE:
                obtenerHora(tvAbreViernes);
                break;
            case R.id.editTextHoraAbrirSAB:
                obtenerHora(tvAbreSabado);
                break;
            case R.id.editTextHoraAbrirDOM:
                obtenerHora(tvAbreDomingo);
                break;
            case R.id.editTextHoraCerrarLUN:
                obtenerHora(tvCierraLunes);
                break;
            case R.id.editTextHoraCerrarMAR:
                obtenerHora(tvCierraMartes);
                break;
            case R.id.editTextHoraCerrarMIE:
                obtenerHora(tvCierraMiercoles);
                break;
            case R.id.editTextHoraCerrarJUE:
                obtenerHora(tvCierraJueves);
                break;
            case R.id.editTextHoraCerrarVIE:
                obtenerHora(tvCierraViernes);
                break;
            case R.id.editTextHoraCerrarSAB:
                obtenerHora(tvCierraSabado);
                break;
            case R.id.editTextHoraCerrarDOM:
                obtenerHora(tvCierraDomingo);
                break;
            case R.id.btnModificarLugar:
                cambiarDatos();
                break;


        }
    }

    private void obtenerHora(final TextView textView) {
        TimePickerDialog recogerHora = new TimePickerDialog(this, new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                //Formateo el hora obtenido: antepone el 0 si son menores de 10
                String horaFormateada = (hourOfDay < 10) ? String.valueOf(CERO + hourOfDay) : String.valueOf(hourOfDay);
                //Formateo el minuto obtenido: antepone el 0 si son menores de 10
                String minutoFormateado = (minute < 10) ? String.valueOf(CERO + minute) : String.valueOf(minute);
                //Obtengo el valor a.m. o p.m., dependiendo de la selección del usuario
                String AM_PM;
                if (hourOfDay < 12) {
                    AM_PM = "a.m.";
                } else {
                    AM_PM = "p.m.";
                }
                //Muestro la hora con el formato deseado
                String estado = textView.getText().toString().trim();
                String hora = horaFormateada + DOS_PUNTOS + minutoFormateado + " " + AM_PM;
                textView.requestFocus();
                switch (estado) {
                    case "Abres..":
                        ponerHoraAbierto(hora);
                        break;
                    case "Cierras..":
                        ponerHoraCerrado(hora);
                        break;
                    default:
                        textView.setText(hora);
                        break;
                }
            }
            //Estos valores deben ir en ese orden
            //Al colocar en false se muestra en formato 12 horas y true en formato 24 horas
            //Pero el sistema devuelve la hora en formato 24 horas
        }, hora, minuto, false);

        recogerHora.show();
    }

    public void ponerHoraAbierto(String hora) {
        String estado = tvAbreLunes.getText().toString().trim();
        if (estado.equals("Abres..")) {
            tvAbreLunes.setText(hora);
        }
        estado = tvAbreMartes.getText().toString().trim();
        if (estado.equals("Abres..")) {
            tvAbreMartes.setText(hora);
        }
        estado = tvAbreMiercoles.getText().toString().trim();
        if (estado.equals("Abres..")) {
            tvAbreMiercoles.setText(hora);
        }
        estado = tvAbreJueves.getText().toString().trim();
        if (estado.equals("Abres..")) {
            tvAbreJueves.setText(hora);
        }
        estado = tvAbreViernes.getText().toString().trim();
        if (estado.equals("Abres..")) {
            tvAbreViernes.setText(hora);
        }
        estado = tvAbreSabado.getText().toString().trim();
        if (estado.equals("Abres..")) {
            tvAbreSabado.setText(hora);
        }
        estado = tvAbreDomingo.getText().toString().trim();
        if (estado.equals("Abres..")) {
            tvAbreDomingo.setText(hora);
        }
    }

    public void ponerHoraCerrado(String hora) {
        String estado = tvCierraLunes.getText().toString().trim();
        if (estado.equals("Cierras..")) {
            tvCierraLunes.setText(hora);
        }
        estado = tvCierraMartes.getText().toString().trim();
        if (estado.equals("Cierras..")) {
            tvCierraMartes.setText(hora);
        }
        estado = tvCierraMiercoles.getText().toString().trim();
        if (estado.equals("Cierras..")) {
            tvCierraMiercoles.setText(hora);
        }
        estado = tvCierraJueves.getText().toString().trim();
        if (estado.equals("Cierras..")) {
            tvCierraJueves.setText(hora);
        }
        estado = tvCierraViernes.getText().toString().trim();
        if (estado.equals("Cierras..")) {
            tvCierraViernes.setText(hora);
        }
        estado = tvCierraSabado.getText().toString().trim();
        if (estado.equals("Cierras..")) {
            tvCierraSabado.setText(hora);
        }
        estado = tvCierraDomingo.getText().toString().trim();
        if (estado.equals("Cierras..")) {
            tvCierraDomingo.setText(hora);
        }
    }

    public void ponerElementos(Lugar lugar) {
        nombrelugar.setText(lugar.getNombre());
        etdireccion.setText(lugar.getDireccion());
        etdescripcion.setText(lugar.getDescripcion());

        ettelefonos.get(0).setText(lugar.getTelefono().get(0));
        crearTextos.createTextInputEditText(null, ettelefonos, layoutParams, linearLayoutTelefono,
                getResources().getString(R.string.telefono2), InputType.TYPE_CLASS_PHONE, lugar.getTelefono());

        if (!lugar.getSitio_web().isEmpty()) {
            etweb.get(0).setText(lugar.getSitio_web().get(0));
            crearTextos.createTextInputEditText(null, etweb, layoutParams, linearLayoutWeb,
                    getResources().getString(R.string.paginaweb), InputType.TYPE_TEXT_VARIATION_WEB_EDIT_TEXT, lugar.getSitio_web());
        }

        if (!lugar.getRedes().isEmpty()) {
            etredes.get(0).setText(lugar.getRedes().get(0));
            crearTextos.createTextInputEditText(null, etredes, layoutParams, linearLayoutRedes,
                    getResources().getString(R.string.redessociales), InputType.TYPE_TEXT_VARIATION_WEB_EDIT_TEXT, lugar.getRedes());
        }

        if (!lugar.getEmail().isEmpty()) {
            etemail.get(0).setText(lugar.getEmail().get(0));
            crearTextos.createTextInputEditText(null, etemail, layoutParams, linearLayoutEmail,
                    getResources().getString(R.string.hint_email), InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS, lugar.getEmail());
        }

        ponerHorarios();

    }

    private void ponerHorarios() {
        ArrayList<String> dias = lugar.getDias_servicio();
        ArrayList<String> abre = lugar.getHorarioabierto();
        ArrayList<String> cierra = lugar.getHorariocerrado();

        if (!dias.get(0).equals("N")) {
            cbLunes.setChecked(true);
            tvAbreLunes.setText(abre.get(0));
            tvCierraLunes.setText(cierra.get(0));
        }
        if (!dias.get(1).equals("N")) {
            cbMartes.setChecked(true);
            tvAbreMartes.setText(abre.get(1));
            tvCierraMartes.setText(cierra.get(1));
        }
        if (!dias.get(2).equals("N")) {
            cbMiercoles.setChecked(true);
            tvAbreMiercoles.setText(abre.get(2));
            tvCierraMiercoles.setText(cierra.get(2));
        }
        if (!dias.get(3).equals("N")) {
            cbJueves.setChecked(true);
            tvAbreJueves.setText(abre.get(3));
            tvCierraJueves.setText(cierra.get(3));
        }
        if (!dias.get(4).equals("N")) {
            cbViernes.setChecked(true);
            tvAbreViernes.setText(abre.get(4));
            tvCierraViernes.setText(cierra.get(4));
        }
        if (!dias.get(5).equals("N")) {
            cbSabado.setChecked(true);
            tvAbreSabado.setText(abre.get(5));
            tvCierraSabado.setText(cierra.get(5));
        }
        if (!dias.get(6).equals("N")) {
            cbDomingo.setChecked(true);
            tvAbreDomingo.setText(abre.get(6));
            tvCierraDomingo.setText(cierra.get(6));
        }

    }

    public void cambiarDatos() {
        final Alerts alerts = new Alerts(this);

        if (alerts.isConnected()) {
            ValidarTextos validarTextos = new ValidarTextos();
            boolean nombrevalido = validarTextos.validateBlank(nombrelugar, this);
            boolean descripcionvalido = validarTextos.validateBlank(etdireccion, this);
            boolean direccionvalido = validarTextos.validateBlank(etdescripcion, this);

            //boolean paginawebvalido = validarTextos.validateWEB(paginaweb, this);
            // boolean horaabiertovalido = validarTextos.validateBlank(horainicio, this);
            // boolean horacerradovalido = validarTextos.validateBlank(horafin, this);

            if (nombrevalido && descripcionvalido && direccionvalido  /* && paginawebvalido && horaabiertovalido && horacerradovalido*/) {

                final String nombre = nombrelugar.getText().toString().trim();
                final String direccion = etdireccion.getText().toString().trim();
                final String descripcion = etdescripcion.getText().toString().trim();

                final ArrayList<String> telefonos = crearTextos.obtenerLista(ettelefonos);
                final ArrayList<String> redes = crearTextos.obtenerLista(etredes);
                final ArrayList<String> web = crearTextos.obtenerLista(etweb);
                final ArrayList<String> email = crearTextos.obtenerLista(etemail);

                ArrayList<String> diasServicio = new ArrayList<>();
                ArrayList<String> horaAbierto = new ArrayList<>();
                ArrayList<String> horaCerrado = new ArrayList<>();

                obtenerDiasDeAtencion(diasServicio, horaAbierto, horaCerrado);


                //lugar.setFoto(fotos);

                lugar.setNombre(nombre);
                lugar.setDireccion(direccion);
                lugar.setDescripcion(descripcion);
                //lugar.setHorarioabierto(horaabierto);
                //lugar.setHorariocerrado(horacerrado);
                lugar.setTelefono(telefonos);
                lugar.setSitio_web(web);
                lugar.setEmail(email);
                lugar.setRedes(redes);


                putJSONVolley(lugar);
            }
        }
    }

    private void obtenerDiasDeAtencion(ArrayList<String> dias, ArrayList<String> abre, ArrayList<String> cierra) {
        if (cbLunes.isChecked()) {
            dias.add(cbLunes.getText().toString().trim());
            abre.add(tvAbreLunes.getText().toString().trim());
            cierra.add(tvCierraLunes.getText().toString().trim());
        } else {
            dias.add("N");
            abre.add("N");
            cierra.add("N");
        }
        if (cbMartes.isChecked()) {
            dias.add(cbMartes.getText().toString().trim());
            abre.add(tvAbreMartes.getText().toString().trim());
            cierra.add(tvCierraMartes.getText().toString().trim());
        } else {
            dias.add("N");
            abre.add("N");
            cierra.add("N");
        }
        if (cbMiercoles.isChecked()) {
            dias.add(cbMiercoles.getText().toString().trim());
            abre.add(tvAbreMiercoles.getText().toString().trim());
            cierra.add(tvCierraMiercoles.getText().toString().trim());
        } else {
            dias.add("N");
            abre.add("N");
            cierra.add("N");
        }
        if (cbJueves.isChecked()) {
            dias.add(cbJueves.getText().toString().trim());
            abre.add(tvAbreJueves.getText().toString().trim());
            cierra.add(tvCierraJueves.getText().toString().trim());
        } else {
            dias.add("N");
            abre.add("N");
            cierra.add("N");
        }
        if (cbViernes.isChecked()) {
            dias.add(cbViernes.getText().toString().trim());
            abre.add(tvAbreViernes.getText().toString().trim());
            cierra.add(tvCierraViernes.getText().toString().trim());
        } else {
            dias.add("N");
            abre.add("N");
            cierra.add("N");
        }
        if (cbSabado.isChecked()) {
            dias.add(cbSabado.getText().toString().trim());
            abre.add(tvAbreSabado.getText().toString().trim());
            cierra.add(tvCierraSabado.getText().toString().trim());
        } else {
            dias.add("N");
            abre.add("N");
            cierra.add("N");
        }
        if (cbDomingo.isChecked()) {
            dias.add(cbDomingo.getText().toString().trim());
            abre.add(tvAbreDomingo.getText().toString().trim());
            cierra.add(tvCierraDomingo.getText().toString().trim());
        } else {
            dias.add("N");
            abre.add("N");
            cierra.add("N");
        }
        lugar.setDias_servicio(dias);
        lugar.setHorarioabierto(abre);
        lugar.setHorariocerrado(cierra);
    }

    public void putJSONVolley(Lugar lugar) {
        btnModificar.setEnabled(false);
        btnModificar.setBackgroundResource(R.color.darker_gray);
        try {
            final Alerts alerts = new Alerts(this);

            RequestQueue requestQueue = Volley.newRequestQueue(this);

            JSONObject jsonBody = lugar.getJSONLugar();

            final String mRequestBody = jsonBody.toString();
            String url = Constants.URL + Constants.URL_LUGARES_API + lugar.getId() + Constants.BAR;


            StringRequest stringRequest = new StringRequest(Request.Method.PUT, url,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            getLugarJSONVolley();
                        }
                    }, new Response.ErrorListener() {

                @Override
                public void onErrorResponse(VolleyError error) {
                    int statusCode = error.networkResponse.statusCode;
                    String mensaje = "No se pudo modificar el lugar";
                    errorAlertDialog = alerts.createErrorAlert(statusCode, mensaje).create();
                    errorAlertDialog.show();
                    btnModificar.setEnabled(true);
                    btnModificar.setBackgroundResource(R.color.colorPrimaryDark);
                }
            }) {
                @Override
                public Map<String, String> getHeaders() {
                    Map<String, String> params = new HashMap<>();
                    params.put("Content-Type", "application/json; charset=UTF-8");
                    params.put("Authorization", key);
                    return params;
                }

                @Override
                public String getBodyContentType() {
                    return "application/json; charset=utf-8";
                }

                @Override
                public byte[] getBody() {
                    return mRequestBody == null ? null : mRequestBody.getBytes(StandardCharsets.UTF_8);
                }

                @Override
                protected Response<String> parseNetworkResponse(NetworkResponse response) {
                    String responseString = "";
                    if (response != null) {
                        responseString = String.valueOf(response.statusCode);
                    }
                    return Response.success(responseString, HttpHeaderParser.parseCacheHeaders(response));
                }
            };

            requestQueue.add(stringRequest);

        } catch (JSONException e) {
            btnModificar.setEnabled(true);
            btnModificar.setBackgroundResource(R.color.colorPrimaryDark);
        }

    }

    public void irDetallesLugar(Lugar lugar) {
        Intent intent = new Intent(this, DetallesLugarActivity.class);
        Bundle bundle = new Bundle();
        bundle.putSerializable("lugar", lugar);
        bundle.putSerializable("usuario", usuario);
        bundle.putSerializable("key", key);
        intent.putExtras(bundle);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
    }

    public void getLugarJSONVolley() {
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        String url = Constants.URL + Constants.URL_LUGARES_API + lugar.getId() + Constants.BAR;

        final JsonObjectRequest jsObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {
                    lugar = new Lugar(response);
                    alertDialog.show();
                    btnModificar.setEnabled(true);
                    btnModificar.setBackgroundResource(R.color.colorPrimaryDark);
                    //irDetallesLugar(lugar);
                } catch (JSONException e) {
                    btnModificar.setEnabled(true);
                    btnModificar.setBackgroundResource(R.color.colorPrimaryDark);
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                //Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_LONG).show();
            }
        }) {
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> params = new HashMap<>();
                params.put("Content-Type", "application/json; charset=UTF-8");
                params.put("Authorization", key);
                return params;
            }
        };

        requestQueue.add(jsObjectRequest);
    }


}
