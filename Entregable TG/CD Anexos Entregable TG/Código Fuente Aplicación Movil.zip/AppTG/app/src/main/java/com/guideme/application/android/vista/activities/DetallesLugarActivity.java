package com.guideme.application.android.vista.activities;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.v4.app.NavUtils;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.guideme.application.android.R;
import com.guideme.application.android.modelo.Evento;
import com.guideme.application.android.modelo.Lugar;
import com.guideme.application.android.modelo.Preferencia;
import com.guideme.application.android.modelo.Producto;
import com.guideme.application.android.modelo.Recomendacion;
import com.guideme.application.android.modelo.Suscripcion;
import com.guideme.application.android.modelo.Usuario;
import com.guideme.application.android.modelo.Visita;
import com.guideme.application.android.utils.Alerts;
import com.guideme.application.android.utils.Constants;
import com.guideme.application.android.utils.Consultas;
import com.guideme.application.android.utils.ControladorFechas;
import com.guideme.application.android.utils.Operaciones;
import com.guideme.application.android.vista.adapters.recycler.ComentarioAdapterRecycler;
import com.guideme.application.android.vista.adapters.recycler.ProductoAdapterRecycler;
import com.guideme.application.android.vista.adapters.recycler.TagGridAdapter;
import com.guideme.application.android.vista.adapters.slides.SlideEventosAdapter;
import com.guideme.application.android.vista.adapters.slides.SlideImagenDetallesAdapter;
import com.guideme.application.android.vista.dialog.ComentarioDialog;
import com.pusher.pushnotifications.PushNotifications;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class DetallesLugarActivity extends AppCompatActivity {
    private final Operaciones operaciones = new Operaciones();

    Context context = this;
    static final String LUGAR = "lugar";

    private LinearLayout dotsLayout;
    public Lugar lugar;
    private Usuario usuario;
    private Suscripcion suscripcion;
    private Visita visita;
    private Preferencia preferencia;
    private boolean esRecomendado;
    private ArrayList<Evento> eventos;
    private ArrayList<Producto> productos;
    private boolean haOpinado;
    private Recomendacion recomendacion;
    private Alerts alerts;
    private RecyclerView recyclerView;
    private RatingBar ratingBar;
    private TextView visitas;
    private TextView suscripciones;
    private Button btnSeguir;
    private Button btnVisita;
    private Button btnComoLlegar;
    private AlertDialog errorAlertDialog;

    private RecyclerView recyclerViewProducto;

    private ComentarioAdapterRecycler comentarioAdapterRecycler;

    private ViewPager viewPagerEvento;
    private LinearLayout dotsLayoutEvento;
    private SlideEventosAdapter slideEventosAdapter;

    private TextView dotsEvento[];
    private LinearLayout layoutEvento;

    private LinearLayout layoutHorarios;

    //Relatives
    private RelativeLayout horarioLunes;
    private RelativeLayout horarioMartes;
    private RelativeLayout horarioMiercoles;
    private RelativeLayout horarioJueves;
    private RelativeLayout horarioViernes;
    private RelativeLayout horarioSabado;
    private RelativeLayout horarioDomingo;

    //Dias
    private CheckBox cbLunes;
    private CheckBox cbMartes;
    private CheckBox cbMiercoles;
    private CheckBox cbJueves;
    private CheckBox cbViernes;
    private CheckBox cbSabado;
    private CheckBox cbDomingo;

    //Atencion abierto
    private TextView tvAbreLunes;
    private TextView tvAbreMartes;
    private TextView tvAbreMiercoles;
    private TextView tvAbreJueves;
    private TextView tvAbreViernes;
    private TextView tvAbreSabado;
    private TextView tvAbreDomingo;

    //Atencion cerrado
    private TextView tvCierraLunes;
    private TextView tvCierraMartes;
    private TextView tvCierraMiercoles;
    private TextView tvCierraJueves;
    private TextView tvCierraViernes;
    private TextView tvCierraSabado;
    private TextView tvCierraDomingo;

    private ControladorFechas controladorFechas;

    private String key;

    private View coordinatorLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalles_lugar);
        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        lugar = new Lugar();
        haOpinado = false;

        if (savedInstanceState == null) {
            lugar = (Lugar) (bundle != null ? bundle.getSerializable("lugar") : null);
            usuario = (Usuario) (bundle != null ? bundle.getSerializable("usuario") : null);
            preferencia = (Preferencia) (bundle != null ? bundle.getSerializable("preferencia") : null);
            esRecomendado = bundle != null && bundle.getBoolean("recomendado");
            eventos = (ArrayList<Evento>)
                    (bundle != null ? bundle.getSerializable("eventos") : null);
            productos = (ArrayList<Producto>)
                    (bundle != null ? bundle.getSerializable("productos") : null);
            key = bundle != null ? bundle.getString("key") : null;
        } else {
            lugar = (Lugar) savedInstanceState.getSerializable("lugar");
            usuario = (Usuario) savedInstanceState.getSerializable("usuario");
            key = savedInstanceState.getString("key");
        }
        obtenerOpiniones();

        //usuario = new Usuario();
        controladorFechas = new ControladorFechas();

        //Slide
        ViewPager slideImagenes = findViewById(R.id.slideFotosDetalles);
        SlideImagenDetallesAdapter slideImagenDetallesAdapter = new SlideImagenDetallesAdapter(this, lugar.getFoto());
        dotsLayout = findViewById(R.id.dotsLayoutDetallesLugar);
        addDotsIndicator(0);
        slideImagenes.addOnPageChangeListener(viewListener);
        slideImagenes.setAdapter(slideImagenDetallesAdapter);

        //Inicializar Elementos y Adapters
        coordinatorLayout = findViewById(R.id.coordinatorDetallesLugar);
        TextView descripcion = findViewById(R.id.descripcionLugarDetalles);
        TextView direccion = findViewById(R.id.direccionDetallesLugar);
        TextView txtlugar = findViewById(R.id.lugarDetalles);
        TextView telefonos = findViewById(R.id.telefonoContacto);
        TextView web = findViewById(R.id.paginaContacto);
        TextView redes = findViewById(R.id.txtwebs);
        TextView tvEmail = findViewById(R.id.txtemail);
        visitas = findViewById(R.id.textViewCantidadVisitas);
        suscripciones = findViewById(R.id.textViewCantidadFavoritos);
        recyclerView = findViewById(R.id.recyclerComentario);
        ratingBar = findViewById(R.id.ratingComment);
        RatingBar ratingLugar = findViewById(R.id.ratingCardDetails);
        recyclerViewProducto = findViewById(R.id.recyclerProducto);
        RecyclerView recyclerViewTag = findViewById(R.id.recyclerTags);
        btnSeguir = findViewById(R.id.btnSeguir);
        btnVisita = findViewById(R.id.btnVisita);
        btnComoLlegar = findViewById(R.id.btnComoLlegar);

        //Poner Elementos
        ratingLugar.setRating(lugar.getRating());

        SimpleDateFormat format = new SimpleDateFormat("HH:mm:ss");

        ///////////////////////Inicializar Servicio//////////////////////////
        layoutHorarios = findViewById(R.id.layoutHorarios);

        horarioLunes = findViewById(R.id.horarioLunes);
        horarioMartes = findViewById(R.id.horarioMartes);
        horarioMiercoles = findViewById(R.id.horarioMiercoles);
        horarioJueves = findViewById(R.id.horarioJueves);
        horarioViernes = findViewById(R.id.horarioViernes);
        horarioSabado = findViewById(R.id.horarioSabado);
        horarioDomingo = findViewById(R.id.horarioDomingo);

        cbLunes = findViewById(R.id.checkboxLUN);
        cbMartes = findViewById(R.id.checkboxMAR);
        cbMiercoles = findViewById(R.id.checkboxMIE);
        cbJueves = findViewById(R.id.checkboxJUE);
        cbViernes = findViewById(R.id.checkboxVIE);
        cbSabado = findViewById(R.id.checkboxSAB);
        cbDomingo = findViewById(R.id.checkboxDOM);

        cbLunes.setButtonDrawable(R.color.white);
        cbMartes.setButtonDrawable(R.color.white);
        cbMiercoles.setButtonDrawable(R.color.white);
        cbJueves.setButtonDrawable(R.color.white);
        cbViernes.setButtonDrawable(R.color.white);
        cbSabado.setButtonDrawable(R.color.white);
        cbDomingo.setButtonDrawable(R.color.white);

        tvAbreLunes = findViewById(R.id.editTextHoraAbrirLUN);
        tvAbreMartes = findViewById(R.id.editTextHoraAbrirMAR);
        tvAbreMiercoles = findViewById(R.id.editTextHoraAbrirMIE);
        tvAbreJueves = findViewById(R.id.editTextHoraAbrirJUE);
        tvAbreViernes = findViewById(R.id.editTextHoraAbrirVIE);
        tvAbreSabado = findViewById(R.id.editTextHoraAbrirSAB);
        tvAbreDomingo = findViewById(R.id.editTextHoraAbrirDOM);

        tvCierraLunes = findViewById(R.id.editTextHoraCerrarLUN);
        tvCierraMartes = findViewById(R.id.editTextHoraCerrarMAR);
        tvCierraMiercoles = findViewById(R.id.editTextHoraCerrarMIE);
        tvCierraJueves = findViewById(R.id.editTextHoraCerrarJUE);
        tvCierraViernes = findViewById(R.id.editTextHoraCerrarVIE);
        tvCierraSabado = findViewById(R.id.editTextHoraCerrarSAB);
        tvCierraDomingo = findViewById(R.id.editTextHoraCerrarDOM);

        ponerHorarios();

        descripcion.setText(lugar.getDescripcion());
        direccion.setText(lugar.getDireccion());
        txtlugar.setText(lugar.getMunicipio());
        //ratingBar.setRating(1);

        StringBuilder auxTelefonos = new StringBuilder();
        for (int i = 0; i < lugar.getTelefono().size(); i++) {
            auxTelefonos.append(lugar.getTelefono().get(i)).append("\n");
        }
        telefonos.setText(auxTelefonos.toString());

        StringBuilder auxWebs = new StringBuilder();
        for (int i = 0; i < lugar.getSitio_web().size(); i++) {
            auxWebs.append(lugar.getSitio_web().get(i)).append("\n");
        }
        web.setText(auxWebs.toString());
        /*if(!lugar.getSitio_web().isEmpty()){
            AgregarURL agregarURL = new AgregarURL(lugar.getSitio_web());
            Spanned url = agregarURL.crearUrls();
            web.setText(url);
            web.setMovementMethod(LinkMovementMethod.getInstance());
        }*/

        /*if(!lugar.getRedes().isEmpty()){
            AgregarURL agregarURL = new AgregarURL(lugar.getRedes());
            Spanned url = agregarURL.crearUrls();
            redes.setText(url);
            redes.setMovementMethod(LinkMovementMethod.getInstance());
        }*/

        StringBuilder auxRedes = new StringBuilder();
        for (int i = 0; i < lugar.getRedes().size(); i++) {
            auxRedes.append(lugar.getRedes().get(i)).append("\n");
        }
        redes.setText(auxRedes.toString());

        StringBuilder email = new StringBuilder();
        for (int i = 0; i < lugar.getEmail().size(); i++) {
            email.append(lugar.getEmail().get(i)).append("\n");
        }
        tvEmail.setText(email.toString());

        //Recycler Tags
        TagGridAdapter tagGridAdapter = new TagGridAdapter(lugar.getTags());
        GridLayoutManager gridLayoutManager = new GridLayoutManager(this, 2);
        recyclerViewTag.setAdapter(tagGridAdapter);
        recyclerViewTag.setLayoutManager(gridLayoutManager);

        //Recycler Productos
        productos = new ArrayList<>();
        obtenerProductos();

        //Recycler Eventos
        eventos = new ArrayList<>();
        obtenerEventos();
        viewPagerEvento = findViewById(R.id.slideEventoHome);
        dotsLayoutEvento = findViewById(R.id.dotsEventoLayoutHome);
        layoutEvento = findViewById(R.id.layout_evento);

        //Recycler Comentarios
        //Collections.reverse(lugar.getComentarios());
        comentarioAdapterRecycler = new ComentarioAdapterRecycler(this, lugar.getComentarios());
        LinearLayoutManager linearLayoutManager1 = new LinearLayoutManager(this);
        recyclerView.setAdapter(comentarioAdapterRecycler);
        recyclerView.setLayoutManager(linearLayoutManager1);

        ActionBar actionBar = new ActionBar();
        actionBar.showToolbar(lugar.getNombre(), true, this);

        btnComoLlegar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(DetallesLugarActivity.this, MapsLugarActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                Bundle bundle = new Bundle();
                bundle.putSerializable("lugar", lugar);
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });
        alerts = new Alerts(this);
        obtenerCantidadVisitasSuscripciones();
        getVisitaJSONVolley();

        ratingBar.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                String url = Constants.URL + Constants.URL_LUGARES_API + lugar.getId() + Constants.BAR;
                agregarComentario(url);
            }
        });
        /*if(preferencia.getTags().isEmpty()){
            ponerTagsImplicitos();
        }*/

    }

    /*private void ponerTagsImplicitos() {
        try {
            preferencia.setTags(lugar.getTags());

            RequestQueue requestQueue = Volley.newRequestQueue(this);
            JSONObject jsonBody = preferencia.getJSONPreferencia();

            final String mRequestBody = jsonBody.toString();
            //System.out.println("---> " + mRequestBody);
            //System.out.println(jsonBody.toString());

            StringRequest stringRequest = new StringRequest(Request.Method.PUT, Constants.URL
                    + Constants.URL_PREFERENCIAS_API + preferencia.getId()
                    + Constants.BAR, new Response.Listener<String>() {

                @Override
                public void onResponse(String response) {

                }
            }, new Response.ErrorListener() {

                @Override
                public void onErrorResponse(VolleyError error) {
                }
            }) {
                @Override
                public Map<String, String> getHeaders() {
                    Map<String, String> params = new HashMap<>();
                    params.put("Content-Type", "application/json; charset=UTF-8");
                    params.put("Authorization", key);
                    return params;
                }

                @Override
                public String getBodyContentType() {
                    return "application/json; charset=utf-8";
                }

                @Override
                public byte[] getBody() {
                    return mRequestBody == null ? null : mRequestBody.getBytes(StandardCharsets.UTF_8);
                }

                @Override
                protected Response<String> parseNetworkResponse(NetworkResponse response) {
                    String responseString = "";
                    if (response != null) {
                        responseString = String.valueOf(response.statusCode);
                    }
                    return Response.success(responseString, HttpHeaderParser.parseCacheHeaders(response));
                }
            };

            requestQueue.add(stringRequest);

        } catch (JSONException e) {
            //e.printStackTrace();
        }
    }

    private void ponerTagsExplicitos() {
        try {
            Consultas consultas = new Consultas();
            preferencia.setTags(consultas.preferenciasDeUsuario(lugar.getTags(), preferencia.getTags()));

            RequestQueue requestQueue = Volley.newRequestQueue(this);
            JSONObject jsonBody = preferencia.getJSONPreferencia();

            final String mRequestBody = jsonBody.toString();
            //System.out.println("---> " + mRequestBody);
            //System.out.println(jsonBody.toString());

            StringRequest stringRequest = new StringRequest(Request.Method.PUT, Constants.URL
                    + Constants.URL_PREFERENCIAS_API + preferencia.getId()
                    + Constants.BAR, new Response.Listener<String>() {

                @Override
                public void onResponse(String response) {

                }
            }, new Response.ErrorListener() {

                @Override
                public void onErrorResponse(VolleyError error) {
                }
            }) {
                @Override
                public Map<String, String> getHeaders() {
                    Map<String, String> params = new HashMap<>();
                    params.put("Content-Type", "application/json; charset=UTF-8");
                    params.put("Authorization", key);
                    return params;
                }

                @Override
                public String getBodyContentType() {
                    return "application/json; charset=utf-8";
                }

                @Override
                public byte[] getBody() {
                    return mRequestBody == null ? null : mRequestBody.getBytes(StandardCharsets.UTF_8);
                }

                @Override
                protected Response<String> parseNetworkResponse(NetworkResponse response) {
                    String responseString = "";
                    if (response != null) {
                        responseString = String.valueOf(response.statusCode);
                    }
                    return Response.success(responseString, HttpHeaderParser.parseCacheHeaders(response));
                }
            };

            requestQueue.add(stringRequest);

        } catch (JSONException e) {
            //e.printStackTrace();
        }
    }*/

    private void ponerHorarios() {
        ArrayList<String> dias = lugar.getDias_servicio();
        ArrayList<String> abre = lugar.getHorarioabierto();
        ArrayList<String> cierra = lugar.getHorariocerrado();

        if (dias.get(0).equals("N")) {
            layoutHorarios.removeView(horarioLunes);
            /*cbLunes.setVisibility(View.GONE);
            tvAbreLunes.setVisibility(View.GONE);
            tvCierraLunes.setVisibility(View.GONE);*/
        } else {
            tvAbreLunes.setText(abre.get(0));
            tvCierraLunes.setText(cierra.get(0));
        }
        if (dias.get(1).equals("N")) {
            layoutHorarios.removeView(horarioMartes);
            /*cbMartes.setVisibility(View.GONE);
            tvAbreMartes.setVisibility(View.GONE);
            tvCierraMartes.setVisibility(View.GONE);*/
        } else {
            tvAbreMartes.setText(abre.get(1));
            tvCierraMartes.setText(cierra.get(1));
        }
        if (dias.get(2).equals("N")) {
            layoutHorarios.removeView(horarioMiercoles);
            /*cbMiercoles.setVisibility(View.GONE);
            tvAbreMiercoles.setVisibility(View.GONE);
            tvCierraMiercoles.setVisibility(View.GONE);*/
        } else {
            tvAbreMiercoles.setText(abre.get(2));
            tvCierraMiercoles.setText(cierra.get(2));
        }
        if (dias.get(3).equals("N")) {
            layoutHorarios.removeView(horarioJueves);
            /*cbJueves.setVisibility(View.GONE);
            tvAbreJueves.setVisibility(View.GONE);
            tvCierraJueves.setVisibility(View.GONE);*/
        } else {
            tvAbreJueves.setText(abre.get(3));
            tvCierraJueves.setText(cierra.get(3));
        }
        if (dias.get(4).equals("N")) {
            layoutHorarios.removeView(horarioViernes);
            /*cbViernes.setVisibility(View.GONE);
            tvAbreViernes.setVisibility(View.GONE);
            tvCierraViernes.setVisibility(View.GONE);*/
        } else {
            tvAbreViernes.setText(abre.get(4));
            tvCierraViernes.setText(cierra.get(4));
        }
        if (dias.get(5).equals("N")) {
            layoutHorarios.removeView(horarioSabado);
            /*cbSabado.setVisibility(View.GONE);
            tvAbreSabado.setVisibility(View.GONE);
            tvCierraSabado.setVisibility(View.GONE);*/
        } else {
            tvAbreSabado.setText(abre.get(5));
            tvCierraSabado.setText(cierra.get(5));
        }
        if (dias.get(6).equals("N")) {
            layoutHorarios.removeView(horarioDomingo);
            /*cbDomingo.setVisibility(View.GONE);
            tvAbreDomingo.setVisibility(View.GONE);
            tvCierraDomingo.setVisibility(View.GONE);*/
        } else {
            tvAbreDomingo.setText(abre.get(6));
            tvCierraDomingo.setText(cierra.get(6));
        }

    }

    @Override
    public void onSaveInstanceState(Bundle savedInstanceState) {
        // Save the user's current game state
        savedInstanceState.putSerializable(LUGAR, lugar);
        savedInstanceState.putSerializable("usuario", usuario);
        savedInstanceState.putSerializable("eventos", eventos);
        savedInstanceState.putSerializable("productos", productos);
        savedInstanceState.putString("key", key);

        // Always call the superclass so it can save the view hierarchy state
        super.onSaveInstanceState(savedInstanceState);
    }

    public void onRestoreInstanceState(Bundle savedInstanceState) {
        // Always call the superclass so it can restore the view hierarchy
        super.onRestoreInstanceState(savedInstanceState);

        // Restore state members from saved instance
        lugar = (Lugar) savedInstanceState.getSerializable("lugar");
        usuario = (Usuario) savedInstanceState.getSerializable("usuario");
        eventos = (ArrayList<Evento>) savedInstanceState.getSerializable("eventos");
        productos = (ArrayList<Producto>) savedInstanceState.getSerializable("productos");
        key = savedInstanceState.getString("key");
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        boolean escomerciante = lugar.getId_propietario() == usuario.getId();

        if (escomerciante) {
            getMenuInflater().inflate(R.menu.menu_comerciante, menu);
            btnVisita.setVisibility(View.GONE);
            btnSeguir.setVisibility(View.GONE);
        } else {
            getMenuInflater().inflate(R.menu.menu_compartir, menu);
            getSuscripcionJSONVolley();
        }

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Intent intent;
        Bundle bundle;

        switch (item.getItemId()) {
            case R.id.menu_crear_evento:
                intent = new Intent(this, CrearEventoActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                bundle = new Bundle();
                bundle.putSerializable("lugar", lugar);
                bundle.putSerializable("usuario", usuario);
                bundle.putString("key", key);
                intent.putExtras(bundle);
                startActivity(intent);
                return true;
            case R.id.menu_modificar:
                intent = new Intent(this, ModificarLugarActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                bundle = new Bundle();
                bundle.putSerializable("usuario", usuario);
                bundle.putSerializable("lugar", lugar);
                bundle.putString("key", key);
                intent.putExtras(bundle);
                startActivity(intent);
                break;
            case R.id.menu_nuevo_producto:
                intent = new Intent(this, CrearProductoActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                bundle = new Bundle();
                bundle.putSerializable("lugar", lugar);
                bundle.putSerializable("usuario", usuario);
                bundle.putSerializable("productos", productos);
                bundle.putString("key", key);
                intent.putExtras(bundle);
                startActivity(intent);
                break;
            case android.R.id.home:
                final Intent intentBack = NavUtils.getParentActivityIntent(this);
                if (intentBack != null) {
                    if (esRecomendado && !haOpinado){
                        AlertDialog alertDialog;
                        final Consultas consultas = new Consultas();
                        AlertDialog.Builder builder = new AlertDialog.Builder(context);
                        builder.setTitle("Ayudanos a mejorar");
                        builder.setMessage("¿Fue de tu agrado esta recomendación?");
                        builder.setPositiveButton("Si, me gustó", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                double valor = recomendacion.getValor();
                                consultas.crearOpinion(lugar, usuario, true, valor, context, key);
                                intentBack.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                NavUtils.navigateUpTo(DetallesLugarActivity.this, intentBack);
                            }
                        });
                        builder.setNegativeButton("No, no me gustó", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                double valor = recomendacion.getValor();
                                consultas.crearOpinion(lugar, usuario, false, valor, context, key);
                                intentBack.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                NavUtils.navigateUpTo(DetallesLugarActivity.this, intentBack);
                            }
                        });
                        alertDialog = builder.create();
                        alertDialog.show();
                    }
                    else {
                        intentBack.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        NavUtils.navigateUpTo(this, intentBack);
                    }
                }
                return true;
            case R.id.menu_compartir:
                intent = new Intent(Intent.ACTION_SEND);
                intent.setType("text/plain");
                intent.putExtra(Intent.EXTRA_TEXT, "Mira " + lugar.getNombre() + " ubicada en " + lugar.getDireccion() + ", https://www.google.com/maps/@" + lugar.getLatitud() + "," + lugar.getLongitud() + ",14z");
                //intent.setPackage("com.facebook.katana");
                startActivity(Intent.createChooser(intent, "Compartir con.."));
                return true;
            case R.id.menu_ver_suscriptores:
                intent = new Intent(this, VerSuscriptoresActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                bundle = new Bundle();
                bundle.putSerializable("lugar", lugar);
                bundle.putSerializable("usuario", usuario);
                bundle.putString("key", key);
                intent.putExtras(bundle);
                startActivity(intent);
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    public void addDotsIndicator(int position) {
        dotsLayout.removeAllViews();
        TextView[] dots = new TextView[lugar.getFoto().size()];
        for (int i = 0; i < dots.length; i++) {
            dots[i] = new TextView(this);
            dots[i].setText(Html.fromHtml("&#8226;"));
            dots[i].setTextSize(35);
            dots[i].setTextColor(getResources().getColor(R.color.transparentwhite));

            dotsLayout.addView(dots[i]);
        }
        if (dots.length > 0) {
            dots[position].setTextColor(getResources().getColor(R.color.white));
        }
    }

    ViewPager.OnPageChangeListener viewListener = new ViewPager.OnPageChangeListener() {
        @Override
        public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
        }

        @Override
        public void onPageSelected(int position) {
            addDotsIndicator(position);
        }

        @Override
        public void onPageScrollStateChanged(int state) {
        }
    };

    public void agregarFavorito(View view) {
        if (alerts.isConnected()) {
            if (suscripcion == null) {
                postSuscripcionVolley();
            } else {
                AlertDialog alertDialog;
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                builder.setTitle("Confirmar");
                builder.setMessage("¿Desea cancelar la suscripcion a " + lugar.getNombre() + "?");
                builder.setPositiveButton("Si", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        deleteSuscripcionVolley();
                    }
                });
                builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
                alertDialog = builder.create();
                alertDialog.show();
            }
        }
    }

    public void agregarVisita(View view) {
        if (alerts.isConnected()) postVisitaVolley();
    }

    public void agregarComentario(String url) {
        if (alerts.isConnected()) {
            new ComentarioDialog(context, lugar, usuario, ratingBar.getRating(), key, url, comentarioAdapterRecycler, recyclerView);

            /*comentarioAdapterRecycler = new ComentarioAdapterRecycler(context, lugar.getComentarios());
            LinearLayoutManager linearLayoutManager1 = new LinearLayoutManager(context);
            recyclerView.setAdapter(comentarioAdapterRecycler);
            recyclerView.setLayoutManager(linearLayoutManager1);*/
        }
    }

    private void postVisitaVolley() {
        try {

            String fecha = controladorFechas.getDate();
            String hora = controladorFechas.getHour();

            RequestQueue requestQueue = Volley.newRequestQueue(this);

            JSONObject jsonBody = new JSONObject();

            jsonBody.put("usuario", usuario.getId());
            jsonBody.put("lugar", lugar.getId());
            jsonBody.put("fecha_visita", fecha);
            jsonBody.put("hora_visita", hora);

            final String mRequestBody = jsonBody.toString();

            StringRequest stringRequest = new StringRequest(Request.Method.POST, Constants.URL + Constants.URL_VISITAS_API, new Response.Listener<String>() {

                @Override
                public void onResponse(String response) {
                    btnVisita.setClickable(false);
                    btnVisita.setBackgroundResource(R.color.darker_gray);
                    String mensaje = "Se ha registrado tu visita";
                    //ponerTagsExplicitos();
                    Snackbar.make(coordinatorLayout, mensaje, Snackbar.LENGTH_SHORT).show();
                }
            }, new Response.ErrorListener() {

                @Override
                public void onErrorResponse(VolleyError error) {
                    int statusCode = error.networkResponse.statusCode;
                    String mensaje = "No se pudo registrar tú visita";
                    errorAlertDialog = alerts.createErrorAlert(statusCode, mensaje).create();
                    errorAlertDialog.show();
                }
            }) {
                @Override
                public Map<String, String> getHeaders() {
                    Map<String, String> params = new HashMap<>();
                    params.put("Content-Type", "application/json; charset=UTF-8");
                    params.put("Authorization", key);
                    return params;
                }

                @Override
                public String getBodyContentType() {
                    return "application/json; charset=utf-8";
                }

                @Override
                public byte[] getBody() {
                    return mRequestBody == null ? null : mRequestBody.getBytes(StandardCharsets.UTF_8);
                }

                @Override
                protected Response<String> parseNetworkResponse(NetworkResponse response) {
                    String responseString = "";
                    if (response != null) {
                        responseString = String.valueOf(response.statusCode);
                    }
                    return Response.success(responseString, HttpHeaderParser.parseCacheHeaders(response));
                }
            };

            requestQueue.add(stringRequest);

        } catch (JSONException e) {
            //e.printStackTrace();
        }
    }

    private void postSuscripcionVolley() {
        try {

            String fecha = controladorFechas.getDate();
            String hora = controladorFechas.getHour();
            lugar.setRating(operaciones.calcularCalificacion(lugar.getComentarios()));
            //lugar.setRating(0);

            suscripcion = new Suscripcion(usuario, lugar.getId(), fecha, hora, true);

            RequestQueue requestQueue = Volley.newRequestQueue(this);
            JSONObject jsonBody = suscripcion.getJSONSuscripcion();

            final String mRequestBody = jsonBody.toString();
            //System.out.println("---> " + mRequestBody);
            //System.out.println(jsonBody.toString());

            StringRequest stringRequest = new StringRequest(Request.Method.POST, Constants.URL + Constants.URL_SUSCRIPCIONES_API, new Response.Listener<String>() {

                @Override
                public void onResponse(String response) {
                    btnSeguir.setBackgroundResource(R.color.darker_gray);
                    btnSeguir.setText(getResources().getString(R.string.siguiendo));
                    PushNotifications.subscribe(lugar.getId() + "");
                    getSuscripcionJSONVolley();
                    //ponerTagsExplicitos();
                    String mensaje = "Sigues a " + lugar.getNombre();
                    Snackbar.make(coordinatorLayout, mensaje, Snackbar.LENGTH_SHORT).show();
                }
            }, new Response.ErrorListener() {

                @Override
                public void onErrorResponse(VolleyError error) {
                    int statusCode = error.networkResponse.statusCode;
                    String mensaje = "No se pudo registrar tu suscripcion";
                    errorAlertDialog = alerts.createErrorAlert(statusCode, mensaje).create();
                    errorAlertDialog.show();
                }
            }) {
                @Override
                public Map<String, String> getHeaders() {
                    Map<String, String> params = new HashMap<>();
                    params.put("Content-Type", "application/json; charset=UTF-8");
                    params.put("Authorization", key);
                    return params;
                }

                @Override
                public String getBodyContentType() {
                    return "application/json; charset=utf-8";
                }

                @Override
                public byte[] getBody() {
                    return mRequestBody == null ? null : mRequestBody.getBytes(StandardCharsets.UTF_8);
                }

                @Override
                protected Response<String> parseNetworkResponse(NetworkResponse response) {
                    String responseString = "";
                    if (response != null) {
                        responseString = String.valueOf(response.statusCode);
                    }
                    return Response.success(responseString, HttpHeaderParser.parseCacheHeaders(response));
                }
            };

            requestQueue.add(stringRequest);

        } catch (JSONException e) {
            //e.printStackTrace();
        }
    }


    public void verFotos(View view) {
        Intent intent = new Intent(this, VerFotosActivity.class);
        Bundle bundle = new Bundle();
        bundle.putSerializable("usuario", usuario);
        bundle.putSerializable("lugar", lugar);
        bundle.putString("key", key);
        intent.putExtras(bundle);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
    }

    public void verProductos(View view) {
        Intent intent = new Intent(this, VerProductosActivity.class);
        Bundle bundle = new Bundle();
        bundle.putSerializable("usuario", usuario);
        bundle.putSerializable("lugar", lugar);
        bundle.putString("key", key);
        bundle.putSerializable("productos", productos);
        intent.putExtras(bundle);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
    }

    public void verEventos(View view) {
        Intent intent = new Intent(this, VerEventosActivity.class);
        Bundle bundle = new Bundle();
        bundle.putSerializable("lugar", lugar);
        bundle.putSerializable("eventos", eventos);
        bundle.putSerializable("usuario", usuario);
        intent.putExtras(bundle);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
    }

    private void obtenerEventos() {
        final Operaciones operaciones = new Operaciones();
        String url = Constants.URL + Constants.URL_EVENTOS_API + Constants.CONSULTA_LUGAR + lugar.getId();
        //System.out.println(url);

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        final JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, url, null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                for (int i = 0; i < response.length(); i++) {
                    try {
                        Evento evento = new Evento(response.getJSONObject(i));

                        if (!evento.isFinalizado()) {
                            evento.setRating(operaciones.calcularCalificacion(evento.getComentarios()));
                            eventos.add(evento);
                        }

                    } catch (JSONException e) {
                        //e.printStackTrace();
                    }
                }

                if (eventos.size() > 0) {
                    slideEventosAdapter = new SlideEventosAdapter(context, eventos, usuario, lugar, 2, key);
                    viewPagerEvento.setAdapter(slideEventosAdapter);
                    addDotsIndicator(0, dotsLayoutEvento, dotsEvento, eventos.size());
                    //System.out.println(response.toString());
                } else {
                    layoutEvento.removeAllViews();
                }


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                //System.out.println(error.toString());
            }
        }) {
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> params = new HashMap<>();
                params.put("Content-Type", "application/json; charset=UTF-8");
                params.put("Authorization", key);
                return params;
            }
        };
        jsonArrayRequest.setRetryPolicy(new DefaultRetryPolicy(
                DefaultRetryPolicy.DEFAULT_TIMEOUT_MS * 3,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        requestQueue.add(jsonArrayRequest);

    }

    private void obtenerOpiniones() {
        String url = Constants.URL + Constants.URL_OPINIONES_API + Constants.CONSULTA_LUGAR +
                lugar.getId() + Constants.AND_ID + usuario.getUid();

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        final JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, url, null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                haOpinado = response.length()!=0;
                if(!haOpinado) obtenerRecomendacion();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                //System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> rip");
            }
        }) {
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> params = new HashMap<>();
                params.put("Content-Type", "application/json; charset=UTF-8");
                params.put("Authorization", key);
                return params;
            }
        };
        jsonArrayRequest.setRetryPolicy(new DefaultRetryPolicy(
                DefaultRetryPolicy.DEFAULT_TIMEOUT_MS * 3,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        requestQueue.add(jsonArrayRequest);

    }

    private void obtenerRecomendacion() {
        String url = Constants.URL + Constants.URL_LUGARES_API + Constants.URL_LUGARES_RECOMENDACIONES_API +
                Constants.CONSULTA_LUGAR + lugar.getId() + Constants.AND_USUARIO + usuario.getUid();
        Log.d("url", url);
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        final JsonArrayRequest jsonObjectRequest = new JsonArrayRequest(Request.Method.GET, url, null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                try {
                    recomendacion = new Recomendacion(response.getJSONObject(0));
                    Log.e("response",response.toString());
                } catch (JSONException e) {
                    recomendacion = null;
                    Log.e("error", e.getMessage());
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                recomendacion = null;
                Log.e("error", error.getMessage());
            }
        }){
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> params = new HashMap<>();
                params.put("Content-Type", "application/json; charset=UTF-8");
                params.put("Authorization", key);
                return params;
            }
        };
        jsonObjectRequest.setRetryPolicy(new DefaultRetryPolicy(
                DefaultRetryPolicy.DEFAULT_TIMEOUT_MS * 3,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        requestQueue.add(jsonObjectRequest);
        ;
    }


    private void obtenerProductos() {
        String url = Constants.URL + Constants.URL_PRODUCTOS_API + Constants.CONSULTA_LUGAR + lugar.getId();
        //System.out.println(url);

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        final JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, url, null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                for (int i = 0; i < response.length(); i++) {
                    try {
                        Producto producto = new Producto(response.getJSONObject(i));
                        productos.add(producto);


                    } catch (JSONException e) {
                        //e.printStackTrace();
                    }
                }

                if (productos.size() > 0) {
                    ProductoAdapterRecycler productoAdapterRecycler = new ProductoAdapterRecycler(context, lugar, usuario, key, productos);
                    LinearLayoutManager linearLayoutManager = new LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false);
                    recyclerViewProducto.setAdapter(productoAdapterRecycler);
                    recyclerViewProducto.setLayoutManager(linearLayoutManager);
                    //System.out.println(response.toString());
                } else {
                    recyclerViewProducto.removeAllViews();
                }


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                //System.out.println(error.toString());
            }
        }) {
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> params = new HashMap<>();
                params.put("Content-Type", "application/json; charset=UTF-8");
                params.put("Authorization", key);
                return params;
            }
        };
        jsonArrayRequest.setRetryPolicy(new DefaultRetryPolicy(
                DefaultRetryPolicy.DEFAULT_TIMEOUT_MS * 3,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        requestQueue.add(jsonArrayRequest);

    }

    private void obtenerCantidadVisitasSuscripciones() {
        String url =
                Constants.URL + Constants.URL_LUGARES_API +
                        Constants.CONSULTA_CANTIDAD + Constants.URL_CONTADOR_VISITAS_SUSCRIPCION_API +
                        Constants.CONSULTA_LUGAR + lugar.getId();
        //System.out.println(url);

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        final JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {
                    int contVisitas = response.getInt("visitas");
                    int contSuscripcion = response.getInt("suscripciones");
                    visitas.setText(String.valueOf(contVisitas));
                    suscripciones.setText(String.valueOf(contSuscripcion));
                } catch (JSONException e) {
                    //e.printStackTrace();
                }


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                //System.out.println(error.toString());
            }
        }) {
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> params = new HashMap<>();
                params.put("Content-Type", "application/json; charset=UTF-8");
                params.put("Authorization", key);
                return params;
            }
        };
        jsonObjectRequest.setRetryPolicy(new DefaultRetryPolicy(
                DefaultRetryPolicy.DEFAULT_TIMEOUT_MS * 3,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        requestQueue.add(jsonObjectRequest);

    }

    public void addDotsIndicator(int position, LinearLayout dotsLayout, TextView dots[], int size) {
        dotsLayout.removeAllViews();
        dots = new TextView[size];
        for (int i = 0; i < dots.length; i++) {
            dots[i] = new TextView(this);
            dots[i].setText(Html.fromHtml("&#8226;"));
            dots[i].setTextSize(35);
            dots[i].setTextColor(getResources().getColor(R.color.transparentwhite));

            dotsLayout.addView(dots[i]);
        }
        if (dots.length > 0) {
            dots[position].setTextColor(getResources().getColor(R.color.white));
        }
    }

    public Lugar getLugar() {
        return lugar;
    }

    public void getSuscripcionJSONVolley() {
        String nombre[] = lugar.getNombre().split(" ");
        StringBuilder auxNombre = new StringBuilder();

        for (String aNombre : nombre) {
            auxNombre.append(aNombre).append("%20");
        }

        auxNombre = new StringBuilder(auxNombre.substring(0, auxNombre.length() - 3));

        String url = Constants.URL + Constants.URL_SUSCRIPCIONES_API + Constants.CONSULTA_NOMBRE + auxNombre + Constants.AND_ID + usuario.getUid();
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        final JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, url, null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                try {
                    JSONObject jsonObject = response.getJSONObject(0);
                    suscripcion = new Suscripcion(jsonObject);
                    btnSeguir.setBackgroundResource(R.color.darker_gray);
                    btnSeguir.setText(R.string.siguiendo);
                } catch (JSONException e) {
                    //e.printStackTrace();
                    suscripcion = null;
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }) {
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> params = new HashMap<>();
                params.put("Content-Type", "application/json; charset=UTF-8");
                params.put("Authorization", key);
                return params;
            }
        };
        jsonArrayRequest.setRetryPolicy(new DefaultRetryPolicy(
                DefaultRetryPolicy.DEFAULT_TIMEOUT_MS * 3,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        requestQueue.add(jsonArrayRequest);
    }

    public void getVisitaJSONVolley() {

        String url = Constants.URL + Constants.URL_VISITAS_API + Constants.CONSULTA_USUARIOS +
                usuario.getUid() + Constants.AND_LUGAR + lugar.getId();
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        final JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, url, null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                try {
                    JSONObject jsonObject = response.getJSONObject(0);
                    visita = new Visita(jsonObject);


                    if (visita.getFecha_visita().equals(controladorFechas.getDate())) {
                        btnVisita.setClickable(false);
                        btnVisita.setBackgroundResource(R.color.darker_gray);
                    }
                } catch (JSONException e) {
                    //e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }) {
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> params = new HashMap<>();
                params.put("Content-Type", "application/json; charset=UTF-8");
                params.put("Authorization", key);
                return params;
            }
        };
        jsonArrayRequest.setRetryPolicy(new DefaultRetryPolicy(
                DefaultRetryPolicy.DEFAULT_TIMEOUT_MS * 3,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        requestQueue.add(jsonArrayRequest);
    }

    public void deleteSuscripcionVolley() {
        String url = Constants.URL + Constants.URL_SUSCRIPCIONES_API + suscripcion.getId() + Constants.BAR;
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        StringRequest stringRequest = new StringRequest(Request.Method.DELETE, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                btnSeguir.setBackgroundResource(R.color.colorPrimaryDark);
                btnSeguir.setText(R.string.seguir);
                PushNotifications.unsubscribe(lugar.getId() + "");
                suscripcion = null;
                String mensaje = "Ya no sigues a " + lugar.getNombre();
                Snackbar.make(coordinatorLayout, mensaje, Snackbar.LENGTH_SHORT).show();
            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                int statusCode = error.networkResponse.statusCode;
                String mensaje = "No se pudo procesar tu solicitud";
                errorAlertDialog = alerts.createErrorAlert(statusCode, mensaje).create();
                errorAlertDialog.show();
            }
        }) {
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> params = new HashMap<>();
                params.put("Content-Type", "application/json; charset=UTF-8");
                params.put("Authorization", key);
                return params;
            }

            @Override
            protected Response<String> parseNetworkResponse(NetworkResponse response) {
                String responseString = "";
                if (response != null) {
                    responseString = String.valueOf(response.statusCode);
                }
                return Response.success(responseString, HttpHeaderParser.parseCacheHeaders(response));
            }
        };

        requestQueue.add(stringRequest);

    }

    @Override
    public void onBackPressed() {
        if (esRecomendado && !haOpinado){
            AlertDialog alertDialog;
            final Consultas consultas = new Consultas();
            AlertDialog.Builder builder = new AlertDialog.Builder(context);
            builder.setTitle("Ayudanos a mejorar");
            builder.setMessage("¿Fue de tu agrado esta recomendación?");
            builder.setPositiveButton("Si, me gustó", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    double valor = recomendacion.getValor();
                    consultas.crearOpinion(lugar, usuario, true, valor, context, key);
                    DetallesLugarActivity.super.onBackPressed();
                }
            });
            builder.setNegativeButton("No, no me gustó", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    double valor = recomendacion.getValor();
                    consultas.crearOpinion(lugar, usuario, false, valor, context, key);
                    DetallesLugarActivity.super.onBackPressed();
                }
            });
            alertDialog = builder.create();
            alertDialog.show();
        } else {
            super.onBackPressed();
        }
    }
}

