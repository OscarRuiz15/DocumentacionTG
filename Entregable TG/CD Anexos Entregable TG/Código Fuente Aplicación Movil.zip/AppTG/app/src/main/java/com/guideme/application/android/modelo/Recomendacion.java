package com.guideme.application.android.modelo;

import org.json.JSONException;
import org.json.JSONObject;

public class Recomendacion {
    private int id;
    private double valor;
    private int lugar;
    private int usuario;

    public Recomendacion(int id, double valor, int lugar, int usuario) {
        this.id = id;
        this.valor = valor;
        this.lugar = lugar;
        this.usuario = usuario;
    }

    public Recomendacion(JSONObject jsonObject) throws JSONException {
        //this.id = jsonObject.getInt("id");
        this.valor = jsonObject.getDouble("valor");
        this.usuario = jsonObject.getInt("usuario");
        this.lugar = jsonObject.getInt("lugar");
    }

    public JSONObject getJSONRecomendacion() throws JSONException {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("id", id);
        jsonObject.put("valor", valor);
        jsonObject.put("usuario", usuario);
        jsonObject.put("lugar", lugar);
        return jsonObject;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public int getLugar() {
        return lugar;
    }

    public void setLugar(int lugar) {
        this.lugar = lugar;
    }

    public int getUsuario() {
        return usuario;
    }

    public void setUsuario(int usuario) {
        this.usuario = usuario;
    }
}
