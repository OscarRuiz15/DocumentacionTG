package com.guideme.application.android.vista.adapters.recycler;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.Snackbar;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.guideme.application.android.utils.Alerts;
import com.guideme.application.android.utils.Constants;
import com.guideme.application.android.R;
import com.guideme.application.android.modelo.Solicitud;
import com.guideme.application.android.vista.activities.NuevaSolicitudActivity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class SolicitudesAdapterRecycler extends RecyclerView.Adapter<SolicitudesAdapterRecycler.SolicitudHolder> {

    private Context context;
    private ArrayList<Solicitud> solicitudes;
    private String key;
    private View view;

    public SolicitudesAdapterRecycler(Context context, ArrayList<Solicitud> solicitudes, String key, View view) {
        this.context = context;
        this.solicitudes = solicitudes;
        this.key = key;
        this.view = view;
    }

    @NonNull
    @Override
    public SolicitudHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.cardview_solicitudes_creadas, parent, false);
        return new SolicitudHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull SolicitudHolder holder, final int position) {
        final SolicitudesAdapterRecycler adapter = this;
        final Alerts alerts = new Alerts(context);
        holder.tvTitulo.setText(solicitudes.get(position).getNombre_lugar());
        holder.tvDescripcion.setText(solicitudes.get(position).getInformacion());
        holder.imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (alerts.isConnected()) alerts.confirmAlert(solicitudes.get(position), adapter);
            }
        });

        holder.tvTitulo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, NuevaSolicitudActivity.class);
                Bundle bundle = new Bundle();
                bundle.putSerializable("solicitud", solicitudes.get(position));
                bundle.putInt("id", 1);
                intent.putExtras(bundle);
                context.startActivity(intent);
            }
        });
    }

    public void eliminarSolicitud(final Solicitud solicitud) {
        final SolicitudesAdapterRecycler adapter = this;
        String url = Constants.URL + Constants.URL_SOLICITUDES_API + solicitud.getId() + Constants.BAR;
        RequestQueue requestQueue = Volley.newRequestQueue(Objects.requireNonNull(context));
        StringRequest stringRequest = new StringRequest(Request.Method.DELETE, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                solicitudes.remove(solicitud);
                notifyDataSetChanged();
                Snackbar.make(view, "Se ha eliminado la solicitud", Snackbar.LENGTH_SHORT).show();
            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }) {
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> params = new HashMap<>();
                params.put("Content-Type", "application/json; charset=UTF-8");
                params.put("Authorization", key);
                return params;
            }


            @Override
            protected Response<String> parseNetworkResponse(NetworkResponse response) {
                String responseString = "";
                if (response != null) {
                    responseString = String.valueOf(response.statusCode);
                }
                assert response != null;
                return Response.success(responseString, HttpHeaderParser.parseCacheHeaders(response));
            }
        };

        requestQueue.add(stringRequest);


    }


    @Override
    public int getItemCount() {
        return solicitudes.size();
    }

    class SolicitudHolder extends RecyclerView.ViewHolder {

        ImageView imageView;
        TextView tvTitulo;
        TextView tvDescripcion;

        public SolicitudHolder(View itemView) {
            super(itemView);

            imageView = itemView.findViewById(R.id.imageEliminarSolicitud);
            tvTitulo = itemView.findViewById(R.id.textViewTituloSolicitud);
            tvDescripcion = itemView.findViewById(R.id.textViewDescripicionSolicitud);
        }
    }
}
