package com.guideme.application.android.modelo;

import org.json.JSONException;
import org.json.JSONObject;

public class Opinion {
    private int id;
    private Usuario usuario;
    private int lugar;
    private boolean like;
    private double valor;

    public Opinion(JSONObject jsonObject) throws JSONException {
        this.id = jsonObject.getInt("id");
        this.usuario = new Usuario(jsonObject.getJSONObject("usuario"), 0);
        this.lugar = jsonObject.getInt("lugar");
        this.like = jsonObject.getBoolean("like");
        this.valor = jsonObject.getInt("valor");
    }

    public Opinion(int id, Usuario usuario, int lugar, boolean like, double valor) {
        this.id = id;
        this.usuario = usuario;
        this.lugar = lugar;
        this.like = like;
        this.valor = valor;
    }

    public Opinion(int id, Usuario usuario, int lugar, boolean like) {
        this.id = id;
        this.usuario = usuario;
        this.lugar = lugar;
        this.like = like;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public int getLugar() {
        return lugar;
    }

    public void setLugar(int lugar) {
        this.lugar = lugar;
    }

    public boolean isLike() {
        return like;
    }

    public void setLike(boolean like) {
        this.like = like;
    }

    public JSONObject getJSONOpinion() throws JSONException {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("id", id);
        jsonObject.put("usuario", usuario.getJSONUsuario());
        jsonObject.put("lugar", lugar);
        jsonObject.put("like", like);
        jsonObject.put("valor", valor);

        return jsonObject;
    }
}
