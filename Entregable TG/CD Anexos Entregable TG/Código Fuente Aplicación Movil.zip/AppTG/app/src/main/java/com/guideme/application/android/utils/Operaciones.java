package com.guideme.application.android.utils;

import com.guideme.application.android.modelo.Comentario;


import java.util.ArrayList;

public class Operaciones {

    public Operaciones() {
    }

    public float calcularCalificacion(ArrayList<Comentario> comentarios) {
        if (comentarios == null) return (float) 0;
        float acumulador = 0;
        float contador = 0;

        for (Comentario comentario : comentarios) {
            acumulador += comentario.getCalificacion();
            contador++;
        }
        float rating = acumulador / contador;
        rating = Math.round(rating * 10.0f) / 10.0f;
        //System.out.println(rating);
        return rating;
    }
}
