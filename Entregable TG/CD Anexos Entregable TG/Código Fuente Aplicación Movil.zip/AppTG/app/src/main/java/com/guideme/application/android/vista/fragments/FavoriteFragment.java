package com.guideme.application.android.vista.fragments;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.SearchView;
import android.widget.TextView;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.guideme.application.android.utils.Constants;
import com.guideme.application.android.utils.Consultas;
import com.guideme.application.android.utils.Operaciones;
import com.guideme.application.android.R;
import com.guideme.application.android.modelo.Lugar;
import com.guideme.application.android.modelo.Usuario;
import com.guideme.application.android.vista.adapters.recycler.LugarAdapterRecycler;
import com.guideme.application.android.vista.activities.ActionBar;
import com.guideme.application.android.vista.activities.ContainerActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class FavoriteFragment extends Fragment {

    private ProgressBar progressBar;
    private TextView tvNotFound;
    private LugarAdapterRecycler lugarAdapterRecycler;
    private Usuario usuario;
    ArrayList<Lugar> lugaresFavoritos;
    ArrayList<Lugar> lugaresFavoritosConsulta;
    private String key;
    private Consultas consultas;
    private String url_favoritos;
    private RecyclerView recyclerView;
    private boolean isCreated = false;

    public FavoriteFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_favorite, container, false);
        SearchView searchView = view.findViewById(R.id.search_view_favorite);
        recyclerView = view.findViewById(R.id.recyclerPlaceFavorite);
        progressBar = view.findViewById(R.id.progressBar);
        tvNotFound = view.findViewById(R.id.tvNotFound);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity());
        isCreated = true;

        recyclerView.setLayoutManager(linearLayoutManager);

        usuario = ((ContainerActivity) Objects.requireNonNull(getActivity())).getUsuario();
        lugaresFavoritos = new ArrayList<>();
        lugaresFavoritosConsulta = new ArrayList<>();
        consultas = new Consultas();

        key = ((ContainerActivity) getActivity()).getKey();

        url_favoritos = Constants.URL + Constants.URL_LUGARES_API +
                Constants.CONSULTA_SUSCRITO + Constants.CONSULTA_USUARIOS + usuario.getUid();

        obtenerFavoritos(url_favoritos, recyclerView);

        ActionBar actionBar = new ActionBar();
        actionBar.showToolbar("Favoritos", false, getActivity(), view);

        searchView.setOnQueryTextListener(new android.widget.SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                if (!lugaresFavoritos.isEmpty()) {
                    ArrayList<Lugar> lugaresFiltrados = consultas.consultaLugaresPorNombre(lugaresFavoritos, newText);
                    lugarAdapterRecycler.setFilter(lugaresFiltrados);
                    if (lugaresFiltrados.isEmpty()) {
                        tvNotFound.setVisibility(View.VISIBLE);
                    } else {
                        tvNotFound.setVisibility(View.GONE);
                    }
                }
                return false;
            }

        });
        searchView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            }
        });

        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        if(!isCreated){
            obtenerFavoritos(url_favoritos, recyclerView);
        }

    }

    public void obtenerFavoritos(String url, final RecyclerView recyclerView) {
        final Operaciones operaciones = new Operaciones();
        RequestQueue requestQueue = Volley.newRequestQueue(Objects.requireNonNull(getContext()));
        final JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, url,
                null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                JSONObject jsonObject;
                //boolean jsonSuscripcion;
                for (int i = 0; i < response.length(); i++) {
                    try {
                        //jsonSuscripcion = response.getJSONObject(i).getBoolean("notificaciones");
                        //if (jsonSuscripcion) {
                        jsonObject = response.getJSONObject(i);
                        Lugar lugar = new Lugar(jsonObject);
                        lugar.setRating(operaciones.calcularCalificacion(lugar.getComentarios()));
                        lugaresFavoritos.add(lugar);
                        //}


                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }

                progressBar.setVisibility(View.GONE);
                if (!lugaresFavoritos.isEmpty()) {
                    recyclerView.setVisibility(View.VISIBLE);
                    lugarAdapterRecycler = new LugarAdapterRecycler(getActivity(), lugaresFavoritos,
                            usuario, key);
                    recyclerView.setAdapter(lugarAdapterRecycler);
                } else {
                    tvNotFound.setVisibility(View.VISIBLE);
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }) {
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> params = new HashMap<>();
                params.put("Content-Type", "application/json; charset=UTF-8");
                params.put("Authorization", key);
                return params;
            }
        };
        jsonArrayRequest.setRetryPolicy(new DefaultRetryPolicy(
                DefaultRetryPolicy.DEFAULT_TIMEOUT_MS * 3,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        requestQueue.add(jsonArrayRequest);
    }


}
