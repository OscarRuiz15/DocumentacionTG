package com.guideme.application.android.vista.activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.NavUtils;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import com.guideme.application.android.R;
import com.guideme.application.android.modelo.Lugar;
import com.guideme.application.android.modelo.Producto;
import com.guideme.application.android.modelo.Usuario;
import com.guideme.application.android.vista.adapters.recycler.ProductoAdapterRecycler;

import java.util.ArrayList;

public class VerProductosActivity extends AppCompatActivity {

    private Lugar lugar;
    private Usuario usuario;
    private String key;
    private ArrayList<Producto> productos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ver_productos);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        if (savedInstanceState != null) {
            lugar = (Lugar) savedInstanceState.getSerializable("lugar");
            usuario = (Usuario) savedInstanceState.getSerializable("usuario");
            productos = (ArrayList<Producto>) savedInstanceState.getSerializable("productos");
            key = savedInstanceState.getString("key");
        } else {
            lugar = (Lugar) (bundle != null ? bundle.getSerializable("lugar") : null);
            usuario = (Usuario) (bundle != null ? bundle.getSerializable("usuario") : null);
            key = bundle != null ? bundle.getString("key") : null;
            productos = (ArrayList<Producto>) bundle.getSerializable("productos");
        }


        RecyclerView recyclerView = findViewById(R.id.recyclerProductos);
        TextView tvNotFound = findViewById(R.id.tvNotFound);

        if (productos.isEmpty()) {
            tvNotFound.setVisibility(View.VISIBLE);
        }

        GridLayoutManager gridLayoutManager = new GridLayoutManager(this, 2);
        recyclerView.setLayoutManager(gridLayoutManager);


        ProductoAdapterRecycler productoAdapterRecycler = new ProductoAdapterRecycler(this, lugar, usuario, key, productos);
        recyclerView.setLayoutManager(gridLayoutManager);
        recyclerView.setAdapter(productoAdapterRecycler);

        ActionBar actionBar = new ActionBar();
        actionBar.showToolbar("Productos", true, this);
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            Intent intent = NavUtils.getParentActivityIntent(this);
            if (intent != null) {
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                NavUtils.navigateUpTo(this, intent);
            }

            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onSaveInstanceState(Bundle savedInstanceState) {
        savedInstanceState.putSerializable("lugar", lugar);
        savedInstanceState.putSerializable("usuario", usuario);
        savedInstanceState.putSerializable("productos", productos);
        savedInstanceState.putString("key", key);

        super.onSaveInstanceState(savedInstanceState);
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);

        lugar = (Lugar) savedInstanceState.getSerializable("lugar");
        usuario = (Usuario) savedInstanceState.getSerializable("usuario");
        productos = (ArrayList<Producto>) savedInstanceState.getSerializable("productos");
        key = savedInstanceState.getString("key");
    }
}
