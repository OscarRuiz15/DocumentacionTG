package com.guideme.application.android.vista.dialog;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.view.Window;
import android.widget.ImageView;

import com.guideme.application.android.R;
import com.guideme.application.android.vista.fragments.GlideApp;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.Objects;

public class ImageDialog {

    public ImageDialog(Context context, String foto) {

        Dialog dialog = new Dialog(context);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(true);
        Objects.requireNonNull(dialog.getWindow()).setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.setContentView(R.layout.dialogo_imagen);

        ImageView imageView = dialog.findViewById(R.id.imagenDialogo);

        FirebaseStorage firebaseStorage = FirebaseStorage.getInstance();
        StorageReference storageReference;

        try {
            storageReference = firebaseStorage.getReferenceFromUrl(foto);
            GlideApp.with(context)
                    .load(storageReference)
                    .into(imageView);
        } catch (Exception e) {
            Uri path = Uri.parse(foto);
            imageView.setImageURI(path);
        }
        dialog.show();
    }
}
