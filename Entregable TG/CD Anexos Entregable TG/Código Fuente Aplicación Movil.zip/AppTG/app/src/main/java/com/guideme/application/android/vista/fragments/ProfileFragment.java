package com.guideme.application.android.vista.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.guideme.application.android.utils.Constants;
import com.guideme.application.android.R;
import com.guideme.application.android.modelo.Solicitud;
import com.guideme.application.android.modelo.Usuario;
import com.guideme.application.android.vista.activities.ActionBar;
import com.guideme.application.android.vista.activities.ConsultaLugaresActivity;
import com.guideme.application.android.vista.activities.ContainerActivity;
import com.guideme.application.android.vista.activities.ModificarContrasenaActivity;
import com.guideme.application.android.vista.activities.ModificarPerfilActivity;
import com.guideme.application.android.vista.activities.ModificarPreferencias;
import com.guideme.application.android.vista.activities.NuevaSolicitudActivity;
import com.guideme.application.android.vista.adapters.recycler.SolicitudesAdapterRecycler;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class ProfileFragment extends Fragment implements View.OnClickListener {

    private Usuario usuario;

    private TextView tvNumeroVisitas;
    private TextView tvNumeroSuscripiones;
    private TextView tvNumeroLugares;

    private Button btnLugares;

    private RecyclerView recyclerView;
    private SolicitudesAdapterRecycler solicitudesAdapterRecycler;

    private ArrayList<Solicitud> solicitudes;
    private String key;

    private View coordinatorLayout;

    public ProfileFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_profile, container, false);
        ImageView imageView = view.findViewById(R.id.imageProfile);
        tvNumeroVisitas = view.findViewById(R.id.textViewNumeroVisitas);
        tvNumeroSuscripiones = view.findViewById(R.id.textViewNumeroSuscripciones);
        tvNumeroLugares = view.findViewById(R.id.textViewNumeroLugares);
        coordinatorLayout = view.findViewById(R.id.coordinatorProfileFragment);

        Button btnSolicitud = view.findViewById(R.id.btnNuevaSolicitud);
        btnLugares = view.findViewById(R.id.btnMisLugares);
        Button btnVisita = view.findViewById(R.id.btnVisita);
        recyclerView = view.findViewById(R.id.recyclerSolicitud);

        btnLugares.setOnClickListener(this);
        btnVisita.setOnClickListener(this);
        btnSolicitud.setOnClickListener(this);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(linearLayoutManager);

        usuario = ((ContainerActivity) Objects.requireNonNull(getActivity())).getUsuario();
        solicitudes = new ArrayList<>();

        obtenerSolicitudes();

        FirebaseStorage firebaseStorage = FirebaseStorage.getInstance();
        StorageReference storageReference;

        // Download directly from StorageReference using Glide
        // (See MyAppGlideModule for Loader registration)
        try {
            storageReference = firebaseStorage.getReferenceFromUrl(usuario.getFoto());
            GlideApp.with(getContext())
                    .load(storageReference)
                    .into(imageView);
        } catch (Exception e) {
            GlideApp.with(getContext())
                    .load(usuario.getFoto())
                    .into(imageView);
        }

        ActionBar actionBar = new ActionBar();
        actionBar.showToolbar(usuario.getNombre(), false, getActivity(), view);
        setHasOptionsMenu(true);

        key = ((ContainerActivity) getActivity()).getKey();

        consultaCantidad();
        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        consultaCantidad();
    }

    private void consultaCantidad() {
        //System.out.println(usuario.toString());
        //URLS
        String urlvisitas = Constants.URL + Constants.URL_VISITAS_API +
                Constants.CONSULTA_CANTIDAD + Constants.CONSULTA_USUARIOS
                + usuario.getUid();
        String urlsuscripiciones = Constants.URL + Constants.URL_SUSCRIPCIONES_API +
                Constants.CONSULTA_CANTIDAD + Constants.CONSULTA_USUARIOS
                + usuario.getUid();

        String urllugares = Constants.URL + Constants.URL_LUGARES_API +
                Constants.CONSULTA_CANTIDAD + Constants.CONSULTA_USUARIOS
                + usuario.getUid();

        RequestQueue requestQueue = Volley.newRequestQueue(Objects.requireNonNull(getContext()));

        JsonObjectRequest cantidadvisitas = new JsonObjectRequest(Request.Method.GET, urlvisitas, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {
                    tvNumeroVisitas.setText(response.getString("user_count"));

                } catch (JSONException e) {
                    tvNumeroVisitas.setText("0");
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                tvNumeroVisitas.setText("0");
            }
        }) {
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> params = new HashMap<>();
                params.put("Content-Type", "application/json; charset=UTF-8");
                params.put("Authorization", key);
                return params;
            }
        };

        JsonObjectRequest cantidadlugares = new JsonObjectRequest(Request.Method.GET, urllugares, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {
                    String numeroLugares = response.getString("user_count");
                    tvNumeroLugares.setText(numeroLugares);
                    if(numeroLugares.equals("0")) btnLugares.setVisibility(View.GONE);
                } catch (JSONException e) {
                    tvNumeroLugares.setText("0");
                    btnLugares.setVisibility(View.GONE);
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                tvNumeroLugares.setText("0");
            }
        }) {
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> params = new HashMap<>();
                params.put("Content-Type", "application/json; charset=UTF-8");
                params.put("Authorization", key);
                return params;
            }
        };

        JsonObjectRequest cantidadsuscripciones = new JsonObjectRequest(Request.Method.GET, urlsuscripiciones, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {
                    tvNumeroSuscripiones.setText(response.getString("user_count"));

                } catch (JSONException e) {
                    tvNumeroSuscripiones.setText("0");
                    btnLugares.setVisibility(View.GONE);
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                tvNumeroSuscripiones.setText("0");
            }
        }) {
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> params = new HashMap<>();
                params.put("Content-Type", "application/json; charset=UTF-8");
                params.put("Authorization", key);
                return params;
            }
        };
        cantidadlugares.setRetryPolicy(new DefaultRetryPolicy(
                DefaultRetryPolicy.DEFAULT_TIMEOUT_MS * 3,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        cantidadsuscripciones.setRetryPolicy(new DefaultRetryPolicy(
                DefaultRetryPolicy.DEFAULT_TIMEOUT_MS * 3,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        cantidadvisitas.setRetryPolicy(new DefaultRetryPolicy(
                DefaultRetryPolicy.DEFAULT_TIMEOUT_MS * 3,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        requestQueue.add(cantidadvisitas);
        requestQueue.add(cantidadlugares);
        requestQueue.add(cantidadsuscripciones);
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.menu_modificar, menu);
        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Intent intent;
        Bundle bundle;

        switch (item.getItemId()) {
            case R.id.menu_modificar:
                intent = new Intent(getContext(), ModificarPerfilActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                bundle = new Bundle();
                bundle.putSerializable("usuario", usuario);
                bundle.putString("key", key);
                intent.putExtras(bundle);
                startActivity(intent);
                return true;
            case R.id.menu_preferencias:
                intent = new Intent(getContext(), ModificarPreferencias.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                bundle = new Bundle();
                bundle.putSerializable("usuario", usuario);
                bundle.putString("key", key);
                intent.putExtras(bundle);
                startActivity(intent);
                return true;
            case R.id.menu_cambiar_contra:
                intent = new Intent(getContext(), ModificarContrasenaActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                bundle = new Bundle();
                bundle.putSerializable("usuario", usuario);
                bundle.putString("key", key);
                intent.putExtras(bundle);
                startActivity(intent);
                return true;
            case R.id.menu_logout:
                ((ContainerActivity) getActivity()).logOut();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public void goToNuevaSolicitud() {
        Intent intent = new Intent(getContext(), NuevaSolicitudActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        Bundle bundle = new Bundle();
        bundle.putSerializable("usuario", usuario);
        bundle.putString("key", key);
        intent.putExtras(bundle);
        startActivity(intent);
    }

    @Override
    public void onClick(View v) {
        String url;
        switch (v.getId()) {
            case R.id.btnNuevaSolicitud:
                goToNuevaSolicitud();
                break;
            case R.id.btnVisita:
                url = Constants.URL + Constants.URL_LUGARES_API + Constants.URL_LUGARES_VISITADOS_API + Constants.CONSULTA_USUARIOS + usuario.getUid();
                goToLugares(url, "Mis Visitas");
                break;
            case R.id.btnMisLugares:
                url = Constants.URL + Constants.URL_LUGARES_API + Constants.CONSULTA_PROPIETARIO + usuario.getUid();
                goToLugares(url, "Mis Lugares");
                break;
        }

    }

    public void obtenerSolicitudes() {
        String url = Constants.URL + Constants.URL_SOLICITUDES_API + Constants.CONSULTA_USUARIOS + usuario.getUid();
        RequestQueue requestQueue = Volley.newRequestQueue(Objects.requireNonNull(getContext()));
        final JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, url,
                null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                JSONObject jsonObject;
                for (int i = 0; i < response.length(); i++) {
                    try {
                        jsonObject = response.getJSONObject(i);
                        Solicitud solicitud = new Solicitud(jsonObject);
                        solicitudes.add(solicitud);

                    } catch (JSONException e) {
                        //e.printStackTrace();
                    }
                }

                if (!solicitudes.isEmpty()) {
                    solicitudesAdapterRecycler = new SolicitudesAdapterRecycler(getActivity(),
                            solicitudes, key, coordinatorLayout);
                    recyclerView.setAdapter(solicitudesAdapterRecycler);
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }) {
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> params = new HashMap<>();
                params.put("Content-Type", "application/json; charset=UTF-8");
                params.put("Authorization", key);
                return params;
            }
        };
        jsonArrayRequest.setRetryPolicy(new DefaultRetryPolicy(
                DefaultRetryPolicy.DEFAULT_TIMEOUT_MS * 3,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        requestQueue.add(jsonArrayRequest);
    }

    private void goToLugares(String url, String nombre) {
        Intent intent = new Intent(getContext(), ConsultaLugaresActivity.class);
        Bundle bundle = new Bundle();
        bundle.putString("nombre", nombre);
        bundle.putSerializable("usuario", usuario);
        bundle.putString("url", url);
        bundle.putString("key", key);
        intent.putExtras(bundle);
        startActivity(intent);
    }
}

