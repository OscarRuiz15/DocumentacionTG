package com.guideme.application.android.utils;

import com.guideme.application.android.modelo.Usuario;

import java.time.LocalDate;
import java.util.Calendar;

public class ControladorFechas {

    private Calendar calendar;

    private final String[] DIAS_SEMANA = {"Domingo", "Lunes", "Martes", "Miercoles", "Jueves", "Viernes", "Sabado"};
    private final String[] MES_INICIAL = {"ENE", "FEB", "MAR", "ABR", "MAY", "JUN", "JUL", "AGO", "SEP", "OCT", "NOV", "DIC"};
    private final String[] MES = {"Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"};


    public ControladorFechas() {
        calendar = Calendar.getInstance();
    }

    public ControladorFechas(Calendar calendar) {
        this.calendar = calendar;
    }

    public String getDiaSemana(int i) {
        return DIAS_SEMANA[i - 1];
    }

    public String getMesInicial(int i) {
        return MES_INICIAL[i - 1];
    }

    public String getMes(int i) {
        return MES[i - 1];
    }

    public String getDate() {
        int mesActual = calendar.get(Calendar.MONTH) + 1;
        int dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH);
        int year = calendar.get(Calendar.YEAR);
        String diaFormateado = (dayOfMonth < 10) ? Constants.CERO + String.valueOf(dayOfMonth) : String.valueOf(dayOfMonth);
        String mesFormateado = (mesActual < 10) ? Constants.CERO + String.valueOf(mesActual) : String.valueOf(mesActual);
        return year + Constants.GUION + mesFormateado + Constants.GUION + diaFormateado;
    }

    public String getHour() {
        int hourOfDay = calendar.get(Calendar.HOUR_OF_DAY);
        int minute = calendar.get(Calendar.MINUTE);
        int second = calendar.get(Calendar.SECOND);

        //Formateo el hora obtenido: antepone el 0 si son menores de 10
        String horaFormateada = (hourOfDay < 10) ? String.valueOf(Constants.CERO + hourOfDay) : String.valueOf(hourOfDay);
        //Formateo el minuto obtenido: antepone el 0 si son menores de 10
        String minutoFormateado = (minute < 10) ? String.valueOf(Constants.CERO + minute) : String.valueOf(minute);
        String segundoFormateado = (second < 10) ? String.valueOf(Constants.CERO + second) : String.valueOf(second);

        return horaFormateada + Constants.DOS_PUNTOS + minutoFormateado + Constants.DOS_PUNTOS + segundoFormateado;
    }

    public String[] obtenerFecha(String fechainicio) {
        String fecha[] = fechainicio.split("-");
        int year = Integer.parseInt(fecha[0]);
        int mes = Integer.parseInt(fecha[1]);
        int dia = Integer.parseInt(fecha[2]);
        Calendar c = Calendar.getInstance();
        c.set(year, mes - 1, dia);
        String res[] = new String[3];
        res[0] = getMesInicial(mes);
        res[1] = getDiaSemana(c.get(Calendar.DAY_OF_WEEK));
        res[2] = dia + "";

        return res;
    }

    public boolean esMayordeEdad(String fechaNacimiento) {
        int mesActual = calendar.get(Calendar.MONTH) + 1;
        int dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH);
        int year = calendar.get(Calendar.YEAR);
        String fecha[] = fechaNacimiento.split("-");
        int birthYear = Integer.parseInt(fecha[0]);
        int mes = Integer.parseInt(fecha[1]);
        int dia = Integer.parseInt(fecha[2]);
        int diffYear = year - birthYear - 1;

        if (diffYear < 17) {
            return false;
        } else if (diffYear >= 18) {
            return true;
        } else {
            int diffmes = mesActual - mes;
            if (diffmes > 0) {
                return true;
            } else if (diffmes == 0) {
                int diffDias = dayOfMonth - dia;
                if (diffDias >= 0) {
                    return true;
                } else {
                    return false;
                }
            } else {
                return false;
            }
        }


    }
}
