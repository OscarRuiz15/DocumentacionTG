package com.guideme.application.android.vista.activities;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.StrictMode;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.auth.api.signin.GoogleSignInResult;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GetTokenResult;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.guideme.application.android.R;
import com.guideme.application.android.modelo.Usuario;
import com.guideme.application.android.utils.Alerts;
import com.guideme.application.android.utils.Constants;
import com.guideme.application.android.utils.ValidarTextos;
import com.guideme.application.android.vista.dialog.TagsDialog;

import org.json.JSONException;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class CreateAccountActivity extends AppCompatActivity implements View.OnClickListener, GoogleApiClient.OnConnectionFailedListener {

    public final Calendar c = Calendar.getInstance();

    //Variables para obtener la fecha
    private int mes = c.get(Calendar.MONTH);
    private int dia = c.get(Calendar.DAY_OF_MONTH);
    private int anio = c.get(Calendar.YEAR);

    //Autenticacion Firebase//////////////////////
    private FirebaseAuth mAuth;
    private FirebaseAuth.AuthStateListener firebaseAuthListener;
    FirebaseUser user;

    //Google SignIn///////////////////////////////
    //private GoogleSignInClient mGoogleSignInClient;
    private GoogleApiClient googleApiClient;

    //Componentes del Activity//////////////////
    private ImageView imagen;
    private EditText etfecha;
    private EditText etnombre;
    private EditText etemail;
    private EditText ettelefono;
    private EditText etpass;
    private EditText passconf;
    private Spinner spDepartamento;
    private Spinner spMunicipio;
    private Spinner spGenero;
    private SignInButton signInButton;
    private ProgressDialog progressDialog;

    //Firebase Storage/////////////////////////
    private StorageReference storageReference;

    //Ruta del Archivo
    private Uri getAbsolutePhotoPath;

    private Button botonCrear;

    private LinearLayout layoutContacto;
    private LinearLayout layoutCompletar;
    private EditText tffecha;
    private Spinner spDepartamento2;
    private Spinner spMunicipio2;
    private Spinner spGenero2;
    private EditText ettelefono2;
    private TextView lblRegistrate;
    private TextView lblCrearGoogle;
    private Button botonContinuar;

    private String urlfoto = " ";

    private String idToken;

    private Alerts alerts;
    private AlertDialog errorAlertDialog;

    private Context context = this;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_account);
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        ActionBar actionBar = new ActionBar();
        alerts = new Alerts(this);
        actionBar.showToolbar(getResources().getString(R.string.toolbar_title_account), true, this);
        imagen = findViewById(R.id.imagenPerfil);
        etfecha = findViewById(R.id.editTextNacimiento);
        etnombre = findViewById(R.id.name);
        etemail = findViewById(R.id.email);
        ettelefono = findViewById(R.id.editTextTelefono);
        etpass = findViewById(R.id.password_create);
        passconf = findViewById(R.id.confirm_password);
        lblCrearGoogle = findViewById(R.id.lblCrearGoogle);
        lblRegistrate = findViewById(R.id.lblRegistrate);

        spGenero = findViewById(R.id.spinnerGenero);
        spDepartamento = findViewById(R.id.spinnerDepartamento);
        spMunicipio = findViewById(R.id.spinnerMunicipio);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.genero_array, R.layout.spinner_item);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spGenero.setAdapter(adapter);

        adapter = ArrayAdapter.createFromResource(this,
                R.array.departamentos_array, R.layout.spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spDepartamento.setAdapter(adapter);
        spDepartamento.setSelection(30);

        spDepartamento.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                switch (spDepartamento.getSelectedItemPosition()) {
                    case 30:
                        spMunicipio.setVisibility(View.VISIBLE);
                        break;
                    default:
                        spMunicipio.setVisibility(View.GONE);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        adapter = ArrayAdapter.createFromResource(this,
                R.array.municipios_valle, R.layout.spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spMunicipio.setAdapter(adapter);
        spMunicipio.setSelection(19);

        botonContinuar = findViewById(R.id.btnContinuar);
        botonCrear = findViewById(R.id.joinUs);

        layoutContacto = findViewById(R.id.layout_Contacto);

        ////////////////////////////////////////////////////////////////////////////////////////////
        layoutCompletar = findViewById(R.id.layout_Completar);
        tffecha = findViewById(R.id.tfFecha);
        spGenero2 = findViewById(R.id.spinnerGeneroCompletar);
        spDepartamento2 = findViewById(R.id.spinnerDepartamentoCompletar);
        spMunicipio2 = findViewById(R.id.spinnerMunicipioCompletar);
        ettelefono2 = findViewById(R.id.editTextTelefono2);

        adapter = ArrayAdapter.createFromResource(this,
                R.array.genero_array, R.layout.spinner_item);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spGenero2.setAdapter(adapter);

        adapter = ArrayAdapter.createFromResource(this,
                R.array.departamentos_array, R.layout.spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spDepartamento2.setAdapter(adapter);
        spDepartamento2.setSelection(30);

        spDepartamento2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                switch (spDepartamento2.getSelectedItemPosition()) {
                    case 30:
                        spMunicipio2.setVisibility(View.VISIBLE);
                        break;
                    default:
                        spMunicipio2.setVisibility(View.GONE);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        adapter = ArrayAdapter.createFromResource(this,
                R.array.municipios_valle, R.layout.spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spMunicipio2.setAdapter(adapter);
        spMunicipio2.setSelection(19);

        layoutCompletar.setVisibility(View.GONE);

        etfecha.setOnClickListener(this);
        tffecha.setOnClickListener(this);
        ////////////////////////////////////////////////////////////////////////////////////////////

        progressDialog = new ProgressDialog(CreateAccountActivity.this);
        progressDialog.setMessage("Procesando");

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail()
                .build();

        googleApiClient = new GoogleApiClient.Builder(this)
                .enableAutoManage(this, this)
                .addApi(Auth.GOOGLE_SIGN_IN_API, gso)
                .build();

        signInButton = findViewById(R.id.sign_in_button);
        signInButton.setOnClickListener(this);
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        mAuth = FirebaseAuth.getInstance();
        firebaseAuthListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
            }
        };

        FirebaseStorage storage = FirebaseStorage.getInstance();
        storageReference = storage.getReferenceFromUrl(Constants.FIREBASE_STORAGE_URL);

        botonContinuar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                crearCuentaGoogle(user);
            }
        });
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////GOOGLE WITH FIREBASE//////////////////////////////////////////////////
    @Override
    protected void onStart() {
        super.onStart();
        mAuth.addAuthStateListener(firebaseAuthListener);
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (firebaseAuthListener != null) {
            mAuth.removeAuthStateListener(firebaseAuthListener);
        }
    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {
    }

    private void signIn() {
        if (alerts.isConnected()) {
            Intent signInIntent = Auth.GoogleSignInApi.getSignInIntent(googleApiClient);
            startActivityForResult(signInIntent, Constants.RC_SIGN_IN);
            signInButton.setEnabled(false);
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            Uri path = data.getData();
            imagen.setImageURI(path);
            getAbsolutePhotoPath = path;
        }

        if (requestCode == Constants.RC_SIGN_IN) {

            Uri path = data.getData();
            imagen.setImageURI(path);
            getAbsolutePhotoPath = path;
            GoogleSignInResult result = Auth.GoogleSignInApi.getSignInResultFromIntent(data);
            //System.out.println(data.toString());
            //System.out.println(result.toString());
            handleSignInResult(result);

        } else {
            //System.out.println("Paila my friend");
        }

    }

    private void handleSignInResult(GoogleSignInResult googleSignInResult) {
        if (googleSignInResult.isSuccess()) {
            firebaseAuthWithGoogle(Objects.requireNonNull(googleSignInResult.getSignInAccount()));
        } else {
            Toast.makeText(CreateAccountActivity.this, "No se pudo iniciar sesion ",
                    Toast.LENGTH_SHORT).show();
        }
    }

    private void firebaseAuthWithGoogle(GoogleSignInAccount acct) {
        AuthCredential credential = GoogleAuthProvider.getCredential(acct.getIdToken(), null);
        mAuth.signInWithCredential(credential).addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful()) {
                    // Sign in success, update UI with the signed-in user's information
                    user = mAuth.getCurrentUser();
                    if (user != null) {
                        user.getIdToken(true)
                                .addOnCompleteListener(new OnCompleteListener<GetTokenResult>() {
                                    public void onComplete(@NonNull Task<GetTokenResult> task) {
                                        if (task.isSuccessful()) {
                                            idToken = Objects.requireNonNull(task.getResult()).getToken();
                                            getJSONVolley(user, idToken);
                                        } else {
                                            String mensaje = "Existe un error para ingresar con tu " +
                                                    "cuenta de Google, intenta ingresar mas tarde";
                                            errorAlertDialog = alerts.createErrorAlert(400, mensaje).create();
                                            errorAlertDialog.show();
                                        }
                                    }
                                });
                    }
                } else {
                    Toast.makeText(CreateAccountActivity.this, "No se pudo conectar",
                            Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    private void goToContainer(Usuario usuario, String key) {
        Intent intent = new Intent(this, ContainerActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        Bundle bundle = new Bundle();
        bundle.putSerializable("usuario", usuario);
        bundle.putString("key", key);
        intent.putExtras(bundle);
        startActivity(intent);
    }

    private String uploadPhoto(String child) {
        StorageReference imageReference = storageReference.child(child);

        UploadTask uploadTask = imageReference.putFile(getAbsolutePhotoPath);

        uploadTask.addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                /*Toast.makeText(CreateAccountActivity.this, "Mal",
                        Toast.LENGTH_SHORT).show();*/

            }
        }).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
            }
        });
        return Constants.FIREBASE_STORAGE_URL + Constants.BAR + child;
    }

    public void agregarImagen(View view) {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (inputMethodManager != null) {
            inputMethodManager.hideSoftInputFromWindow(etnombre.getWindowToken(), 0);
            inputMethodManager.hideSoftInputFromWindow(etemail.getWindowToken(), 0);
            inputMethodManager.hideSoftInputFromWindow(etpass.getWindowToken(), 0);
            inputMethodManager.hideSoftInputFromWindow(ettelefono.getWindowToken(), 0);
            inputMethodManager.hideSoftInputFromWindow(passconf.getWindowToken(), 0);
        }

        startActivityForResult(Intent.createChooser(intent, "Selecciona la Aplicación"), 10);
    }

    private void obtenerFecha(final EditText editText) {

        DatePickerDialog recogerFecha = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                //Esta variable lo que realiza es aumentar en uno el mes ya que comienza desde 0 = enero
                final int mesActual = month + 1;

                //Formateo el día obtenido: antepone el 0 si son menores de 10
                String diaFormateado = (dayOfMonth < 10) ? Constants.CERO + String.valueOf(dayOfMonth) : String.valueOf(dayOfMonth);

                //Formateo el mes obtenido: antepone el 0 si son menores de 10
                String mesFormateado = (mesActual < 10) ? Constants.CERO + String.valueOf(mesActual) : String.valueOf(mesActual);
                Calendar calendar = Calendar.getInstance();
                calendar.set(year, month, dayOfMonth);

                //Muestro la fecha con el formato deseado
                String fecha = String.valueOf(year) + Constants.GUION + mesFormateado + Constants.GUION + diaFormateado;
                editText.setText(fecha);
                anio = year;
                mes = month;
                dia = dayOfMonth;
            }
            //Estos valores deben ir en ese orden, de lo contrario no mostrara la fecha actual
        }, anio, mes, dia);

        //Muestro el widget
        recogerFecha.show();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.sign_in_button:
                signIn();
                break;
            case R.id.editTextNacimiento:
                obtenerFecha(etfecha);
                break;
            case R.id.tfFecha:
                obtenerFecha(tffecha);
                break;
        }
    }

    public void verInterfaz() {
        signInButton.setVisibility(View.INVISIBLE);
        botonCrear.setVisibility(View.INVISIBLE);
        lblCrearGoogle.setVisibility(View.INVISIBLE);
        lblRegistrate.setVisibility(View.INVISIBLE);

        layoutContacto.setVisibility(View.GONE);
        layoutCompletar.setVisibility(View.VISIBLE);
    }

    ///////////////CREAR CUENTA NORMAL
    public void CrearCuenta(View view) {
        if (alerts.isConnected()) {
            progressDialog.show();
            ValidarTextos validarTextos = new ValidarTextos();
            boolean nombrevalido = validarTextos.validateBlank(etnombre, this);
            boolean emailvalido = validarTextos.validateEmail(etemail, this);
            boolean fechavalido = validarTextos.validateBlank(etfecha, this);

            boolean passvalido = validarTextos.validatePassword(etpass, passconf, this);

            boolean telefonovalido = true;
            if (!ettelefono.getText().toString().trim().equals("")) {
                telefonovalido = validarTextos.validatePhone(ettelefono, this);
            } else {
                telefonovalido = true;
            }

            if (nombrevalido && emailvalido && fechavalido && telefonovalido && passvalido) {
                String email = etemail.getText().toString().trim();
                String password = etpass.getText().toString().trim();
                mAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            FirebaseUser mFirebaseUser = mAuth.getCurrentUser();
                            String uid = mFirebaseUser != null ? mFirebaseUser.getUid() : null;

                            if (mFirebaseUser != null) {
                                mFirebaseUser.getIdToken(true)
                                        .addOnCompleteListener(new OnCompleteListener<GetTokenResult>() {
                                            public void onComplete(@NonNull Task<GetTokenResult> task) {
                                                if (task.isSuccessful()) {
                                                    idToken = Objects.requireNonNull(task.getResult()).getToken();
                                                } else {
                                                    String mensaje = "Existe un error para crear tu " +
                                                            "cuenta, intenta ingresar mas tarde";
                                                    errorAlertDialog = alerts.createErrorAlert(400, mensaje).create();
                                                    errorAlertDialog.show();
                                                }
                                            }
                                        });
                            }

                            urlfoto = " ";

                            if (getAbsolutePhotoPath != null) {
                                urlfoto = uploadPhoto(uid);
                            } else {
                                urlfoto = "gs://trabajo-de-grado-f9cb8.appspot.com/imgperfil.png";
                            }

                            postJSONVolley(uid, urlfoto, idToken);

                            progressDialog.hide();
                        } else {
                            Toast.makeText(CreateAccountActivity.this, "No se pudo crear",
                                    Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            } else {
                progressDialog.hide();
            }
        }
    }

    public void postJSONVolley(final String uid, final String foto, final String key) {
        try {
            RequestQueue requestQueue = Volley.newRequestQueue(this);

            JSONObject jsonBody = new JSONObject();
            String nombre = etnombre.getText().toString().trim();
            String telefono = ettelefono.getText().toString().trim();
            String email = etemail.getText().toString().trim();
            String fecha = etfecha.getText().toString().trim();
            String genero = spGenero.getSelectedItem() + "";
            String departamento = spDepartamento.getSelectedItem() + "";
            String municipio = "";
            if (spMunicipio.getVisibility() != View.GONE) {
                municipio = spMunicipio.getSelectedItem() + "";
            }
            jsonBody.put("uid", uid);
            jsonBody.put("nombre", nombre);
            jsonBody.put("foto", foto);
            jsonBody.put("fecha_nacimiento", fecha);
            jsonBody.put("telefono", telefono);
            jsonBody.put("email", email);
            jsonBody.put("departamento", departamento);
            jsonBody.put("municipio", municipio);
            jsonBody.put("genero", genero);
            final Usuario usuario = new Usuario(0, uid, nombre, email, telefono, fecha, foto, null);
            final String mRequestBody = jsonBody.toString();

            StringRequest stringRequest = new StringRequest(Request.Method.POST, Constants.URL + Constants.URL_USUARIOS_API, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    getJSONUsuario(key, usuario);
                    //goToContainer(usuario, key);
                }
            }, new Response.ErrorListener() {

                @Override
                public void onErrorResponse(VolleyError error) {
                    String mensaje = "Hay un error al crear tu " +
                            "cuenta, intenta de nuevo";
                    errorAlertDialog = alerts.createErrorAlert(400, mensaje).create();
                    errorAlertDialog.show();
                    progressDialog.dismiss();
                }
            }) {
                /*@Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                    Map<String, String> params = new HashMap<String, String>();
                    params.put("Content-Type", "application/json; charset=UTF-8");
                    params.put("Authorization", "Token " + key);
                    return params;
                }*/

                @Override
                public String getBodyContentType() {
                    return "application/json; charset=utf-8";
                }

                @Override
                public byte[] getBody() {
                    return mRequestBody == null ? null : mRequestBody.getBytes(StandardCharsets.UTF_8);
                }

                @Override
                protected Response<String> parseNetworkResponse(NetworkResponse response) {
                    String responseString = "";
                    if (response != null) {
                        responseString = String.valueOf(response.statusCode);
                    }
                    return Response.success(responseString, HttpHeaderParser.parseCacheHeaders(response));
                }
            };

            requestQueue.add(stringRequest);

        } catch (JSONException e) {
            //e.printStackTrace();
        }
    }

    //////////////CREAR CUENTA CON GOOGLE
    public void crearCuentaGoogle(FirebaseUser user) {
        if (alerts.isConnected()) {
            progressDialog.show();
            ValidarTextos validarTextos = new ValidarTextos();
            boolean fechavalido = validarTextos.validateBlank(tffecha, this);

            boolean telefonovalido = true;
            if (!ettelefono.getText().toString().trim().equals("")) {
                telefonovalido = validarTextos.validatePhone(ettelefono2, this);
            } else {
                telefonovalido = true;
            }

            if (fechavalido && telefonovalido) {
                final String uid = user.getUid();
                final String nombre = user.getDisplayName();
                final String email = user.getEmail();
                final String foto_url = "" + user.getPhotoUrl();
                final String fecha_nacimiento = tffecha.getText().toString().trim();
                final String telefono = ettelefono2.getText().toString().trim(); //Dato a completar
                String genero = spGenero2.getSelectedItem() + "";
                String departamento = spDepartamento2.getSelectedItem() + "";
                String municipio = "";
                if (spMunicipio2.getVisibility() != View.GONE) {
                    municipio = spMunicipio2.getSelectedItem() + "";
                }

                Usuario usuario = new Usuario();
                usuario.setUid(uid);
                usuario.setNombre(nombre);
                usuario.setEmail(email);
                usuario.setFoto(foto_url);
                usuario.setFecha(fecha_nacimiento);
                usuario.setTelefono(telefono);
                usuario.setGenero(genero);
                usuario.setDepartamento(departamento);
                usuario.setMunicipio(municipio);

                postJSONVolley(usuario, idToken);
            }
        }
    }

    public void getJSONVolley(final FirebaseUser user, final String token) {
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        String url = Constants.URL + Constants.URL_USUARIOS_API + user.getUid() + Constants.GET_JSON;

        final JsonObjectRequest jsObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            //Si existe un usuario con ese uid, no crea ninguno
            @Override
            public void onResponse(JSONObject response) {
                try {
                    Usuario usuario = new Usuario(response);
                    goToContainer(usuario, token);
                } catch (JSONException e) {
                    //e.printStackTrace();
                }
            }
        },
                //Si da error porque no existe usuario con ese uid, lo crea
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        verInterfaz();
                    }
                }) {
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> params = new HashMap<>();
                params.put("Content-Type", "application/json; charset=UTF-8");
                params.put("Authorization", token);
                return params;
            }
        };
        jsObjectRequest.setRetryPolicy(new DefaultRetryPolicy(
                DefaultRetryPolicy.DEFAULT_TIMEOUT_MS * 3,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        requestQueue.add(jsObjectRequest);
    }

    public void postJSONVolley(final Usuario usuario, final String idToken) {
        botonContinuar.setEnabled(false);
        botonContinuar.setBackgroundResource(R.color.darker_gray);
        try {
            RequestQueue requestQueue = Volley.newRequestQueue(this);

            JSONObject jsonBody = new JSONObject();
            jsonBody.put("uid", usuario.getUid());
            jsonBody.put("nombre", usuario.getNombre());
            jsonBody.put("foto", usuario.getFoto());
            jsonBody.put("fecha_nacimiento", usuario.getFecha());
            jsonBody.put("telefono", usuario.getTelefono());
            jsonBody.put("email", usuario.getEmail());
            jsonBody.put("genero", usuario.getGenero());
            jsonBody.put("departamento", usuario.getDepartamento());
            jsonBody.put("municipio", usuario.getMunicipio());
            final String mRequestBody = jsonBody.toString();

            //System.out.println("JSON: " + mRequestBody);

            StringRequest stringRequest = new StringRequest(Request.Method.POST, Constants.URL + Constants.URL_USUARIOS_API, new Response.Listener<String>() {

                @Override
                public void onResponse(String response) {
                    //Log.i("LOG_VOLLEY", response);
                    getJSONUsuario(idToken, usuario);
                    progressDialog.dismiss();
                    //goToContainer(usuario, idToken);
                }
            }, new Response.ErrorListener() {

                @Override
                public void onErrorResponse(VolleyError error) {
                    String mensaje = "Hay un error al crear tu " +
                            "cuenta, intenta de nuevo";
                    errorAlertDialog = alerts.createErrorAlert(400, mensaje).create();
                    errorAlertDialog.show();
                    progressDialog.dismiss();
                    botonContinuar.setEnabled(true);
                    botonContinuar.setBackgroundResource(R.color.colorPrimaryDark);
                }
            }) {
                @Override
                public String getBodyContentType() {
                    return "application/json; charset=utf-8";
                }

                @Override
                public byte[] getBody() {
                    return mRequestBody == null ? null : mRequestBody.getBytes(StandardCharsets.UTF_8);
                }

                @Override
                protected Response<String> parseNetworkResponse(NetworkResponse response) {
                    String responseString = "";
                    if (response != null) {
                        responseString = String.valueOf(response.statusCode);
                    }
                    return Response.success(responseString, HttpHeaderParser.parseCacheHeaders(response));
                }
            };

            requestQueue.add(stringRequest);
        } catch (JSONException e) {
            //e.printStackTrace();
        }
    }

    /////////////OLA
    private void getJSONUsuario(final String key, Usuario usuario) {
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        String url = Constants.URL + Constants.URL_USUARIOS_API + usuario.getUid() + Constants.GET_JSON;
        JsonObjectRequest jsObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {
                    Usuario usuario = new Usuario(response);
                    new TagsDialog(context, key, usuario);
                } catch (JSONException e) {
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                botonContinuar.setEnabled(true);
                botonContinuar.setBackgroundResource(R.color.colorPrimaryDark);
            }
        }) {
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> params = new HashMap<>();
                params.put("Content-Type", "application/json; charset=UTF-8");
                params.put("Authorization", key);
                return params;
            }
        };
        jsObjectRequest.setRetryPolicy(new DefaultRetryPolicy(
                DefaultRetryPolicy.DEFAULT_TIMEOUT_MS * 3,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        requestQueue.add(jsObjectRequest);

    }
}
