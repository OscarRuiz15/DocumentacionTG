package com.guideme.application.android.modelo;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.Serializable;

public class Visita implements Serializable {


    private int id;
    private int usuario;
    private int lugar;
    private String fecha_visita;
    private String hora_visita;


    public Visita(JSONObject jsonObject) throws JSONException {
        this.id = jsonObject.getInt("id");
        this.usuario = jsonObject.getInt("usuario");
        this.lugar = jsonObject.getInt("lugar");
        this.fecha_visita = jsonObject.getString("fecha_visita");
        this.hora_visita = jsonObject.getString("hora_visita");
    }

    public String getFecha_visita() {
        return fecha_visita;
    }

    public void setFecha_visita(String fecha_visita) {
        this.fecha_visita = fecha_visita;
    }

    public String getHora_visita() {
        return hora_visita;
    }

    public void setHora_visita(String hora_visita) {
        this.hora_visita = hora_visita;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getUsuario() {
        return usuario;
    }

    public void setUsuario(int usuario) {
        this.usuario = usuario;
    }

    public int getLugar() {
        return lugar;
    }

    public void setLugar(int lugar) {
        this.lugar = lugar;
    }
}
