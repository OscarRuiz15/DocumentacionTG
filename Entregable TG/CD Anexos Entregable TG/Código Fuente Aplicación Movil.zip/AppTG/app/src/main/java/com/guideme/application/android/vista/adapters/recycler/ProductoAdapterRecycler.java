package com.guideme.application.android.vista.adapters.recycler;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.guideme.application.android.R;
import com.guideme.application.android.modelo.Lugar;
import com.guideme.application.android.modelo.Producto;
import com.guideme.application.android.modelo.Usuario;
import com.guideme.application.android.vista.activities.DetallesProductoActivity;
import com.guideme.application.android.vista.fragments.GlideApp;

import java.util.ArrayList;

public class ProductoAdapterRecycler extends RecyclerView.Adapter<ProductoAdapterRecycler.ProductoHolder> {

    private Context context;
    private ArrayList<Producto> productos;
    private Lugar lugar;
    private Usuario usuario;
    private String key;

    public ProductoAdapterRecycler(Context context, Lugar lugar, Usuario usuario, String key, ArrayList<Producto> productos) {
        this.context = context;
        this.lugar = lugar;
        this.usuario = usuario;
        this.key = key;
        this.productos = productos;
    }

    @NonNull
    @Override
    public ProductoHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.cardview_productos, parent, false);
        return new ProductoHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ProductoHolder holder, int position) {
        position = holder.getAdapterPosition();
        FirebaseStorage firebaseStorage = FirebaseStorage.getInstance();

        StorageReference storageReference;
        holder.nombre.setText(productos.get(position).getNombre());
        holder.precio.setText(productos.get(position).getPrecio());

        try {
            storageReference = firebaseStorage.getReferenceFromUrl(productos.get(position).getFoto());
            GlideApp.with(context)
                    .load(storageReference)
                    .into(holder.imagen);
        } catch (Exception e) {
            Uri path = Uri.parse(productos.get(position).getFoto());
            holder.imagen.setImageURI(path);
        }

        final int finalPosition = position;
        holder.imagen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, DetallesProductoActivity.class);
                Bundle bundle = new Bundle();
                bundle.putSerializable("usuario", usuario);
                bundle.putSerializable("lugar", lugar);
                bundle.putSerializable("producto", productos.get(finalPosition));
                bundle.putString("key", key);
                intent.putExtras(bundle);
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return productos.size();
    }

    class ProductoHolder extends RecyclerView.ViewHolder {

        ImageView imagen;
        TextView nombre;
        TextView precio;

        ProductoHolder(View itemView) {
            super(itemView);
            imagen = itemView.findViewById(R.id.imagenProducto);
            nombre = itemView.findViewById(R.id.nombreProducto);
            precio = itemView.findViewById(R.id.precioProducto);
        }
    }
}
