package com.guideme.application.android.vista.activities;

import android.content.Context;
import android.content.Intent;
import android.support.v4.app.NavUtils;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.guideme.application.android.R;
import com.guideme.application.android.modelo.Lugar;
import com.guideme.application.android.modelo.Producto;
import com.guideme.application.android.modelo.Usuario;
import com.guideme.application.android.vista.dialog.ImageDialog;
import com.guideme.application.android.vista.fragments.GlideApp;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.Objects;

public class DetallesProductoActivity extends AppCompatActivity {

    StorageReference storageReference;
    FirebaseStorage firebaseStorage;
    private Producto producto;
    Context context;
    private Usuario usuario;
    private Lugar lugar;
    private String key;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalles_producto);

        context = this;
        ActionBar actionBar = new ActionBar();

        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();

        if (savedInstanceState != null) {
            producto = (Producto) savedInstanceState.getSerializable("producto");
            lugar = (Lugar) savedInstanceState.getSerializable("lugar");
            usuario = (Usuario) savedInstanceState.getSerializable("usuario");
            key = savedInstanceState.getString("key");
        } else {
            producto = (Producto) (bundle != null ? bundle.getSerializable("producto") : null);
            lugar = (Lugar) (bundle != null ? bundle.getSerializable("lugar") : null);
            usuario = (Usuario) (bundle != null ? bundle.getSerializable("usuario") : null);
            key = bundle != null ? bundle.getString("key") : null;
        }

        actionBar.showToolbar(Objects.requireNonNull(producto).getNombre(), true, this);

        ImageView imagen = findViewById(R.id.imagenProducto);
        TextView nombre = findViewById(R.id.nombreProducto);
        TextView precio = findViewById(R.id.precioProducto);
        TextView descripcion = findViewById(R.id.descripcionProducto);

        nombre.setText(producto.getNombre());
        precio.setText(producto.getPrecio());
        descripcion.setText(producto.getDescripcion());

        firebaseStorage = FirebaseStorage.getInstance();
        storageReference = firebaseStorage.getReferenceFromUrl(producto.getFoto());
        GlideApp.with(this)
                .load(storageReference)
                .into(imagen);

        imagen.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                new ImageDialog(context, producto.getFoto());
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        boolean escomerciante = lugar.getId_propietario() == usuario.getId();
        // Inflate the menu; this adds items to the action bar if it is present.
        if (escomerciante) {
            getMenuInflater().inflate(R.menu.menu_modificar_producto_evento, menu);
        }

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.menu_modificar_producto_evento) {
            Intent intent;
            intent = new Intent(this, ModificarProductoActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            Bundle bundle = new Bundle();
            bundle.putSerializable("usuario", usuario);
            bundle.putSerializable("lugar", lugar);
            bundle.putSerializable("producto", producto);
            bundle.putString("key", key);
            intent.putExtras(bundle);
            startActivity(intent);
            return true;
        }
        if (item.getItemId() == android.R.id.home) {
            Intent intent = NavUtils.getParentActivityIntent(this);
            if (intent != null) {
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                NavUtils.navigateUpTo(this, intent);
            }

            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onSaveInstanceState(Bundle savedInstanceState) {
        savedInstanceState.putSerializable("producto", producto);
        savedInstanceState.putSerializable("lugar", lugar);
        savedInstanceState.putSerializable("usuario", usuario);
        savedInstanceState.putString("key", key);

        super.onSaveInstanceState(savedInstanceState);
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);

        producto = (Producto) savedInstanceState.getSerializable("producto");
        lugar = (Lugar) savedInstanceState.getSerializable("lugar");
        usuario = (Usuario) savedInstanceState.getSerializable("usuario");
        key = savedInstanceState.getString("key");
    }
}
