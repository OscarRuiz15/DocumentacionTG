package com.guideme.application.android.utils;

import android.content.Context;
import android.support.design.widget.Snackbar;
import android.util.Log;

import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.guideme.application.android.R;
import com.guideme.application.android.modelo.Evento;
import com.guideme.application.android.modelo.Lugar;
import com.guideme.application.android.modelo.Suscripcion;
import com.guideme.application.android.modelo.Tag;
import com.guideme.application.android.modelo.Usuario;
import com.pusher.pushnotifications.PushNotifications;

import org.json.JSONException;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Consultas {

    public Consultas() {
    }

    public ArrayList<Lugar> consultaLugaresPorNombre(ArrayList<Lugar> lugares, String query) {
        ArrayList<Lugar> lugaresFiltrados = new ArrayList<>();
        String q = query.toLowerCase();
        for (Lugar lugar : lugares) {
            String nombre = lugar.getNombre().toLowerCase();
            if (nombre.contains(q)) {
                lugaresFiltrados.add(lugar);
            }
        }

        return lugaresFiltrados;
    }

    public ArrayList<Evento> consultaEventosPorNombre(ArrayList<Evento> eventos, String query) {
        ArrayList<Evento> eventosFiltrados = new ArrayList<>();
        String q = query.toLowerCase();
        for (Evento evento : eventos) {
            String nombre = evento.getNombre().toLowerCase();
            if (nombre.contains(q)) {
                eventosFiltrados.add(evento);
            }
        }

        return eventosFiltrados;
    }

    public ArrayList<Tag> preferenciasDeUsuario(ArrayList<Tag> tagsLugar, ArrayList<Tag> tagsPreferencias){
        ArrayList <Tag> tags = tagsPreferencias;
        for (Tag tag : tagsLugar){
            if(isPreferencia(tag, tagsPreferencias)){
                tags.add(tag);
            }
        }
        return tags;
    }

    private boolean isPreferencia(Tag tagLugar, ArrayList<Tag> tagsPreferencias) {
        for (Tag tag : tagsPreferencias){
            if(tag.getId() == tagLugar.getId()){
                return true;
            }
        }
        return false;
    }

    public void crearOpinion(Lugar lugar, Usuario usuario, boolean like, double valor, Context context, final String key){
            try {
                RequestQueue requestQueue = Volley.newRequestQueue(context);

                JSONObject jsonBody = new JSONObject();

                jsonBody.put("usuario", usuario.getId());
                jsonBody.put("lugar", lugar.getId());
                jsonBody.put("like", like);
                jsonBody.put("valor", valor);

                final String mRequestBody = jsonBody.toString();

                StringRequest stringRequest = new StringRequest(Request.Method.POST,
                        Constants.URL + Constants.URL_OPINIONES_API, new Response.Listener<String>() {

                    @Override
                    public void onResponse(String response) {
                        Log.i("Response--->", response);
                    }
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("Error--->", error.toString());
                    }
                }) {
                    @Override
                    public Map<String, String> getHeaders() {
                        Map<String, String> params = new HashMap<>();
                        params.put("Content-Type", "application/json; charset=UTF-8");
                        params.put("Authorization", key);
                        return params;
                    }

                    @Override
                    public String getBodyContentType() {
                        return "application/json; charset=utf-8";
                    }

                    @Override
                    public byte[] getBody() {
                        return mRequestBody == null ? null : mRequestBody.getBytes(StandardCharsets.UTF_8);
                    }

                    @Override
                    protected Response<String> parseNetworkResponse(NetworkResponse response) {
                        String responseString = "";
                        if (response != null) {
                            responseString = String.valueOf(response.statusCode);
                        }
                        return Response.success(responseString, HttpHeaderParser.parseCacheHeaders(response));
                    }
                };

                requestQueue.add(stringRequest);

            } catch (JSONException e) {
                //e.printStackTrace();
            }
        }
}
