package com.guideme.application.android.modelo;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.Serializable;

public class Suscripcion implements Serializable {

    private int id;
    private int lugar;
    private String fecha_suscripcion;
    private String hora_suscripcion;
    private boolean notificaciones;
    private Usuario usuario;

    public Suscripcion() {
    }

    public Suscripcion(Usuario usuario, int lugar, String fecha_suscripcion, String hora_suscripcion, boolean notificaciones) {
        this.usuario = usuario;
        this.lugar = lugar;
        this.fecha_suscripcion = fecha_suscripcion;
        this.hora_suscripcion = hora_suscripcion;
        this.notificaciones = notificaciones;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario user) {
        this.usuario = user;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getLugar() {
        return lugar;
    }

    public void setLugar(int lugar) {
        this.lugar = lugar;
    }

    public String getFecha_suscripcion() {
        return fecha_suscripcion;
    }

    public void setFecha_suscripcion(String fecha_suscripcion) {
        this.fecha_suscripcion = fecha_suscripcion;
    }

    public String getHora_suscripcion() {
        return hora_suscripcion;
    }

    public void setHora_suscripcion(String hora_suscripcion) {
        this.hora_suscripcion = hora_suscripcion;
    }

    public boolean isNotificaciones() {
        return notificaciones;
    }

    public void setNotificaciones(boolean notificaciones) {
        this.notificaciones = notificaciones;
    }

    public Suscripcion(JSONObject jsonObject) throws JSONException {
        this.id = jsonObject.getInt("id");
        this.usuario = new Usuario(jsonObject.getJSONObject("usuario"), 0);
        this.lugar = jsonObject.getInt("lugar");
        this.fecha_suscripcion = jsonObject.getString("fecha_suscripcion");
        this.hora_suscripcion = jsonObject.getString("hora_suscripcion");
        this.notificaciones = jsonObject.getBoolean("notificaciones");
    }

    public JSONObject getJSONSuscripcion() throws JSONException {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("id", id);
        jsonObject.put("usuario", usuario.getJSONUsuario());
        jsonObject.put("lugar", lugar);
        jsonObject.put("fecha_suscripcion", fecha_suscripcion);
        jsonObject.put("hora_suscripcion", hora_suscripcion);
        jsonObject.put("notificaciones", notificaciones);

        return jsonObject;
    }

}
