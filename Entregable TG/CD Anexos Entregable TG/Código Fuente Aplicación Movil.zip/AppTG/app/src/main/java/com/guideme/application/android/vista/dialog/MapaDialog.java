package com.guideme.application.android.vista.dialog;

import android.Manifest;
import android.app.Dialog;
import android.content.Context;
import android.content.pm.PackageManager;
import android.support.v4.app.ActivityCompat;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.MapsInitializer;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.guideme.application.android.R;

public class MapaDialog {

    private Dialog dialog;
    private GoogleMap mMap;
    private TextView textoLatitud;
    private TextView textoLongitud;
    private double longitud = 0.0;
    private double latitud = 0.0;
    private int cont = 0;
    private ImageView btnRetroceder;
    private ImageView btnConfirmar;

    private Context context;

    public MapaDialog(Context context, TextView textoLatitud, TextView textoLongitud) {
        this.context = context;
        this.textoLatitud = textoLatitud;
        this.textoLongitud = textoLongitud;

        crearDialogo();
    }

    public void crearDialogo() {
        dialog = new Dialog(context);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialogo_mapa);
        dialog.show();
        Window w = dialog.getWindow();
        w.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);

        btnRetroceder = dialog.findViewById(R.id.btnRetroceder);
        btnRetroceder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                retroceder();
            }
        });

        btnConfirmar = dialog.findViewById(R.id.btnConfirmar);
        btnConfirmar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                confirmar();
            }
        });

        iniciarMapa();
    }

    public void iniciarMapa() {
        MapView mMapView = dialog.findViewById(R.id.mapView);
        mMapView.onCreate(dialog.onSaveInstanceState());
        mMapView.onResume();

        MapsInitializer.initialize(context);

        mMapView.getMapAsync(new OnMapReadyCallback() {
            @Override
            public void onMapReady(final GoogleMap googleMap) {
                mMap = googleMap;

                googleMap.setOnMapClickListener(new GoogleMap.OnMapClickListener() {
                    @Override
                    public void onMapClick(LatLng point) {
                        if (cont < 1) {
                            latitud = point.latitude;
                            longitud = point.longitude;
                            anadirMarca(point.latitude, point.longitude);
                            cont++;
                            btnConfirmar.setVisibility(View.VISIBLE);
                            btnRetroceder.setVisibility(View.VISIBLE);
                        }
                    }
                });

                LatLng posisiabsen = new LatLng(3.7244444444444, -76.267222222222); ////your lat lng
                googleMap.moveCamera(CameraUpdateFactory.newLatLng(posisiabsen));

                if (ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    return;
                }

                googleMap.setMyLocationEnabled(true);

                googleMap.getUiSettings().setZoomControlsEnabled(true);
                googleMap.getUiSettings().setZoomGesturesEnabled(true);
                googleMap.getUiSettings().setScrollGesturesEnabled(true);
                googleMap.getUiSettings().setRotateGesturesEnabled(true);

                googleMap.animateCamera(CameraUpdateFactory.zoomTo(15), 2000, null);
            }
        });
    }

    public void anadirMarca(double lat, double lon) {
        LatLng punto = new LatLng(lat, lon);
        mMap.addMarker(new MarkerOptions()
                .position(punto));
    }

    public void retroceder() {
        mMap.clear();
        btnConfirmar.setVisibility(View.GONE);
        btnRetroceder.setVisibility(View.GONE);
        cont--;

    }

    public void confirmar() {
        textoLatitud.setText("" + latitud);
        textoLongitud.setText("" + longitud);
        dialog.dismiss();
    }
}
