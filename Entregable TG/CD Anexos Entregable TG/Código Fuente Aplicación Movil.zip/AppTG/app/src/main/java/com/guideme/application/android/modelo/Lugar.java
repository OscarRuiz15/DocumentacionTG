package com.guideme.application.android.modelo;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.Serializable;
import java.util.ArrayList;

public class Lugar implements Serializable {

    private int id;
    private String nombre;
    private String descripcion;
    private ArrayList<String> foto;
    private float rating;
    private ArrayList<Tag> tags;
    private ArrayList<String> email;
    private ArrayList<String> sitio_web;
    private ArrayList<String> telefono;
    private ArrayList<String> redes;
    private ArrayList<Comentario> comentarios;
    private String direccion;
    private ArrayList<String> horarioabierto;
    private ArrayList<String> horariocerrado;
    private ArrayList<String> dias_servicio;
    private Double latitud;
    private Double longitud;
    private int categoria;
    private int id_propietario;
    private String fecha_creacion;
    private boolean abierto;
    private String departamento;
    private String municipio;

    public Lugar(int id, String nombre, String descripcion, ArrayList<String> foto, float rating, ArrayList<Tag> tags, ArrayList<String> email, ArrayList<String> sitio_web, ArrayList<String> telefono, ArrayList<String> redes, ArrayList<Comentario> comentarios, String direccion, ArrayList<String> horarioabierto, ArrayList<String> horariocerrado, ArrayList<String> dias_servicio, Double latitud, Double longitud, String municipio, int categoria, int propietario, String fecha_creacion, boolean abierto, String departamento) {
        this.id = id;
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.foto = foto;
        this.rating = rating;
        this.tags = tags;
        this.email = email;
        this.sitio_web = sitio_web;
        this.telefono = telefono;
        this.redes = redes;
        this.comentarios = comentarios;
        this.direccion = direccion;
        this.horarioabierto = horarioabierto;
        this.horariocerrado = horariocerrado;
        this.dias_servicio = dias_servicio;
        this.latitud = latitud;
        this.longitud = longitud;
        this.municipio = municipio;
        this.categoria = categoria;
        this.id_propietario = propietario;
        this.fecha_creacion = fecha_creacion;
        this.abierto = abierto;
        this.departamento = departamento;
    }

    public Lugar() {
    }

    public Lugar(JSONObject jsonObject) throws JSONException {
        this.id = jsonObject.getInt("id");
        this.nombre = jsonObject.getString("nombre");
        this.descripcion = jsonObject.getString("descripcion");
        this.foto = stringJSONArray(jsonObject.getJSONArray("foto"));
        this.rating = (float) jsonObject.getDouble("calificacion");
        this.tags = tagsJSONArray(jsonObject.getJSONArray("tag"));
        this.email = stringJSONArray(jsonObject.getJSONArray("email"));
        this.sitio_web = stringJSONArray(jsonObject.getJSONArray("sitio_web"));
        this.telefono = stringJSONArray(jsonObject.getJSONArray("telefono"));
        this.redes = stringJSONArray(jsonObject.getJSONArray("redes"));
        this.comentarios = comentariosJSONArray(jsonObject.getJSONArray("comentario"));
        this.direccion = jsonObject.getString("direccion");
        this.horarioabierto = stringJSONArray(jsonObject.getJSONArray("hora_abierto"));
        this.horariocerrado = stringJSONArray(jsonObject.getJSONArray("hora_cerrado"));
        this.dias_servicio = stringJSONArray(jsonObject.getJSONArray("dias_servicio"));
        this.latitud = jsonObject.getDouble("latitud");
        this.longitud = jsonObject.getDouble("longitud");
        this.categoria = jsonObject.getInt("categoria");
        this.id_propietario = jsonObject.getInt("propietario");
        this.fecha_creacion = jsonObject.getString("fecha_creacion");
        //this.abierto = jsonObject.getBoolean("abierto");
        this.departamento = jsonObject.getString("departamento");
        this.municipio = jsonObject.getString("municipio");
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }


    public String getNombre() {
        return nombre;
    }

    public void setNombre(String username) {
        this.nombre = username;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public float getRating() {
        return rating;
    }

    public void setRating(float rating) {
        this.rating = rating;
    }

    public ArrayList<Comentario> getComentarios() {
        return comentarios;
    }

    public void setComentarios(ArrayList<Comentario> comentarios) {
        this.comentarios = comentarios;
    }

    public ArrayList<String> getHorarioabierto() {
        return horarioabierto;
    }

    public void setHorarioabierto(ArrayList<String> horarioabierto) {
        this.horarioabierto = horarioabierto;
    }

    public ArrayList<String> getHorariocerrado() {
        return horariocerrado;
    }

    public void setHorariocerrado(ArrayList<String> horariocerrado) {
        this.horariocerrado = horariocerrado;
    }

    public boolean isAbierto() {
        return abierto;
    }

    public void setAbierto(boolean abierto) {
        this.abierto = abierto;
    }

    public ArrayList<String> getDias_servicio() {
        return dias_servicio;
    }

    public void setDias_servicio(ArrayList<String> dias_servicio) {
        this.dias_servicio = dias_servicio;
    }

    public ArrayList<String> getRedes() {
        return redes;
    }

    public void setRedes(ArrayList<String> redes) {
        this.redes = redes;
    }

    public ArrayList<String> getFoto() {
        return foto;
    }

    public void setFoto(ArrayList<String> foto) {
        this.foto = foto;
    }

    public ArrayList<Tag> getTags() {
        return tags;
    }

    public void setTags(ArrayList<Tag> tags) {
        this.tags = tags;
    }

    public ArrayList<String> getEmail() {
        return email;
    }

    public void setEmail(ArrayList<String> email) {
        this.email = email;
    }

    public ArrayList<String> getSitio_web() {
        return sitio_web;
    }

    public void setSitio_web(ArrayList<String> sitio_web) {
        this.sitio_web = sitio_web;
    }

    public ArrayList<String> getTelefono() {
        return telefono;
    }

    public void setTelefono(ArrayList<String> telefono) {
        this.telefono = telefono;
    }

    public Double getLatitud() {
        return latitud;
    }

    public void setLatitud(Double latitud) {
        this.latitud = latitud;
    }

    public Double getLongitud() {
        return longitud;
    }

    public void setLongitud(Double longitud) {
        this.longitud = longitud;
    }

    public int getCategoria() {
        return categoria;
    }

    public void setCategoria(int categoria) {
        this.categoria = categoria;
    }

    public int getId_propietario() {
        return id_propietario;
    }

    public void setId_propietario(int id_propietario) {
        this.id_propietario = id_propietario;
    }

    public String getFecha_creacion() {
        return fecha_creacion;
    }

    public void setFecha_creacion(String fecha_creacion) {
        this.fecha_creacion = fecha_creacion;
    }

    public String getDepartamento() {
        return departamento;
    }

    public void setDepartamento(String departamento) {
        this.departamento = departamento;
    }

    public String getMunicipio() {
        return municipio;
    }

    public void setMunicipio(String municipio) {
        this.municipio = municipio;
    }

    private ArrayList<Comentario> comentariosJSONArray(JSONArray jsonArray) {
        ArrayList<Comentario> comentarios = new ArrayList<>();
        for (int i = 0; i < jsonArray.length(); i++) {
            try {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                comentarios.add(new Comentario(jsonObject));
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        return comentarios;
    }

    private ArrayList<String> stringJSONArray(JSONArray jsonArray) {
        ArrayList<String> lista = new ArrayList<>();
        for (int i = 0; i < jsonArray.length(); i++) {
            try {
                String str = jsonArray.getString(i);
                lista.add(str);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        return lista;
    }

    private ArrayList<Tag> tagsJSONArray(JSONArray jsonArray) {
        ArrayList<Tag> tags = new ArrayList<>();
        for (int i = 0; i < jsonArray.length(); i++) {
            try {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                tags.add(new Tag(jsonObject));
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        return tags;
    }


    private ArrayList<Producto> prodcutosJSONArray(JSONArray jsonArray) {
        ArrayList<Producto> productos = new ArrayList<>();
        for (int i = 0; i < jsonArray.length(); i++) {
            try {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                productos.add(new Producto(jsonObject));
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        return productos;
    }

    private JSONArray stringListToJSONArray(ArrayList<String> lista) {
        JSONArray jsonArray = new JSONArray();
        for (String str : lista) {
            jsonArray.put(str);
        }
        return jsonArray;
    }

    private JSONArray productoListToJSONArray(ArrayList<Producto> lista) throws JSONException {
        JSONArray jsonArray = new JSONArray();
        for (Producto producto : lista) {
            JSONObject jsonObject = producto.getJSONProducto();
            jsonArray.put(jsonObject);
        }
        return jsonArray;
    }

    private JSONArray tagListToJSONArray(ArrayList<Tag> tags) throws JSONException {
        JSONArray jsonArray = new JSONArray();
        for (Tag tag : tags) {
            JSONObject jsonObject = tag.getJSONProducto();
            jsonArray.put(jsonObject);
        }
        return jsonArray;
    }

    public JSONArray comentariosListToJSONArray(ArrayList<Comentario> comentarios) throws JSONException {
        JSONArray jsonArray = new JSONArray();
        for (Comentario comentario : comentarios) {
            JSONObject jsonObject = comentario.getJSONComentario();
            jsonArray.put(jsonObject);
        }
        return jsonArray;
    }

    public JSONObject getJSONLugar() throws JSONException {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("id", id);
        jsonObject.put("nombre", nombre);
        jsonObject.put("descripcion", descripcion);
        jsonObject.put("foto", stringListToJSONArray(foto));
        jsonObject.put("calificacion", rating);
        jsonObject.put("tag", tagListToJSONArray(tags));
        jsonObject.put("email", stringListToJSONArray(email));
        jsonObject.put("sitio_web", stringListToJSONArray(sitio_web));
        jsonObject.put("telefono", stringListToJSONArray(telefono));
        jsonObject.put("redes", stringListToJSONArray(redes));
        jsonObject.put("comentario", comentariosListToJSONArray(comentarios));
        jsonObject.put("direccion", direccion);
        jsonObject.put("hora_abierto", stringListToJSONArray(horarioabierto));
        jsonObject.put("hora_cerrado", stringListToJSONArray(horariocerrado));
        jsonObject.put("dias_servicio", stringListToJSONArray(dias_servicio));
        jsonObject.put("latitud", latitud);
        jsonObject.put("longitud", longitud);
        jsonObject.put("municipio", municipio);
        jsonObject.put("categoria", categoria);
        jsonObject.put("propietario", id_propietario);
        jsonObject.put("fecha_creacion", fecha_creacion);
        jsonObject.put("departamento", departamento);
        jsonObject.put("municipio", municipio);

        //private boolean abierto;

        //System.out.println(jsonObject.toString());
        return jsonObject;
    }


}
