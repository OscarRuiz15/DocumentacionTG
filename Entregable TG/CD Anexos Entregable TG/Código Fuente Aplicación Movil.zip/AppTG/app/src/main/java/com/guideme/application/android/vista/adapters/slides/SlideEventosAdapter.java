package com.guideme.application.android.vista.adapters.slides;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.view.PagerAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.TextView;

import com.guideme.application.android.utils.ControladorFechas;
import com.guideme.application.android.R;
import com.guideme.application.android.modelo.Evento;
import com.guideme.application.android.modelo.Lugar;
import com.guideme.application.android.modelo.Usuario;
import com.guideme.application.android.vista.activities.DetallesEventoActivity;
import com.guideme.application.android.vista.fragments.GlideApp;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;
import java.util.Objects;

public class SlideEventosAdapter extends PagerAdapter {
    private Context context;
    private ArrayList<Evento> eventos;
    private Usuario usuario;
    private Lugar lugar;
    private int camino;
    private String key;


    public SlideEventosAdapter(Context context, ArrayList<Evento> eventos, Usuario usuario, int camino, String key) {
        this.context = context;
        this.eventos = eventos;
        this.usuario = usuario;
        this.camino = camino;
        this.key = key;
    }

    public SlideEventosAdapter(Context context, ArrayList<Evento> eventos, Usuario usuario, Lugar lugar, int camino, String key) {
        this.context = context;
        this.eventos = eventos;
        this.usuario = usuario;
        this.lugar = lugar;
        this.camino = camino;
        this.key = key;
    }

    @Override
    public int getCount() {
        return eventos.size();
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        return view == object;
    }

    @NonNull
    @Override
    public Object instantiateItem(@NonNull ViewGroup container, final int position) {
        LayoutInflater layoutInflater = (LayoutInflater)
                Objects.requireNonNull(context.getSystemService(Context.LAYOUT_INFLATER_SERVICE));
        View view = layoutInflater.inflate(R.layout.slide_evento, container, false);

        FirebaseStorage firebaseStorage = FirebaseStorage.getInstance();
        StorageReference storageReference = firebaseStorage.getReferenceFromUrl(eventos.get(position).getFoto());

        ControladorFechas controladorFechas = new ControladorFechas();

        ImageView imagen = view.findViewById(R.id.imageCardEvento);
        TextView txtnombre = view.findViewById(R.id.eventnameCardDetail);
        TextView txtdireccion = view.findViewById(R.id.direccionEventoDetail);
        TextView txtdescripcion = view.findViewById(R.id.detallesEventoCard);
        TextView txtmes = view.findViewById(R.id.mesEvento);
        TextView txtdia = view.findViewById(R.id.diaEvento);
        TextView txtdiainicio = view.findViewById(R.id.diaInicioEvento);
        TextView txthorainicio = view.findViewById(R.id.horaInicioEvento);
        RatingBar rbrating = view.findViewById(R.id.ratingCardEventDetails);
        TextView txttipo = view.findViewById(R.id.lugarEventoDetail);

        GlideApp.with(context)
                .load(storageReference)
                .into(imagen);
        txtnombre.setText(eventos.get(position).getNombre());
        txtdireccion.setText(eventos.get(position).getDireccion());
        String fechas[] = controladorFechas.obtenerFecha(eventos.get(position).getFechainicio());
        /////Fechas
        ///// 0 Inicial mes ENE, FEB,....
        ///// 1 Dia de la semana Lunes, Mates...
        ///// 2 Numero del dia del Mes
        txtmes.setText(fechas[0]);
        txtdia.setText(fechas[2]);
        txtdiainicio.setText(fechas[1]);
        txthorainicio.setText(eventos.get(position).getHorainicio());

        txtdescripcion.setText(eventos.get(position).getDescripcion());

        rbrating.setRating(eventos.get(position).getRating());

        txttipo.setText(eventos.get(position).getTipo());

        imagen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, DetallesEventoActivity.class);
                Bundle bundle = new Bundle();
                bundle.putSerializable("evento", eventos.get(position));
                bundle.putSerializable("usuario", usuario);
                bundle.putSerializable("lugar", lugar);
                bundle.putInt("camino", camino);
                bundle.putString("key", key);
                intent.putExtras(bundle);
                context.startActivity(intent);
            }
        });

        container.addView(view);

        return view;
    }

    @Override
    public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
        container.removeView((LinearLayout) object);
    }


}
