package com.guideme.application.android.modelo;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.Serializable;
import java.util.ArrayList;

public class Usuario implements Serializable {


    private int id;
    private String uid;
    private String nombre;
    private String email;
    private String telefono;
    private String fecha;
    private String foto;
    private String genero;
    private String departamento;
    private String municipio;

    public Usuario() {

    }

    public Usuario(int id, String uid, String nombre, String email, String telefono, String fecha, String foto, String genero, String departamento, String municipio) {
        this.id = id;
        this.uid = uid;
        this.nombre = nombre;
        this.email = email;
        this.telefono = telefono;
        this.fecha = fecha;
        this.foto = foto;
        this.genero = genero;
        this.departamento = departamento;
        this.municipio = municipio;
    }

    public Usuario(int id, String uid, String nombre, String email, String telefono, String fecha, String foto, String departamento, String municipio, ArrayList<Lugar> lugares) {
        this.id = id;
        this.uid = uid;
        this.nombre = nombre;
        this.email = email;
        this.telefono = telefono;
        this.fecha = fecha;
        this.foto = foto;
        this.departamento = departamento;
        this.municipio = municipio;
        this.lugares = lugares;
    }

    public Usuario(JSONObject jsonObject) throws JSONException {
        this.id = jsonObject.getInt("id");
        this.uid = jsonObject.getString("uid");
        this.foto = jsonObject.getString("foto");
        this.nombre = jsonObject.getString("nombre");
        this.email = jsonObject.getString("email");
        this.telefono = jsonObject.getString("telefono");
        this.fecha = jsonObject.getString("fecha_nacimiento");
        this.departamento = jsonObject.getString("departamento");
        this.municipio = jsonObject.getString("municipio");
        this.genero = jsonObject.getString("genero");
    }

    public Usuario(int id, String uid, String nombre, String email, String telefono, String fecha, String foto) {
        this.setId(id);
        this.uid = uid;
        this.nombre = nombre;
        this.email = email;
        this.telefono = telefono;
        this.fecha = fecha;
        this.foto = foto;
    }

    public Usuario(JSONObject jsonObject, int i) throws JSONException {
        this.id = jsonObject.getInt("id");
        this.foto = jsonObject.getString("foto");
        this.nombre = jsonObject.getString("nombre");
    }

    public Usuario(int id, String uid, String nombre, String email, String telefono, String fecha, String foto, ArrayList<Lugar> lugares) {
        this.id = id;
        this.uid = uid;
        this.nombre = nombre;
        this.email = email;
        this.telefono = telefono;
        this.fecha = fecha;
        this.foto = foto;
        this.lugares = lugares;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelefono() {
        return telefono;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getFoto() {
        return foto;
    }

    public void setFoto(String foto) {
        this.foto = foto;
    }

    private ArrayList<Lugar> lugares;

    public ArrayList<Lugar> getLugares() {
        return lugares;
    }

    public void setLugares(ArrayList<Lugar> lugares) {
        this.lugares = lugares;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDepartamento() {
        return departamento;
    }

    public void setDepartamento(String departamento) {
        this.departamento = departamento;
    }

    public String getMunicipio() {
        return municipio;
    }

    public void setMunicipio(String municipio) {
        this.municipio = municipio;
    }

    @Override
    public String toString() {
        return "Usuario{" +
                "uid='" + uid + '\'' +
                ", nombre='" + nombre + '\'' +
                ", email='" + email + '\'' +
                ", telefono='" + telefono + '\'' +
                ", fecha='" + fecha + '\'' +
                ", foto='" + foto + '\'' +
                ", lugares=" + lugares +
                '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public JSONObject getJSONUsuario() throws JSONException {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("id", id);
        jsonObject.put("uid", uid);
        jsonObject.put("nombre", nombre);
        jsonObject.put("email", email);
        jsonObject.put("telefono", telefono);
        jsonObject.put("fecha_nacimiento", fecha);
        jsonObject.put("foto", foto);
        jsonObject.put("departamento", departamento);
        jsonObject.put("municipio", municipio);
        jsonObject.put("genero", genero);

        return jsonObject;
    }
}
