package com.guideme.application.android.utils;

public class Constants {

    public static final String CERO = "0";
    public static final String BAR = "/";
    public static final int RC_SIGN_IN = 777;
    public static final String FIREBASE_STORAGE_URL = "gs://trabajo-de-grado-f9cb8.appspot.com";
    public static final String FIREBASE_STORAGE_URL_LUGAR = "gs://trabajo-de-grado-f9cb8.appspot.com/lugares";
    public static final String FIREBASE_STORAGE_URL_PRODUCTOS = "gs://trabajo-de-grado-f9cb8.appspot.com/productos";
    public static final String FIREBASE_STORAGE_URL_EVENTOS = "gs://trabajo-de-grado-f9cb8.appspot.com/eventos";
    public static final String FIREBASE_STORAGE_URL_SOLICITUDES = "gs://trabajo-de-grado-f9cb8.appspot.com/solicitudes";
    public static final String DOS_PUNTOS = ":";
    public static final String URL = "https://bkndtg.herokuapp.com";
    public static final String URL_USUARIOS_API = "/usuarios/api/";
    public static final String URL_CATEGORIAS_API = "/categorias/api/";
    public static final String URL_PRODUCTOS = "/productos/Producto/";
    public static final String URL_PRODUCTOS_API = "/productos/api/";
    public static final String URL_TAGS_API = "/tags/api/";
    public static final String URL_PREFERENCIAS_API = "/preferencias/api/";
    public static final String URL_OPINIONES_API = "/opiniones/api/";
    public static final String URL__API = "/tags/api/";
    public static final String URL_COMENTARIOS_API = "/comentarios/api/";
    public static final String URL_VISITAS_API = "/visitas/api/";
    public static final String URL_SOLICITUDES_API = "/solicitudes/api/";
    public static final String URL_SUSCRIPCIONES_API = "/suscripciones/api/";
    public static final String URL_EVENTOS_API = "/eventos/api/";
    public static final String URL_LUGARES_API = "/lugares/api/";
    public static final String URL_LUGARES_VISITADOS_API = "visitas/";
    public static final String URL_CONTADOR_VISITAS_SUSCRIPCION_API = "data/";
    public static final String URL_LUGARES_POPULARES_API = "popular/";
    public static final String URL_LUGARES_REOCOMENDADOS_API = "recomendados/";
    public static final String URL_LUGARES_RECOMENDACIONES_API = "consulta-recomendaciones/";
    public static final String URL_LUGARES_NUEVOS_API = "nuevos/";
    public static final String GUION = "-";
    public static final String DEFAULT_TAB = "default_tab";
    public static final String GET_JSON = "?format=json";
    public static final String CONSULTA_LUGARES_CATEGORIA = "?categoria=";
    public static final String CONSULTA_USUARIOS = "?usuario=";
    public static final String CONSULTA_PROPIETARIO = "?propietario=";
    public static final String CONSULTA_LUGAR = "?lugar=";
    public static final String CONSULTA_CANTIDAD = "count/";
    public static final String CONSULTA_LISTA_SUSCRIPTORES = "list/suscrito/";
    public static final String CONSULTA_SUSCRITO = "suscrito/";
    public static final String CONSULTA_NOMBRE = "?nombre=";
    public static final String CONSULTA_DIA = "?dias=";
    public static final String AND_ID = "&uid=";
    public static final String AND_USUARIO = "&usuario=";
    public static final String AND_LUGAR = "&lugar=";

    public static final String BEAMS_NOTIFICATIONS_INSTANCE_ID = "150ee5d4-aa83-42f8-9c65-fe6ab983f0ca";

}
