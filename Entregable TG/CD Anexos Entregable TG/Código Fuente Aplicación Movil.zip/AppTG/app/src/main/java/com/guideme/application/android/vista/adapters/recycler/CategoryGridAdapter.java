package com.guideme.application.android.vista.adapters.recycler;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.guideme.application.android.utils.Constants;
import com.guideme.application.android.R;
import com.guideme.application.android.modelo.Categoria;
import com.guideme.application.android.modelo.Usuario;
import com.guideme.application.android.vista.activities.ConsultaLugaresActivity;

import java.util.ArrayList;

public class CategoryGridAdapter extends RecyclerView.Adapter<CategoryGridAdapter.CategoryViewHolder> {

    private Context context;
    private ArrayList<Categoria> categorias;
    private Usuario usuario;
    private String key;

    public CategoryGridAdapter(Context context, ArrayList<Categoria> categorias, Usuario usuario, String key) {
        this.context = context;
        this.categorias = categorias;
        this.usuario = usuario;
        this.key = key;
    }

    static class CategoryViewHolder extends RecyclerView.ViewHolder {
        ImageView icono;
        TextView titulo;
        TextView descripcion;
        private CardView cardView;

        CategoryViewHolder(View itemView) {
            super(itemView);
            icono = itemView.findViewById(R.id.icon_category_search);
            titulo = itemView.findViewById(R.id.title_category_search);
            //descripcion = itemView.findViewById(R.id.description_category_search);
            cardView = itemView.findViewById(R.id.cardview_category);
        }
    }

    @NonNull
    @Override
    public CategoryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.cardview_category, parent, false);
        return new CategoryViewHolder(view);
    }

    public void onBindViewHolder(@NonNull final CategoryViewHolder holder, int position) {
        position = holder.getAdapterPosition();
        //FirebaseStorage firebaseStorage = FirebaseStorage.getInstance();
        //System.out.println(categorias.get(position).getFoto());

        //StorageReference storageReference = firebaseStorage.getReferenceFromUrl(categorias.get(position).getFoto());
        switch (categorias.get(position).getId()){
            case 1:
                holder.icono.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.ic_bar));
                break;
            case 2:
                holder.icono.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.ic_breakfast));
                break;
            case 3:
                holder.icono.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.ic_entertainment));
                break;
            case 4:
                holder.icono.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.ic_food));
                break;
            case 5:
                holder.icono.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.ic_pizza));
                break;
            case 6:
                holder.icono.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.ic_bed));
                break;
        }

        holder.icono.setScaleType(ImageView.ScaleType.CENTER_CROP);
        holder.icono.setMaxWidth(30);
        holder.icono.setMaxHeight(30);
        holder.titulo.setText(categorias.get(position).getNombre());
        //holder.descripcion.setText(categorias.get(position).getDescripcion());

        final int id = categorias.get(position).getId();
        final int finalPosition = position;
        holder.cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //System.out.println("CATEGORIA ELEGIDA "+id);
                Intent intent = new Intent(context, ConsultaLugaresActivity.class);
                Bundle bundle = new Bundle();

                String url = Constants.URL + Constants.URL_LUGARES_API +
                        Constants.CONSULTA_LUGARES_CATEGORIA + id;
                bundle.putString("nombre", categorias.get(finalPosition).getNombre());
                bundle.putSerializable("usuario", usuario);
                bundle.putString("url", url);
                bundle.putString("key", key);
                intent.putExtras(bundle);
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return categorias.size();
    }
}
