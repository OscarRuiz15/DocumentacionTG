package com.guideme.application.android.utils;

import android.content.Context;
import android.support.design.widget.TextInputEditText;
import android.support.design.widget.TextInputLayout;
import android.support.v7.view.ContextThemeWrapper;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.LinearLayout;

import com.guideme.application.android.R;

import java.util.ArrayList;

//Clase para crear TextInputEditText dinámicamente y obtener los textos de estos
//Es necesario el Context para crear los elementos que se agregan al layout

public class CrearTextos {

    private Context context;

    public CrearTextos(Context context) {
        this.context = context;

    }

    public TextWatcher onTextChangedListener(final EditText editText, final boolean primero,
                                             final ArrayList<TextInputEditText> listEditText,
                                             final TextInputLayout.LayoutParams layoutParams,
                                             final LinearLayout linearLayout,
                                             final String hint,
                                             final int inputType) {


        return new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {

                boolean crear = primero;
                if (!crear) {
                    String hint = editText.getContentDescription() + "";
                    //Log.d("hint", hint + "");

                    int index = Integer.parseInt(hint);
                    //Log.d("Index", index + "");
                    //Log.d("Size", listEditText.size() + "");
                    crear = index + 2 > listEditText.size();
                }

                if (s.length() > 0 && s.length() == 1 && crear) {

                    createTextInputEditText(editText,
                            listEditText,
                            layoutParams,
                            linearLayout,
                            hint,
                            inputType,
                            null);
                }

            }
        };
    }

    public void createTextInputEditText(final EditText editText,
                                        final ArrayList<TextInputEditText> listEditText,
                                        final TextInputLayout.LayoutParams layoutParams,
                                        final LinearLayout linearLayout,
                                        final String hint,
                                        final int inputType,
                                        ArrayList<String> datos) {


        if (datos == null) {
            TextInputLayout telInputLayout = new TextInputLayout(new ContextThemeWrapper(context,
                    R.style.EditTextTertiary));
            telInputLayout.setErrorEnabled(true);
            TextInputEditText textInputEditText = new TextInputEditText(context);
            telInputLayout.setLayoutParams(layoutParams);
            listEditText.add(textInputEditText);
            textInputEditText.setHint(hint + listEditText.size());
            textInputEditText.setInputType(inputType);
            //textInputEditText.setLayoutParams(layoutParams);
            textInputEditText.setContentDescription(listEditText.size() + "");
            telInputLayout.addView(textInputEditText);
            linearLayout.addView(telInputLayout);

            //textInputEditText.setLayoutParams(layoutParams);

            textInputEditText.addTextChangedListener(onTextChangedListener(textInputEditText,
                    false,
                    listEditText,
                    layoutParams,
                    linearLayout,
                    hint,
                    inputType));
            editText.removeTextChangedListener(onTextChangedListener(textInputEditText,
                    false,
                    listEditText,
                    layoutParams,
                    linearLayout,
                    hint,
                    inputType));
        } else {
            for (int i = 1; i <= datos.size(); i++) {
                TextInputLayout telInputLayout = new TextInputLayout(new ContextThemeWrapper(context,
                        R.style.EditTextTertiary));
                telInputLayout.setErrorEnabled(true);
                TextInputEditText textInputEditText = new TextInputEditText(context);
                telInputLayout.setLayoutParams(layoutParams);
                listEditText.add(textInputEditText);
                textInputEditText.setHint(hint + listEditText.size());
                textInputEditText.setInputType(inputType);
                //textInputEditText.setLayoutParams(layoutParams);
                textInputEditText.setContentDescription(listEditText.size() + "");
                telInputLayout.addView(textInputEditText);
                linearLayout.addView(telInputLayout);
                if (i == datos.size()) {
                    textInputEditText.addTextChangedListener(onTextChangedListener(textInputEditText,
                            false,
                            listEditText,
                            layoutParams,
                            linearLayout,
                            hint,
                            inputType));
                } else {
                    textInputEditText.setText(datos.get(i));
                }
            }
        }


    }

    public ArrayList<String> obtenerLista(ArrayList<TextInputEditText> etlista) {
        ArrayList<String> lista = new ArrayList<>();
        for (int i = 0; i < etlista.size(); i++) {
            if (etlista.get(i).getText().length() != 0) {
                String elemento = etlista.get(i).getText().toString().trim();
                lista.add(elemento);
            }
        }

        return lista;
    }


}
