package com.guideme.application.android.vista.fragments;


import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.guideme.application.android.utils.Constants;
import com.guideme.application.android.utils.Operaciones;
import com.guideme.application.android.R;
import com.guideme.application.android.modelo.Evento;
import com.guideme.application.android.modelo.Lugar;
import com.guideme.application.android.modelo.Usuario;
import com.guideme.application.android.vista.adapters.slides.SlideEventosAdapter;
import com.guideme.application.android.vista.adapters.slides.SlideHomeAdapter;
import com.guideme.application.android.vista.activities.ActionBar;
import com.guideme.application.android.vista.activities.ContainerActivity;
import com.guideme.application.android.vista.activities.ConsultaLugaresActivity;
import com.guideme.application.android.vista.activities.VerEventosActivity;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class HomeFragment extends Fragment {

    private SlideHomeAdapter slideHomeAdapter;
    private SlideEventosAdapter slideEventosAdapter;

    private ViewPager viewPagerEvento;
    private LinearLayout dotsLayoutEvento;

    private TextView dotsRecomendacion[];
    private TextView dotsNuevo[];
    private TextView dotsPopular[];
    private TextView dotsEvento[];

    private LinearLayout linearLayoutPopular;
    private LinearLayout linearLayoutRecomendados;
    private LinearLayout linearLayoutNuevo;
    private LinearLayout linearLayoutEventos;

    private ArrayList<Lugar> lugaresRecomendados;
    private ArrayList<Lugar> lugaresNuevos;
    private ArrayList<Lugar> lugaresPopulares;

    private ArrayList<Evento> eventos;

    private ArrayList<Evento> eventosMin;

    private Usuario usuario;

    private String key;
    private final Operaciones operaciones = new Operaciones();
    private String url_popular;
    private String url_nuevos;
    private String url_recomendados;
    private ArrayList<Lugar> lugaresPopularesMin;
    private ArrayList<Lugar> lugaresNuevosMin;
    private ViewPager viewPagerPopular;
    private ViewPager viewPagerNuevo;
    private ArrayList<Lugar> lugaresRecomendadosMin;
    private LinearLayout dotsLayoutPopular;
    private LinearLayout dotsLayoutNuevo;
    private ViewPager viewPagerHome;
    private LinearLayout dotsLayoutHome;
    private boolean isCreated = false;


    public HomeFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_home, container, false);
        ActionBar actionBar = new ActionBar();
        actionBar.showToolbar("Inicio", false, getActivity(), view);
        usuario = ((ContainerActivity) Objects.requireNonNull(getActivity())).getUsuario();
        key = ((ContainerActivity) getActivity()).getKey();
        url_recomendados = Constants.URL + Constants.URL_LUGARES_API +
                Constants.URL_LUGARES_REOCOMENDADOS_API + Constants.CONSULTA_USUARIOS + usuario.getUid();
        url_nuevos = Constants.URL + Constants.URL_LUGARES_API
                + Constants.URL_LUGARES_NUEVOS_API + Constants.CONSULTA_DIA + 15;
        url_popular = Constants.URL + Constants.URL_LUGARES_API
                + Constants.URL_LUGARES_POPULARES_API + Constants.GET_JSON;
        isCreated = true;

        linearLayoutPopular = view.findViewById(R.id.linearLayoutPopulares);
        linearLayoutRecomendados = view.findViewById(R.id.linearLayoutRecomendados);
        linearLayoutNuevo = view.findViewById(R.id.linearLayoutNuevos);
        linearLayoutEventos = view.findViewById(R.id.linearLayoutEventos);

        //Pager Populares///////////////////////////////
        viewPagerPopular = view.findViewById(R.id.slidePopularHome);
        dotsLayoutPopular = view.findViewById(R.id.dotsLayoutPopularHome);

        //Pager Recomendaciones///////////////////////////////
        viewPagerHome = view.findViewById(R.id.slideRecomendacionHome);
        dotsLayoutHome = view.findViewById(R.id.dotsLayoutHome);

        //Pager Nuevo//////////////////////////////
        viewPagerNuevo = view.findViewById(R.id.slideNuevoHome);
        dotsLayoutNuevo = view.findViewById(R.id.dotsNuevoLayoutHome);

        lugaresPopulares = new ArrayList<>();
        lugaresNuevos = new ArrayList<>();
        lugaresRecomendados = new ArrayList<>();
        eventos = new ArrayList<>();

        lugaresPopularesMin = new ArrayList<>();
        lugaresNuevosMin = new ArrayList<>();
        lugaresRecomendadosMin = new ArrayList<>();
        eventosMin = new ArrayList<>();

        TextView tvVerMasPopulares = view.findViewById(R.id.ver_mas_populares);
        TextView tvVerMasEvento = view.findViewById(R.id.ver_mas_eventos);
        TextView tvVerMasRecomendados = view.findViewById(R.id.ver_mas_recomendados);
        TextView tvVerMasNuevo = view.findViewById(R.id.ver_mas_nuevo);

        tvVerMasPopulares.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                verMasLugares(lugaresPopulares, "Lugares Populares");
            }
        });
        tvVerMasNuevo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                verMasLugares(lugaresNuevos, "Lugares Nuevos");
            }
        });
        tvVerMasRecomendados.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                verMasLugares(lugaresRecomendados, "Lugares Recomendados");
            }
        });
        tvVerMasEvento.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                verMasEventos();
            }
        });


        obtenerLugares(url_popular, lugaresPopulares, lugaresPopularesMin, viewPagerPopular,
                dotsLayoutPopular, dotsPopular, linearLayoutPopular, false);
        obtenerLugares(url_nuevos, lugaresNuevos, lugaresNuevosMin, viewPagerNuevo, dotsLayoutNuevo,
                dotsNuevo, linearLayoutNuevo, false);
        obtenerLugares(url_recomendados, lugaresRecomendados, lugaresRecomendadosMin, viewPagerHome,
                dotsLayoutHome, dotsRecomendacion, linearLayoutRecomendados, true);
        obtenerEventos();

        //Pager Evento///////////////////////////////////
        viewPagerEvento = view.findViewById(R.id.slideEventoHome);
        dotsLayoutEvento = view.findViewById(R.id.dotsEventoLayoutHome);

        //OnPageChange Listeners

        //Popular//////////////////////////
        ViewPager.OnPageChangeListener popularviewListener = listenerPager(dotsLayoutPopular, dotsPopular, lugaresPopularesMin, null);
        viewPagerPopular.addOnPageChangeListener(popularviewListener);

        //Recomendacion//////////////////////////
        ViewPager.OnPageChangeListener viewListener = listenerPager(dotsLayoutHome, dotsRecomendacion, lugaresRecomendadosMin, null);
        viewPagerHome.addOnPageChangeListener(viewListener);

        //Nuevo
        ViewPager.OnPageChangeListener nuevoviewListener = listenerPager(dotsLayoutNuevo, dotsNuevo, lugaresNuevosMin, null);
        viewPagerNuevo.addOnPageChangeListener(nuevoviewListener);

        //Evento
        ViewPager.OnPageChangeListener eventoviewListener = listenerPager(dotsLayoutEvento, dotsEvento, null, eventosMin);
        viewPagerEvento.addOnPageChangeListener(eventoviewListener);
        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        if (!isCreated) {
            obtenerLugares(url_popular, lugaresPopulares, lugaresPopularesMin, viewPagerPopular, dotsLayoutPopular, dotsPopular, linearLayoutPopular, false);
            obtenerLugares(url_nuevos, lugaresNuevos, lugaresNuevosMin, viewPagerNuevo, dotsLayoutNuevo, dotsNuevo, linearLayoutNuevo, false);
            obtenerLugares(url_recomendados, lugaresRecomendados, lugaresRecomendadosMin, viewPagerHome, dotsLayoutHome, dotsRecomendacion, linearLayoutRecomendados, true);
            obtenerEventos();
        }
    }

    private void obtenerLugares(String url, final ArrayList<Lugar> lugares,
                                final ArrayList<Lugar> lugaresMin, final ViewPager viewPager,
                                final LinearLayout dotsLayout, final TextView[] dots,
                                final LinearLayout linearLayout, final boolean esRecomendado) {

        RequestQueue requestQueue = Volley.newRequestQueue(Objects.requireNonNull(getContext()));
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, url, null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                for (int i = 0; i < response.length(); i++) {
                    try {
                        Lugar lugar = new Lugar(response.getJSONObject(i));
                        lugar.setRating(operaciones.calcularCalificacion(lugar.getComentarios()));
                        lugares.add(lugar);
                        if (i < 5) {
                            lugaresMin.add(lugar);
                        }
                        //Toast.makeText(getContext(), "Lugar " + i, Toast.LENGTH_LONG).show();
                    } catch (JSONException e) {
                        //e.printStackTrace();
                    }
                }
                if (lugares.isEmpty()) {
                    linearLayout.setVisibility(View.VISIBLE);
                    viewPager.setVisibility(View.GONE);
                    return;
                }
                slideHomeAdapter = new SlideHomeAdapter(getActivity(), lugaresMin, usuario, key, esRecomendado);
                viewPager.setAdapter(slideHomeAdapter);
                addDotsIndicator(0, dotsLayout, dots, lugaresMin.size());

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                linearLayout.setVisibility(View.VISIBLE);
                viewPager.setVisibility(View.GONE);
            }
        }) {
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> params = new HashMap<>();
                params.put("Content-Type", "application/json; charset=UTF-8");
                params.put("Authorization", key);
                return params;
            }
        };
        jsonArrayRequest.setRetryPolicy(new DefaultRetryPolicy(
                DefaultRetryPolicy.DEFAULT_TIMEOUT_MS * 3,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        requestQueue.add(jsonArrayRequest);

    }

    private void obtenerEventos() {
        String url = Constants.URL + Constants.URL_EVENTOS_API + Constants.GET_JSON;


        RequestQueue requestQueue = Volley.newRequestQueue(Objects.requireNonNull(getContext()));
        final JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, url, null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                for (int i = 0; i < response.length(); i++) {
                    try {
                        Evento evento = new Evento(response.getJSONObject(i));
                        evento.setRating(operaciones.calcularCalificacion(evento.getComentarios()));
                        eventos.add(evento);
                        if (i < 5) {
                            eventosMin.add(evento);
                        }

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
                if (eventos.isEmpty()) {
                    linearLayoutEventos.setVisibility(View.VISIBLE);
                    viewPagerEvento.setVisibility(View.GONE);
                    return;
                }
                slideEventosAdapter = new SlideEventosAdapter(getActivity(), eventos, usuario, 1, key);
                viewPagerEvento.setAdapter(slideEventosAdapter);
                addDotsIndicator(0, dotsLayoutEvento, dotsEvento, eventosMin.size());


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }) {
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> params = new HashMap<>();
                params.put("Content-Type", "application/json; charset=UTF-8");
                params.put("Authorization", key);
                return params;
            }
        };
        jsonArrayRequest.setRetryPolicy(new DefaultRetryPolicy(
                DefaultRetryPolicy.DEFAULT_TIMEOUT_MS * 3,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        requestQueue.add(jsonArrayRequest);

    }

    public void addDotsIndicator(int position, LinearLayout dotsLayout, TextView dots[], int size) {
        dotsLayout.removeAllViews();
        dots = new TextView[size];
        for (int i = 0; i < dots.length; i++) {
            dots[i] = new TextView(getActivity());
            dots[i].setText(Html.fromHtml("&#8226;"));
            dots[i].setTextSize(35);
            dots[i].setTextColor(getResources().getColor(R.color.transparentwhite));

            dotsLayout.addView(dots[i]);
        }
        if (dots.length > 0) {
            dots[position].setTextColor(getResources().getColor(R.color.white));
        }
    }

    public ViewPager.OnPageChangeListener listenerPager(final LinearLayout dotsLayout, final TextView[] dots, final ArrayList<Lugar> lugares, final ArrayList<Evento> eventos) {
        return new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                //El ultimo parametro es el tamaño de los lugares de cada recycler
                //La variable cantidad siempre es 0
                if (lugares != null) {
                    addDotsIndicator(position, dotsLayout, dots, lugares.size());
                } else {
                    addDotsIndicator(position, dotsLayout, dots, eventos.size());
                }

            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        };
    }


    public void verMasEventos() {
        Intent intent = new Intent(getContext(), VerEventosActivity.class);
        Bundle bundle = new Bundle();
        bundle.putSerializable("eventos", eventos);
        bundle.putSerializable("usuario", usuario);
        bundle.putString("key", key);
        intent.putExtras(bundle);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
    }

    private void verMasLugares(ArrayList<Lugar> tipo, String nombre) {
        Intent intent = new Intent(getContext(), ConsultaLugaresActivity.class);
        Bundle bundle = new Bundle();
        bundle.putSerializable("usuario", usuario);
        bundle.putSerializable("lugares", tipo);
        bundle.putString("nombre", nombre);
        bundle.putString("key", key);
        intent.putExtras(bundle);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
    }


}
