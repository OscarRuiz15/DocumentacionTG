package com.guideme.application.android.vista.activities;

import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v4.app.NavUtils;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.TimePicker;

import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.guideme.application.android.R;
import com.guideme.application.android.modelo.Solicitud;
import com.guideme.application.android.modelo.Usuario;
import com.guideme.application.android.utils.Alerts;
import com.guideme.application.android.utils.Constants;
import com.guideme.application.android.utils.ValidarTextos;
import com.guideme.application.android.vista.dialog.ImageDialog;
import com.guideme.application.android.vista.dialog.MapaDialog;
import com.guideme.application.android.vista.fragments.GlideApp;

import org.json.JSONException;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

public class NuevaSolicitudActivity extends AppCompatActivity implements View.OnClickListener {

    private EditText txtnombre;
    private EditText txtdescripcion;
    private EditText txttelefono;
    private EditText txtemail;
    private EditText txtdireccion;
    private Button btnEnviarSolicitud;
    private AlertDialog alertDialog;
    private TextView textoLatitud;
    private TextView textoLongitud;
    private Button btnUbicar;
    private ImageView imagenSitio;
    private ImageView imagen;
    private RelativeLayout relativeCoordenadas;

    private LinearLayout layoutHorarios;
    //Relatives
    private RelativeLayout horarioLunes;
    private RelativeLayout horarioMartes;
    private RelativeLayout horarioMiercoles;
    private RelativeLayout horarioJueves;
    private RelativeLayout horarioViernes;
    private RelativeLayout horarioSabado;
    private RelativeLayout horarioDomingo;

    //Dias
    private CheckBox cbLunes;
    private CheckBox cbMartes;
    private CheckBox cbMiercoles;
    private CheckBox cbJueves;
    private CheckBox cbViernes;
    private CheckBox cbSabado;
    private CheckBox cbDomingo;

    //Atencion abierto
    private TextView tvAbreLunes;
    private TextView tvAbreMartes;
    private TextView tvAbreMiercoles;
    private TextView tvAbreJueves;
    private TextView tvAbreViernes;
    private TextView tvAbreSabado;
    private TextView tvAbreDomingo;

    //Atencion cerrado
    private TextView tvCierraLunes;
    private TextView tvCierraMartes;
    private TextView tvCierraMiercoles;
    private TextView tvCierraJueves;
    private TextView tvCierraViernes;
    private TextView tvCierraSabado;
    private TextView tvCierraDomingo;
    private Usuario usuario;
    private String key;
    private AlertDialog errorAlertDialog;

    private ActionBar actionBar;

    private Context context = this;
    private Solicitud solicitud;

    public final Calendar c = Calendar.getInstance();
    final int hora = c.get(Calendar.HOUR_OF_DAY);
    final int minuto = c.get(Calendar.MINUTE);

    private static final String CERO = "0";
    private static final String DOS_PUNTOS = ":";

    private ArrayList<String> hora_abierto;
    private ArrayList<String> hora_cerrado;
    private ArrayList<String> dias_servicio;
    private String foto;
    private Double latitud;
    private Double longitud;

    //Foto
    private static int FOTO_DE_GALERIA = 10;
    private Uri getAbsolutePhotoPath;
    private StorageReference storageReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nueva_solicitud);

        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();

        int id;
        if (savedInstanceState != null) {
            usuario = (Usuario) savedInstanceState.getSerializable("usuario");
            key = savedInstanceState.getString("key");
            id = savedInstanceState.getInt("id");
            solicitud = (Solicitud) savedInstanceState.getSerializable("solicitud");
        } else {
            usuario = (Usuario) (bundle != null ? bundle.getSerializable("usuario") : null);
            key = bundle != null ? bundle.getString("key") : null;
            id = bundle != null ? bundle.getInt("id") : null;
            solicitud = (Solicitud) (bundle != null ? bundle.getSerializable("solicitud") : null);
        }

        //txtnit = findViewById(R.id.editTextNIT);
        txtnombre = findViewById(R.id.editTextNombre);
        txtdescripcion = findViewById(R.id.editTextDescripcion);
        txtdireccion = findViewById(R.id.editTextDireccion);
        txtemail = findViewById(R.id.editTextEmail);
        txttelefono = findViewById(R.id.editTextTelefono);
        textoLatitud = findViewById(R.id.textoLatitud);
        textoLongitud = findViewById(R.id.textoLongitud);
        btnEnviarSolicitud = findViewById(R.id.btnEnviarSolicitud);
        btnUbicar = findViewById(R.id.btnUbicar);

        relativeCoordenadas = findViewById(R.id.relativeCoordenadas);
        imagenSitio = findViewById(R.id.imagenSitio);
        imagen = findViewById(R.id.imagenLugar);

        ///////////////////////Inicializar Servicio//////////////////////////
        layoutHorarios = findViewById(R.id.layoutHorarios);

        horarioLunes = findViewById(R.id.horarioLunes);
        horarioMartes = findViewById(R.id.horarioMartes);
        horarioMiercoles = findViewById(R.id.horarioMiercoles);
        horarioJueves = findViewById(R.id.horarioJueves);
        horarioViernes = findViewById(R.id.horarioViernes);
        horarioSabado = findViewById(R.id.horarioSabado);
        horarioDomingo = findViewById(R.id.horarioDomingo);

        cbLunes = findViewById(R.id.checkboxLUN);
        cbMartes = findViewById(R.id.checkboxMAR);
        cbMiercoles = findViewById(R.id.checkboxMIE);
        cbJueves = findViewById(R.id.checkboxJUE);
        cbViernes = findViewById(R.id.checkboxVIE);
        cbSabado = findViewById(R.id.checkboxSAB);
        cbDomingo = findViewById(R.id.checkboxDOM);

        tvAbreLunes = findViewById(R.id.editTextHoraAbrirLUN);
        tvAbreMartes = findViewById(R.id.editTextHoraAbrirMAR);
        tvAbreMiercoles = findViewById(R.id.editTextHoraAbrirMIE);
        tvAbreJueves = findViewById(R.id.editTextHoraAbrirJUE);
        tvAbreViernes = findViewById(R.id.editTextHoraAbrirVIE);
        tvAbreSabado = findViewById(R.id.editTextHoraAbrirSAB);
        tvAbreDomingo = findViewById(R.id.editTextHoraAbrirDOM);

        tvCierraLunes = findViewById(R.id.editTextHoraCerrarLUN);
        tvCierraMartes = findViewById(R.id.editTextHoraCerrarMAR);
        tvCierraMiercoles = findViewById(R.id.editTextHoraCerrarMIE);
        tvCierraJueves = findViewById(R.id.editTextHoraCerrarJUE);
        tvCierraViernes = findViewById(R.id.editTextHoraCerrarVIE);
        tvCierraSabado = findViewById(R.id.editTextHoraCerrarSAB);
        tvCierraDomingo = findViewById(R.id.editTextHoraCerrarDOM);

        tvAbreLunes.setOnClickListener(this);
        tvAbreMartes.setOnClickListener(this);
        tvAbreMiercoles.setOnClickListener(this);
        tvAbreJueves.setOnClickListener(this);
        tvAbreViernes.setOnClickListener(this);
        tvAbreSabado.setOnClickListener(this);
        tvAbreDomingo.setOnClickListener(this);

        tvCierraLunes.setOnClickListener(this);
        tvCierraMartes.setOnClickListener(this);
        tvCierraMiercoles.setOnClickListener(this);
        tvCierraJueves.setOnClickListener(this);
        tvCierraViernes.setOnClickListener(this);
        tvCierraSabado.setOnClickListener(this);
        tvCierraDomingo.setOnClickListener(this);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Solicitud Enviada");
        builder.setMessage("La solicitud ha sido enviada con éxito");
        builder.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        });
        alertDialog = builder.create();

        actionBar = new ActionBar();
        actionBar.showToolbar("Nueva Solicitud", true, this);

        FirebaseStorage storage = FirebaseStorage.getInstance();
        storageReference = storage.getReferenceFromUrl(Constants.FIREBASE_STORAGE_URL_SOLICITUDES);

        if (id != 0) {
            ponerElementos();
        }
        btnEnviarSolicitud.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                enviarSolicitud();
            }
        });
    }

    @Override
    protected void onSaveInstanceState(Bundle savedInstanceState) {
        savedInstanceState.putSerializable("usuario", usuario);
        savedInstanceState.putString("key", key);

        super.onSaveInstanceState(savedInstanceState);
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);

        usuario = (Usuario) savedInstanceState.getSerializable("usuario");
        key = savedInstanceState.getString("key");
    }

    public void enviarSolicitud() {
        try {
            postVolleySolicitud();
        } catch (JSONException e) {
            //e.printStackTrace();
        }
    }

    private void postVolleySolicitud() throws JSONException {
        final Alerts alerts = new Alerts(this);

        if (alerts.isConnected()) {

            ValidarTextos validarTextos = new ValidarTextos();
            boolean nombrevalido = validarTextos.validateBlank(txtnombre, this);
            boolean descripcionvalido = validarTextos.validateBlank(txtdescripcion, this);
            boolean direccionvalido = validarTextos.validateBlank(txtdireccion, this);
            boolean emailvalido = validarTextos.validateEmail(txtemail, this);
            //boolean nitvalido = validarTextos.validateBlank(txtnit, this);
            boolean telefonovalido = validarTextos.validatePhone(txttelefono, this);

            if (nombrevalido && descripcionvalido && direccionvalido && emailvalido && /*nitvalido &&*/ telefonovalido) {
                RequestQueue requestQueue = Volley.newRequestQueue(this);
                String nombre = txtnombre.getText().toString().trim();
                String descripcion = txtdescripcion.getText().toString().trim();
                String direccion = txtdireccion.getText().toString().trim();
                String telefono = txttelefono.getText().toString().trim();
                String email = txtemail.getText().toString().trim();
                String urlfoto;

                ArrayList<String> listaEmail = new ArrayList<>();
                listaEmail.add(email);

                if (getAbsolutePhotoPath != null) {
                    urlfoto = uploadPhoto(getAbsolutePhotoPath.getLastPathSegment());
                } else {
                    urlfoto = "gs://trabajo-de-grado-f9cb8.appspot.com/solicitudes/web_hi_res_512.png";
                }

                hora_abierto = new ArrayList<>();
                hora_cerrado = new ArrayList<>();
                dias_servicio = new ArrayList<>();

                obtenerDiasDeAtencion();

                latitud = Double.parseDouble(textoLatitud.getText().toString().trim());
                longitud = Double.parseDouble(textoLongitud.getText().toString().trim());

                Solicitud solicitud = new Solicitud(0, usuario, nombre, direccion, telefono, listaEmail,
                        descripcion, false, hora_abierto, hora_cerrado, dias_servicio, urlfoto, latitud, longitud);

                JSONObject jsonBody = solicitud.getJsonObject();

                System.out.println(jsonBody.toString());

                final String mRequestBody = jsonBody.toString();
                btnEnviarSolicitud.setEnabled(false);
                btnEnviarSolicitud.setBackgroundResource(R.color.darker_gray);

                StringRequest stringRequest = new StringRequest(Request.Method.POST, Constants.URL + Constants.URL_SOLICITUDES_API, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        alertDialog.show();
                        btnEnviarSolicitud.setEnabled(true);
                        btnEnviarSolicitud.setBackgroundResource(R.color.colorPrimaryDark);
                    }
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {
                        int statusCode = error.networkResponse.statusCode;
                        String mensaje = "No se pudo enviar la solicitud";
                        errorAlertDialog = alerts.createErrorAlert(statusCode, mensaje).create();
                        errorAlertDialog.show();
                        btnEnviarSolicitud.setEnabled(true);
                        btnEnviarSolicitud.setBackgroundResource(R.color.colorPrimaryDark);
                    }
                }) {
                    @Override
                    public Map<String, String> getHeaders() {
                        Map<String, String> params = new HashMap<>();
                        params.put("Content-Type", "application/json; charset=UTF-8");
                        params.put("Authorization", key);
                        return params;
                    }

                    @Override
                    public String getBodyContentType() {
                        return "application/json; charset=utf-8";
                    }

                    @Override
                    public byte[] getBody() {
                        return mRequestBody == null ? null : mRequestBody.getBytes(StandardCharsets.UTF_8);
                    }

                    @Override
                    protected Response<String> parseNetworkResponse(NetworkResponse response) {
                        String responseString = "";
                        if (response != null) {
                            responseString = String.valueOf(response.statusCode);
                        }
                        assert response != null;
                        return Response.success(responseString, HttpHeaderParser.parseCacheHeaders(response));
                    }
                };

                requestQueue.add(stringRequest);
            }
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            Intent intent = NavUtils.getParentActivityIntent(this);
            if (intent != null) {
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                NavUtils.navigateUpTo(this, intent);
            }
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void ponerElementos() {
        tvAbreLunes.setOnClickListener(null);
        tvAbreMartes.setOnClickListener(null);
        tvAbreMiercoles.setOnClickListener(null);
        tvAbreJueves.setOnClickListener(null);
        tvAbreViernes.setOnClickListener(null);
        tvAbreSabado.setOnClickListener(null);
        tvAbreDomingo.setOnClickListener(null);

        tvCierraLunes.setOnClickListener(null);
        tvCierraMartes.setOnClickListener(null);
        tvCierraMiercoles.setOnClickListener(null);
        tvCierraJueves.setOnClickListener(null);
        tvCierraViernes.setOnClickListener(null);
        tvCierraSabado.setOnClickListener(null);
        tvCierraDomingo.setOnClickListener(null);

        cbLunes.setButtonDrawable(R.color.white);
        cbMartes.setButtonDrawable(R.color.white);
        cbMiercoles.setButtonDrawable(R.color.white);
        cbJueves.setButtonDrawable(R.color.white);
        cbViernes.setButtonDrawable(R.color.white);
        cbSabado.setButtonDrawable(R.color.white);
        cbDomingo.setButtonDrawable(R.color.white);

        FirebaseStorage storage = FirebaseStorage.getInstance();
        storageReference = storage.getReferenceFromUrl(solicitud.getFoto());
        GlideApp.with(this)
                .load(storageReference)
                .into(imagen);

        imagen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new ImageDialog(context, solicitud.getFoto());
            }
        });

        String url = "https://api.mapbox.com/v4/mapbox.emerald/pin-m-star+ff0000(" + solicitud.getLongitud() + "," + solicitud.getLatitud() + ")/" + solicitud.getLongitud() + "," + solicitud.getLatitud() + ",16/200x200@2x.png?access_token=pk.eyJ1Ijoib3NjYXJydWl6MTUiLCJhIjoiY2pzYzA3MjRvMDFrdDN5dDBsaHVyNmtpdCJ9.HVKQeMVUWUULUCH6YTCa9w";
        GlideApp.with(context)
                .load(url)
                .into(imagenSitio);

        ponerHorarios();

        txtnombre.setText(solicitud.getNombre_lugar());
        txtdescripcion.setText(solicitud.getInformacion());
        txtdireccion.setText(solicitud.getDireccion());
        txtemail.setText(solicitud.getEmail().get(0));
        txttelefono.setText(solicitud.getTelefono());

        actionBar.showToolbar("Detalles Solicitud", true, this);

        txtnombre.setEnabled(false);
        txtdescripcion.setEnabled(false);
        txtdireccion.setEnabled(false);
        txtemail.setEnabled(false);
        txttelefono.setEnabled(false);
        btnEnviarSolicitud.setVisibility(View.GONE);
        btnUbicar.setVisibility(View.GONE);
        relativeCoordenadas.setVisibility(View.GONE);
        imagenSitio.setVisibility(View.VISIBLE);
    }

    public void agregarImagen(View view) {
        agregarImagenGaleria();
    }

    private void agregarImagenGaleria() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (inputMethodManager != null) {

        }

        startActivityForResult(Intent.createChooser(intent, "Selecciona la Aplicación"), 10);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if (requestCode == FOTO_DE_GALERIA) {
                Uri path = data.getData();
                imagen.setImageURI(path);
                getAbsolutePhotoPath = path;
            }
        }
    }

    private String uploadPhoto(String child) {
        StorageReference imageReference = storageReference.child(child);

        UploadTask uploadTask = imageReference.putFile(getAbsolutePhotoPath);

        uploadTask.addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
            }
        }).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
            }
        });
        return Constants.FIREBASE_STORAGE_URL_SOLICITUDES + Constants.BAR + child;
    }

    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.editTextHoraAbrirLUN:
                obtenerHora(tvAbreLunes);
                break;
            case R.id.editTextHoraAbrirMAR:
                obtenerHora(tvAbreMartes);
                break;
            case R.id.editTextHoraAbrirMIE:
                obtenerHora(tvAbreMiercoles);
                break;
            case R.id.editTextHoraAbrirJUE:
                obtenerHora(tvAbreJueves);
                break;
            case R.id.editTextHoraAbrirVIE:
                obtenerHora(tvAbreViernes);
                break;
            case R.id.editTextHoraAbrirSAB:
                obtenerHora(tvAbreSabado);
                break;
            case R.id.editTextHoraAbrirDOM:
                obtenerHora(tvAbreDomingo);
                break;
            case R.id.editTextHoraCerrarLUN:
                obtenerHora(tvCierraLunes);
                break;
            case R.id.editTextHoraCerrarMAR:
                obtenerHora(tvCierraMartes);
                break;
            case R.id.editTextHoraCerrarMIE:
                obtenerHora(tvCierraMiercoles);
                break;
            case R.id.editTextHoraCerrarJUE:
                obtenerHora(tvCierraJueves);
                break;
            case R.id.editTextHoraCerrarVIE:
                obtenerHora(tvCierraViernes);
                break;
            case R.id.editTextHoraCerrarSAB:
                obtenerHora(tvCierraSabado);
                break;
            case R.id.editTextHoraCerrarDOM:
                obtenerHora(tvCierraDomingo);
                break;
        }
    }

    private void obtenerHora(final TextView textView) {
        TimePickerDialog recogerHora = new TimePickerDialog(this, new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                //Formateo el hora obtenido: antepone el 0 si son menores de 10
                String horaFormateada = (hourOfDay < 10) ? String.valueOf(CERO + hourOfDay) : String.valueOf(hourOfDay);
                //Formateo el minuto obtenido: antepone el 0 si son menores de 10
                String minutoFormateado = (minute < 10) ? String.valueOf(CERO + minute) : String.valueOf(minute);
                //Obtengo el valor a.m. o p.m., dependiendo de la selección del usuario
                String AM_PM;
                if (hourOfDay < 12) {
                    AM_PM = "a.m.";
                } else {
                    AM_PM = "p.m.";
                }
                //Muestro la hora con el formato deseado
                String estado = textView.getText().toString().trim();
                String hora = horaFormateada + DOS_PUNTOS + minutoFormateado + " " + AM_PM;
                textView.requestFocus();
                switch (estado) {
                    case "Abres..":
                        ponerHoraAbierto(hora);
                        break;
                    case "Cierras..":
                        ponerHoraCerrado(hora);
                        break;
                    default:
                        textView.setText(hora);
                        break;
                }
            }
            //Estos valores deben ir en ese orden
            //Al colocar en false se muestra en formato 12 horas y true en formato 24 horas
            //Pero el sistema devuelve la hora en formato 24 horas
        }, hora, minuto, false);

        recogerHora.show();
    }

    public void ponerHoraAbierto(String hora) {
        String estado = tvAbreLunes.getText().toString().trim();
        if (estado.equals("Abres..")) {
            tvAbreLunes.setText(hora);
        }
        estado = tvAbreMartes.getText().toString().trim();
        if (estado.equals("Abres..")) {
            tvAbreMartes.setText(hora);
        }
        estado = tvAbreMiercoles.getText().toString().trim();
        if (estado.equals("Abres..")) {
            tvAbreMiercoles.setText(hora);
        }
        estado = tvAbreJueves.getText().toString().trim();
        if (estado.equals("Abres..")) {
            tvAbreJueves.setText(hora);
        }
        estado = tvAbreViernes.getText().toString().trim();
        if (estado.equals("Abres..")) {
            tvAbreViernes.setText(hora);
        }
        estado = tvAbreSabado.getText().toString().trim();
        if (estado.equals("Abres..")) {
            tvAbreSabado.setText(hora);
        }
        estado = tvAbreDomingo.getText().toString().trim();
        if (estado.equals("Abres..")) {
            tvAbreDomingo.setText(hora);
        }
    }

    public void ponerHoraCerrado(String hora) {
        String estado = tvCierraLunes.getText().toString().trim();
        if (estado.equals("Cierras..")) {
            tvCierraLunes.setText(hora);
        }
        estado = tvCierraMartes.getText().toString().trim();
        if (estado.equals("Cierras..")) {
            tvCierraMartes.setText(hora);
        }
        estado = tvCierraMiercoles.getText().toString().trim();
        if (estado.equals("Cierras..")) {
            tvCierraMiercoles.setText(hora);
        }
        estado = tvCierraJueves.getText().toString().trim();
        if (estado.equals("Cierras..")) {
            tvCierraJueves.setText(hora);
        }
        estado = tvCierraViernes.getText().toString().trim();
        if (estado.equals("Cierras..")) {
            tvCierraViernes.setText(hora);
        }
        estado = tvCierraSabado.getText().toString().trim();
        if (estado.equals("Cierras..")) {
            tvCierraSabado.setText(hora);
        }
        estado = tvCierraDomingo.getText().toString().trim();
        if (estado.equals("Cierras..")) {
            tvCierraDomingo.setText(hora);
        }
    }

    private void obtenerDiasDeAtencion() {
        if (cbLunes.isChecked()) {
            dias_servicio.add(cbLunes.getText().toString().trim());
            hora_abierto.add(tvAbreLunes.getText().toString().trim());
            hora_cerrado.add(tvCierraLunes.getText().toString().trim());
        } else {
            dias_servicio.add("N");
            hora_abierto.add("N");
            hora_cerrado.add("N");
        }
        if (cbMartes.isChecked()) {
            dias_servicio.add(cbMartes.getText().toString().trim());
            hora_abierto.add(tvAbreMartes.getText().toString().trim());
            hora_cerrado.add(tvCierraMartes.getText().toString().trim());
        } else {
            dias_servicio.add("N");
            hora_abierto.add("N");
            hora_cerrado.add("N");
        }
        if (cbMiercoles.isChecked()) {
            dias_servicio.add(cbMiercoles.getText().toString().trim());
            hora_abierto.add(tvAbreMiercoles.getText().toString().trim());
            hora_cerrado.add(tvCierraMiercoles.getText().toString().trim());
        } else {
            dias_servicio.add("N");
            hora_abierto.add("N");
            hora_cerrado.add("N");
        }
        if (cbJueves.isChecked()) {
            dias_servicio.add(cbJueves.getText().toString().trim());
            hora_abierto.add(tvAbreJueves.getText().toString().trim());
            hora_cerrado.add(tvCierraJueves.getText().toString().trim());
        } else {
            dias_servicio.add("N");
            hora_abierto.add("N");
            hora_cerrado.add("N");
        }
        if (cbViernes.isChecked()) {
            dias_servicio.add(cbViernes.getText().toString().trim());
            hora_abierto.add(tvAbreViernes.getText().toString().trim());
            hora_cerrado.add(tvCierraViernes.getText().toString().trim());
        } else {
            dias_servicio.add("N");
            hora_abierto.add("N");
            hora_cerrado.add("N");
        }
        if (cbSabado.isChecked()) {
            dias_servicio.add(cbSabado.getText().toString().trim());
            hora_abierto.add(tvAbreSabado.getText().toString().trim());
            hora_cerrado.add(tvCierraSabado.getText().toString().trim());
        } else {
            dias_servicio.add("N");
            hora_abierto.add("N");
            hora_cerrado.add("N");
        }
        if (cbDomingo.isChecked()) {
            dias_servicio.add(cbDomingo.getText().toString().trim());
            hora_abierto.add(tvAbreDomingo.getText().toString().trim());
            hora_cerrado.add(tvCierraDomingo.getText().toString().trim());
        } else {
            dias_servicio.add("N");
            hora_abierto.add("N");
            hora_cerrado.add("N");
        }
    }

    private void ponerHorarios() {
        ArrayList<String> dias = solicitud.getDias_servicio();
        ArrayList<String> abre = solicitud.getHora_abierto();
        ArrayList<String> cierra = solicitud.getHora_cerrado();

        if (dias.get(0).equals("N")) {
            layoutHorarios.removeView(horarioLunes);
        } else {
            tvAbreLunes.setText(abre.get(0));
            tvCierraLunes.setText(cierra.get(0));
        }
        if (dias.get(1).equals("N")) {
            layoutHorarios.removeView(horarioMartes);
        } else {
            tvAbreMartes.setText(abre.get(1));
            tvCierraMartes.setText(cierra.get(1));
        }
        if (dias.get(2).equals("N")) {
            layoutHorarios.removeView(horarioMiercoles);
        } else {
            tvAbreMiercoles.setText(abre.get(2));
            tvCierraMiercoles.setText(cierra.get(2));
        }
        if (dias.get(3).equals("N")) {
            layoutHorarios.removeView(horarioJueves);
        } else {
            tvAbreJueves.setText(abre.get(3));
            tvCierraJueves.setText(cierra.get(3));
        }
        if (dias.get(4).equals("N")) {
            layoutHorarios.removeView(horarioViernes);
        } else {
            tvAbreViernes.setText(abre.get(4));
            tvCierraViernes.setText(cierra.get(4));
        }
        if (dias.get(5).equals("N")) {
            layoutHorarios.removeView(horarioSabado);
        } else {
            tvAbreSabado.setText(abre.get(5));
            tvCierraSabado.setText(cierra.get(5));
        }
        if (dias.get(6).equals("N")) {
            layoutHorarios.removeView(horarioDomingo);
        } else {
            tvAbreDomingo.setText(abre.get(6));
            tvCierraDomingo.setText(cierra.get(6));
        }

    }

    public void ubicarMapa(View view) {
        new MapaDialog(this, textoLatitud, textoLongitud);
    }
}
