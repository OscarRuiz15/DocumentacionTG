package com.guideme.application.android.modelo;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.Serializable;

public class Tag implements Serializable {

    private int id;
    private String nombre;

    public Tag(int id, String nombre) {
        this.id = id;
        this.nombre = nombre;
    }

    public Tag() {
    }

    public Tag(JSONObject jsonObject) throws JSONException {
        this.id = jsonObject.getInt("id");
        this.nombre = jsonObject.getString("nombre");
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public JSONObject getJSONProducto() throws JSONException {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("id", id);
        jsonObject.put("nombre", nombre);
        return jsonObject;
    }
}
