package com.guideme.application.android.utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Utilidades {
    public static List<List<HashMap<String, String>>> routes = new ArrayList<List<HashMap<String, String>>>();
}
