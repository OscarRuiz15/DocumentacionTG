package com.guideme.application.android.utils;

import android.os.Build;
import android.text.Html;
import android.text.Spanned;

import java.util.ArrayList;

public class AgregarURL {
    private ArrayList<String> urls;

    public AgregarURL(ArrayList<String> urls) {
        this.urls = urls;
    }

    public Spanned crearUrls() {
        String auxWebs = "";
        for (int i = 0; i < urls.size(); i++) {
            urls.set(i, "<a href=\"" + urls.get(i) + "\">" + urls.get(i) + "</a>" + "\n");
            auxWebs += urls.get(i) + "\n";
        }
        Spanned url = fromHtml(auxWebs);
        return url;
    }

    @SuppressWarnings("deprecation")
    public static Spanned fromHtml(String html) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            return Html.fromHtml(html, Html.FROM_HTML_MODE_LEGACY);
        } else {
            return Html.fromHtml(html);
        }
    }
}
