package com.guideme.application.android.vista.activities;

import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.NavUtils;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.guideme.application.android.utils.Constants;
import com.guideme.application.android.R;
import com.guideme.application.android.modelo.Lugar;
import com.guideme.application.android.modelo.Usuario;
import com.guideme.application.android.utils.Operaciones;
import com.guideme.application.android.vista.adapters.recycler.FotoAdapterRecycler;

import org.json.JSONException;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class VerFotosActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private Button btnGuardar;

    private Lugar lugar;
    private Usuario usuario;

    private FirebaseStorage firebaseStorage = FirebaseStorage.getInstance();
    private StorageReference storageReference;

    private int contador;
    private int cantidadOriginal;

    private String key;

    private AlertDialog alertDialog;

    private final Operaciones operaciones = new Operaciones();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ver_fotos);

        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();

        if (savedInstanceState != null) {
            lugar = (Lugar) savedInstanceState.getSerializable("lugar");
            usuario = (Usuario) savedInstanceState.getSerializable("usuario");
            key = savedInstanceState.getString("key");
        } else {
            lugar = (Lugar) (bundle != null ? bundle.getSerializable("lugar") : null);
            usuario = (Usuario) (bundle != null ? bundle.getSerializable("usuario") : null);
            key = bundle != null ? bundle.getString("key") : null;
        }

        btnGuardar = findViewById(R.id.btnGuardar);
        recyclerView = findViewById(R.id.recyclerFotos);

        GridLayoutManager gridLayoutManager = new GridLayoutManager(this, 2);
        recyclerView.setLayoutManager(gridLayoutManager);

        FotoAdapterRecycler fotoAdapterRecycler = new FotoAdapterRecycler(lugar.getFoto(), this);
        recyclerView.setAdapter(fotoAdapterRecycler);

        ActionBar actionBar = new ActionBar();
        actionBar.showToolbar("Fotos", true, this);

        storageReference = firebaseStorage.getReferenceFromUrl(Constants.FIREBASE_STORAGE_URL_LUGAR).child(lugar.getId() + "");

        contador = 0;
        cantidadOriginal = lugar.getFoto().size();

        FloatingActionButton btnMas = findViewById(R.id.fabImagen);

        if (usuario.getId() != lugar.getId_propietario()) {
            btnMas.setVisibility(View.INVISIBLE);
        }

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(":)");
        builder.setMessage("Se han guardado los cambios.");
        builder.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                irDetalleslugar();//getLugarJSONVolley();
            }
        });
        alertDialog = builder.create();
    }

    public void agregarImagenes(View view) {
        Intent intent = new Intent();
        intent.setType("image/*");

        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);

        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Selecciona la Aplicación"), 10);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            int cantidad;
            try {
                cantidad = Objects.requireNonNull(data.getClipData()).getItemCount();
                for (int i = 0; i < cantidad; i++) {
                    contador++;
                    String foto = data.getClipData().getItemAt(i).getUri().toString();
                    lugar.getFoto().add(foto);

                }
            } catch (Exception e) {
                contador++;
                String foto = Objects.requireNonNull(data.getData()).toString();
                lugar.getFoto().add(foto);

            }
            FotoAdapterRecycler fotoAdapterRecycler = new FotoAdapterRecycler(lugar.getFoto(), this);
            recyclerView.setAdapter(fotoAdapterRecycler);
            btnGuardar.setVisibility(View.VISIBLE);
        }

    }

    private String uploadPhoto(Uri uri, int j) {

        StorageReference imageReference = storageReference.child(j + "");

        UploadTask uploadTask = imageReference.putFile(uri);

        uploadTask.addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {

            }
        }).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
            }
        });
        return Constants.FIREBASE_STORAGE_URL_LUGAR + Constants.BAR
                + lugar.getId() + Constants.BAR + j;
    }

    public void guardarCambios(View view) {
        for (int i = 0; i < contador; i++) {
            int j = cantidadOriginal + i;
            Uri uri = Uri.parse(lugar.getFoto().get(j));
            String foto = uploadPhoto(uri, j);
            lugar.getFoto().set(j, foto);
        }
        putFotosLugarVolley();
        //finish();
    }

    private void putFotosLugarVolley() {
        try {
            lugar.setRating(operaciones.calcularCalificacion(lugar.getComentarios()));
            RequestQueue requestQueue = Volley.newRequestQueue(this);
            JSONObject jsonLugar = lugar.getJSONLugar();
            final String mRequestBodyLugar = jsonLugar.toString();
            //System.out.println("---> " + mRequestBodyLugar);
            String url = Constants.URL + Constants.URL_LUGARES_API + lugar.getId() + Constants.BAR;
            //System.out.println(jsonLugar.toString());

            StringRequest stringRequestLugar = new StringRequest(Request.Method.PUT, url, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    //Log.i("TAG", "Bien");
                    alertDialog.show();

                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    //Log.i("TAG", error.toString());
                }
            }) {
                @Override
                public Map<String, String> getHeaders() {
                    Map<String, String> params = new HashMap<>();
                    params.put("Content-Type", "application/json; charset=UTF-8");
                    params.put("Authorization", key);
                    return params;
                }

                @Override
                public String getBodyContentType() {
                    return "application/json; charset=utf-8";
                }

                @Override
                public byte[] getBody() {
                    return mRequestBodyLugar == null ? null : mRequestBodyLugar.getBytes(StandardCharsets.UTF_8);
                }

                @Override
                protected Response<String> parseNetworkResponse(NetworkResponse response) {
                    String responseString = "";
                    if (response != null) {
                        responseString = String.valueOf(response.statusCode);
                    }
                    return Response.success(responseString, HttpHeaderParser.parseCacheHeaders(response));
                }
            };

            stringRequestLugar.setRetryPolicy(new DefaultRetryPolicy(
                    DefaultRetryPolicy.DEFAULT_TIMEOUT_MS * 5,
                    DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

            requestQueue.add(stringRequestLugar);

        } catch (JSONException e) {
            //e.printStackTrace();
        }
    }

    public void onSaveInstanceState(Bundle savedInstanceState) {
        // Save the user's current game state
        savedInstanceState.putSerializable("lugar", lugar);
        savedInstanceState.putSerializable("usuario", usuario);
        savedInstanceState.putString("key", key);

        // Always call the superclass so it can save the view hierarchy state
        super.onSaveInstanceState(savedInstanceState);
    }

    public void onRestoreInstanceState(Bundle savedInstanceState) {
        // Always call the superclass so it can restore the view hierarchy
        super.onRestoreInstanceState(savedInstanceState);

        // Restore state members from saved instance
        lugar = (Lugar) savedInstanceState.getSerializable("lugar");
        usuario = (Usuario) savedInstanceState.getSerializable("usuario");
        key = savedInstanceState.getString("key");
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            Intent intent = NavUtils.getParentActivityIntent(this);
            if (intent != null) {
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                NavUtils.navigateUpTo(this, intent);
            }
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public void irDetalleslugar() {
        Intent intent = new Intent(this, DetallesLugarActivity.class);
        Bundle bundle = new Bundle();
        bundle.putSerializable("usuario", usuario);
        bundle.putSerializable("lugar", lugar);
        bundle.putString("key", key);
        intent.putExtras(bundle);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
    }
}
