from django.apps import AppConfig


class ProductosConfig(AppConfig):
    name = 'productos'
