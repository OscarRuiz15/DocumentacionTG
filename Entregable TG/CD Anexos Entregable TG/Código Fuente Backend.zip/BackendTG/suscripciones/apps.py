from django.apps import AppConfig


class SuscripcionesConfig(AppConfig):
    name = 'suscripciones'
