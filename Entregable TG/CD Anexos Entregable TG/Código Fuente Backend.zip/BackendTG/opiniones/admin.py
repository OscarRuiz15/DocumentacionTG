from django.contrib import admin
from opiniones.models import Opinion

# Register your models here.
admin.site.register(Opinion)