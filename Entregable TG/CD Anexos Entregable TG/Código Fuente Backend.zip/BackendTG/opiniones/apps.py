from django.apps import AppConfig


class OpinionesConfig(AppConfig):
    name = 'opiniones'
