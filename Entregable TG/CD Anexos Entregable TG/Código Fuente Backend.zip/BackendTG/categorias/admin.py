from django.contrib import admin
from categorias.models import Categoria
# Register your models here.
admin.site.register(Categoria)
