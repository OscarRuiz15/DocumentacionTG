from django.apps import AppConfig


class CategoriasConfig(AppConfig):
    name = 'categorias'
