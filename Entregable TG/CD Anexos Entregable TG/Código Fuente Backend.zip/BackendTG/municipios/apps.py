from django.apps import AppConfig


class MunicipiosConfig(AppConfig):
    name = 'municipios'
