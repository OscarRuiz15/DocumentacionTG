from django.apps import AppConfig


class PreferenciasConfig(AppConfig):
    name = 'preferencias'
