from django.contrib import admin
from preferencias.models import Preferencia

# Register your models here.
admin.site.register(Preferencia)
