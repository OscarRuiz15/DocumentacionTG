from django.apps import AppConfig


class DepartamentosConfig(AppConfig):
    name = 'departamentos'
