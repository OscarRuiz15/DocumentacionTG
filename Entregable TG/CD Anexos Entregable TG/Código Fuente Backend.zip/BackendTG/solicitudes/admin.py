from django.contrib import admin
# Register your models here.
from solicitudes.models import Solicitud

admin.site.register(Solicitud)