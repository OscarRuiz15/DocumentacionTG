from django.apps import AppConfig


class SolicitudesConfig(AppConfig):
    name = 'solicitudes'
