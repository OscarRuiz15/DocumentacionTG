from django.contrib import admin
# Register your models here.
from visitas.models import Visita

admin.site.register(Visita)