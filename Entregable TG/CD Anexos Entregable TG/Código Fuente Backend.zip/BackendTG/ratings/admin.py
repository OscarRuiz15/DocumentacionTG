from django.contrib import admin
from ratings.models import Rating

# Register your models here.
admin.site.register(Rating)
