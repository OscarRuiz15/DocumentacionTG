from django.apps import AppConfig


class LugaresConfig(AppConfig):
    name = 'lugares'
