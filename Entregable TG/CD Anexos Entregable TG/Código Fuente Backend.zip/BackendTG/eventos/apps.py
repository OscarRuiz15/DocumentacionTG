from django.apps import AppConfig


class EventosConfig(AppConfig):
    name = 'eventos'
